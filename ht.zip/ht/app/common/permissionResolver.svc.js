/**
 * Created by jasperchiu on 10/16/15.
 */
angular
  .module('itms.permissionCtrlSvc', [])
  .factory('permissionResolver', ['$state', 'identity', permissionMetrixResolver]);

function permissionMetrixResolver($state, identity) {

   function getPermissionMetrix() {
      //权限限制部分逻辑
      if (!identity
         || !identity.currentUser
         || !identity.currentUser.auth
         || !identity.currentUser.auth.authority) {
         $state.go('app.login');
         return;
      }
      var authInfo = identity.currentUser.auth.authority.split(';');
      //菜单权限控制
      var menuPermissionMetrixValue = authInfo[0];
      //运单类型权限控制
      var erTypePermissionMetrixValue = authInfo[1];
      //运输方式权限控制
      var erTRTypePermissionMetrixValue = authInfo[2];
      //数量更改权限控制
      var quantityPermissionMetrixValue = authInfo[3];

      return {
         menuPermissionMetrixValue: menuPermissionMetrixValue,
         erTypePermissionMetrixValue: erTypePermissionMetrixValue,//ER02
         erTRTypePermissionMetrixValue: erTRTypePermissionMetrixValue,//TTP1
         quantityPermissionMetrixValue: quantityPermissionMetrixValue
      };

      return {
         menuPermissionMetrixValue: "*",
         erTypePermissionMetrixValue: "ER02",//ER02
         erTRTypePermissionMetrixValue: "*",//TTP1
         quantityPermissionMetrixValue: "N"
      };
   }

   return {
      getPermissionMetrix: getPermissionMetrix
   }
}
