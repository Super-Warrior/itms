angular.module('itms.map')
    .controller('mapCtrl', ['$scope', mapCtrl]);

function mapCtrl($scope) {
  
}
