angular.module('itms.transport.event')
    .controller('EventSearchCtrl', ['$scope', '$state', '$log', 'eventService', 'exportService', EventSearchCtrl])
    .controller('EventSearchCtrl.MyWorkSpace', ['$scope', '$modal', 'common', 'exportService', EventWorkSpaceCtrl])
    .controller('UserEventSearchCtrl', ['$scope', '$state', '$log', 'eventService', 'exportService', 'common', UserEventSearchCtrl]);

function EventSearchCtrl($scope, $state, $log, eventService, exportService) {

   $scope.module = '运输执行';
   $scope.title = '事件查询';
   $scope.events = [];
   $scope.totalEvents = [];
   $scope.eventSearchCriteria = {
      quickSearch: {},
      erSearch: {},
      eoSearch: {}
   };
  
   activate();

   function activate() {
      eventService.getAllConfigData().then(function (result) {
         $scope.configData = result;
      });

   }

   $scope.searchByEvent = function () {
      $state.go('app.user.transport.eventSearch.search.searchByEvent');
   };
   $scope.searchByEo = function () {
      $state.go('app.user.transport.eventSearch.search.searchByEo');
   };
   $scope.searchByEr = function () {
      $state.go('app.user.transport.eventSearch.search.searchByEr');
   };

   $scope.eventSearch = function (queryOptions) {
      eventService.queryByEvent(queryOptions)
          .success(function (data) {
             $scope.events = data ? eventService.getEventPartial(data) : [];
             $scope.totalEvents = $scope.events;
          })
          .error(function () {
             $log.error('EventSearchCtrl: eventSearch');
          });
   };

   $scope.erSearch = function (queryOptions) {
      eventService.queryByEr(queryOptions)
          .success(function (data) {
             $scope.events = data ? eventService.getEventPartial(data) : [];
             $scope.totalEvents = $scope.events;
          })
          .error(function () {
             $log.error('EventSearchCtrl: queryByEr');
          });
   };

   $scope.eoSearch = function (queryOptions) {
      eventService.queryByEo(queryOptions)
          .success(function (data) {
             $scope.events = data ? eventService.getEventPartial(data) : [];
             $scope.totalEvents = $scope.events;
          })
          .error(function () {
             $log.error('EventSearchCtrl: queryByEr');
          });
   };


   $scope.resetQuickSearch = function () {
      $scope.eventSearchCriteria.quickSearch = {};
   };

   $scope.resetEr = function () {
      $scope.eventSearchCriteria.erSearch = {};
   };

   $scope.resetEo = function () {
      $scope.eventSearchCriteria.eoSearch = {};
   };
   //$state.go('app.user.transport.eventSearch.search.searchByEvent');

}

function EventWorkSpaceCtrl($scope, $modal, common, exportService) {

   $scope.selectedItems = [];
   $scope.columns = [
       {
          "mData": "eventType",
          "sTitle": "事件类型"
          
       },
       {
          "mData": "eventCode",
          "sTitle": "事件代码",
          "sWidth": 120
       },
       {
          "mData": "eventDesc",
          "sTitle": "事件代码描述",
          "sWidth": 180
       },
       {
          "mData": "eventDateTime",
          "sTitle": "发生时间",
          "sWidth": 150
       },
       {
          "mData": "createUser",
          "sTitle": "执行帐号"
       },
       {
          "mData": "eoNumber",
          "sTitle": "EO/ER/ERITN"
       }
   ];

   $scope.detailConfig = {
      erDetail: true,
      timeLine: true,
      eoDetail: true
   };

   $scope.handleEvent = function () {
      var modalInstance = $modal.open({
         templateUrl: 'app/transport/event/handleEvent.tpl.html',
         controller: 'HandleEventCtrl',
         resolve: {
            items: function () {
               return $scope.selectedItems.map(function (item) {
                  return {
                     eo: item.eoid,
                     erid: item.erid,
                     erITN: item.eritn
                  };
               });
            }
         }
      });
      modalInstance.result.then(function () {
         common.notifier.success("操作成功");
      });
   };

   $scope.export = function () {
      exportService.export($scope.columns, $scope.totalEvents);
   };

   $scope.getHeader = function () {
      return $scope.columns.map(function (header) {
         return header.sTitle;
      });
   };

   $scope.disableAction = function () {
      return $scope.selectedItems.length === 0;
   };

   $scope.filterEvent = function (eventType) {
      if (eventType) {
         $scope.events = $scope.totalEvents.filter(function (item) {
            return item.eventType == eventType
         });
      } else {
         $scope.events = $scope.totalEvents;
      }
   };


}

function UserEventSearchCtrl($scope, $state, $log, eventService, exportService, common) {
    $scope.module = '事件管理';
    $scope.title = '用户事件查询';

    $scope.reset = function () {
        $scope.customerOrder1 = '';
        $scope.customerOrder2 = '';
    };

    $scope.customerOrder1 = '';
    $scope.customerOrder2 = '';

    $scope.userEventSearch = function() {
        var eventSearchCriteria = {
            customerOrder1 :  $scope.customerOrder1,
            customerOrder2 :  $scope.customerOrder2,
            customerOrder3 :  ""
        };

        if (!(eventSearchCriteria.customerOrder1) && !(eventSearchCriteria.customerOrder2)) {
            common.notifier.cancel("客户订单号与莲花运单号两者至少输入一项！");
            return;
        }
        eventService.queryUserEvent(eventSearchCriteria)
            .success(function (data) {
                if (data.errorMessage && data.errorMessage === 'NO_RESULT') {
                    common.notifier.success("查询无结果！");
                    return;
                }
                $scope.timelines = data;
            })
            .error(function () {
                $log.error('UserEventSearchCtrl: userEventSearch');
            });
    };
}