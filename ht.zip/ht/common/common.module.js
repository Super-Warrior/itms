angular.module('common', [
            'common.directives.datepicker',
            'common.directives.table',
            'common.directives.widget',
            'common.directives.breadcrumb',
            'common.directives.menu',
            'common.directives.timepicker',
            'common.directives.replacement',
            'common.directives.autoComplete',
            'common.directives.tinyTable'
]);
