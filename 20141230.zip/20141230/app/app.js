angular.module('common', [
    'common.directives.datepicker',
    'common.directives.table',
    'common.directives.widget',
    'common.directives.breadcrumb',
    'common.directives.menu',
    'common.directives.timepicker',
   'common.directives.replacement'
]);
;angular.module('common.directives.breadcrumb', [])
    .directive('swBreadcrumb', function() {
        return {
            restrict: 'A',
            templateUrl: 'template/breadcrumb.tpl.html',
            replace: true
        };

    }).run(function($templateCache) {
        $templateCache.put('template/breadcrumb.tpl.html',
            '<ol class="breadcrumb">\n' +
            '  <li ng-repeat="path in paths"><a data-ui-sref="{{path.state}}">{{path.displayName}}</a></li>\n' +
            '</ol>'
            );
    });
;angular.module('common.directives.datepicker', [])
    .directive('imDatepicker', function () {
        return {
            restrict: 'A',
            require: '?ngModel',
            scope: {

            },
            link: postLink
        };

        function postLink(scope, element, attrs, ngModel) {
            element.datepicker({
                dateFormat: 'yy-mm-dd',
                prevText: '<i class="fa fa-chevron-left"></i>',
                nextText: '<i class="fa fa-chevron-right"></i>'
            });
        }
    });
;angular.module('common.directives.menu', [])
    .directive('swMenu', function () {
        return {
            restrict: 'A',
            templateUrl: 'common/menu/menu.tpl.html',
            replace: true,
            link: link

        };

        function link (scope, element, attrs){
            $.menu_speed = 235;
            $.navbar_height = 49;
            $.root_ = $('body');
            $.left_panel = $('#left-panel');
            $.shortcut_dropdown = $('#shortcut');
            nav_page_height();
            $('nav ul').jarvismenu({
                accordion: true,
                speed: $.menu_speed,
                closedSign: '<em class="fa fa-plus-square-o"></em>',
                openedSign: '<em class="fa fa-minus-square-o"></em>'
            });

            $('#main').resize(function() {
                nav_page_height();
                
            });

            $('nav').resize(function() {
                nav_page_height();
            });

            
            $('.minifyme').click(function(e) {
                $('body').toggleClass("minified");
                $(this).effect("highlight", {}, 500);
                e.preventDefault();
            });

            
            $('#hide-menu >:first-child > a').click(function(e) {
                $('body').toggleClass("hidden-menu");
                e.preventDefault();
            });

            $('#show-shortcut').click(function(e) {
                if ($.shortcut_dropdown.is(":visible")) {
                    shortcut_buttons_hide();
                } else {
                    shortcut_buttons_show();
                }
                e.preventDefault();
            });
            $.shortcut_dropdown.click(function(){
                shortcut_buttons_hide();
            });
        }

    });
;angular.module('common.directives.replacement', [])
    .directive('imReplacement', function () {
       return {
          replace: true,
          restrict: 'A',
          templateUrl: function (element, attr) {
             return attr.imReplacement;
          }
       };

    
    });
;angular.module('common.directives.table', [])
  
  .directive('imTable', ['$modal', 'common',
    function ($modal, common) {
       'use strict';

       var settings = {},
         table;

       return {
          restrict: 'A',
          replace: true,
          scope: {
             headerTitles: '=headerTitles',
             dataSource: '=mySource',
             canSelect: '@canSelect',
             detailConfig: '=detailConfig',
             selectedItems: '=selectedItems'
          },
          template: '<table class="table table-striped table-hover"></table>',
          link: postLink
       };

       function postLink(scope, element, attrs) {
          scope.clickAll = function () {
             console.log('click all');
          };
          settings = {
             sScrollX: '100%',
             bScrollCollapse: true,
             aoColumns: scope.headerTitles,
             aaData: scope.dataSource,
             sDom: "R<'dt-top-row'Clf>r<'dt-wrapper't><'dt-row dt-bottom-row'<'row'<'col-sm-6'i><'col-sm-6 text-right'p>>",
             bAutoWidth: false,
             fnInitComplete: function (oSettings, json) {
                $('.ColVis_Button')
                  .addClass('btn btn-default btn-sm')
                  .html('Columns <i class="icon-arrow-down"></i>');
             }
          };
          setWatchOnTheSource(scope, element);
       }

       function initilizeTable(source, element, scope) {
          var canSelect = ((typeof element.attr("can-select")) !== "undefined");
          settings.aaData = source;

          if (scope.detailConfig) {
             var content = [];
             if (scope.detailConfig.erDetail) {
                content.push('<a href="javascript:void(0)" id="showErDetail" template="erDetail.tpl.html"><i class="fa fa-truck"></i></a>');
             }
             if (scope.detailConfig.eoDetail) {
                content.push('<a href="javascript:void(0)" id="showEoDetail" template="eoDetail.tpl.html"><i class="fa fa-inbox"></i></a>');
             }
             if (scope.detailConfig.timeLine) {
                content.push('<a href="javascript:void(0)" id="showTimeLine" template="timeLine.tpl.html"><i class="fa fa-clock-o"></i></a>');
             }
             settings.aoColumns.push({
                sTitle: '&nbsp;明细&nbsp;',
                
                sWidth: 70,
                mData: null,
                sDefaultContent: content.join('&nbsp;'),
                bSortable: false
             });
          }

          if (canSelect) {
             settings.aoColumns.unshift({
                sTitle: "<input type='checkbox' class='allResult'>",
                
                sWidth: 50,
                mData: null,
                sDefaultContent: "<input type='checkbox'>",
                bSortable: false
             });
          }

          settings.aoColumns.forEach(
             function (col) {
                
                
                if (!col.sWidth)
                   col.sWidth = 80;
             }
          );
          table = element.dataTable(settings);
          bindEventHandler(scope, table);
       }

       function bindEventHandler(scope, t) {
          $(".dataTables_wrapper").delegate('.allResult', "click", function () {
             var that = this;
             t.find('tbody input[type="checkbox"]').each(function (index, element) {
                if ($(that).is(":checked")) {
                   if (!$(element).is(':checked')) {
                      $(element).trigger('click');
                   }
                } else {
                   if ($(element).is(':checked')) {
                      $(element).trigger('click');
                   }
                }
             });
          });

          if (scope.detailConfig && scope.detailConfig.erDetail) {
             t.on('click', 'tbody tr #showErDetail', function (e) {
                var rowData = t.fnGetData($(this).parent().parent()[0]);
                var target = 'app/common/details/' + $(this).attr("template");
                $modal.open({
                   templateUrl: target,
                   controller: erDetailCtrl,
                   windowClass: 'erDetail-window',
                   resolve: {
                      data: function () {
                         return rowData;
                      }
                   }
                });
                e.preventDefault();
                return false;
             });
          }
          if (scope.detailConfig && scope.detailConfig.timeLine) {
             t.on('click', 'tbody tr #showTimeLine', function (e) {
                var rowData = t.fnGetData($(this).parent().parent()[0]);
                var target = 'app/common/details/' + $(this).attr("template");
                $modal.open({
                   templateUrl: target,
                   controller: TimeLineCtrl,
                   windowClass: 'timeline-window',
                   resolve: {
                      data: function () {
                         return rowData;
                      }
                   }
                });
                e.preventDefault();
                return false;
             });
          }
          if (scope.detailConfig && scope.detailConfig.eoDetail) {
             t.on('click', 'tbody tr #showEoDetail', function (e) {
                var rowData = t.fnGetData($(this).parent().parent()[0]);
                var target = 'app/common/details/' + $(this).attr('template');
                var modalInstance = $modal.open({
                   templateUrl: target,
                   controller: EODetailCtrl,
                   windowClass: 'eoDetail-window',
                   resolve: {
                      data: function () {
                         return rowData;
                      }
                   }
                });
                modalInstance.result.then(function () {
                   common.notifier.success('操作成功');
                });
                e.preventDefault();
                return false;
             });
          }

          if (typeof scope.canSelect !== 'undefined') {
             t.on('click', 'tbody tr', function (e) {
                var selectedRow = this,
                  rowData = t.fnGetData(this),
                  $checkBox = $(selectedRow).find('input[type="checkbox"]');

                scope.$apply(function () {
                   if (isRowSelected(selectedRow)) {
                      $checkBox.prop('checked', false);
                      $(selectedRow).removeClass('highlight');
                      _.remove(scope.selectedItems, function (item) {
                         return item._rowId === selectedRow._DT_RowIndex;
                      });
                   } else {
                      $checkBox.prop('checked', true);
                      rowData._rowId = selectedRow._DT_RowIndex;
                      $(selectedRow).addClass('highlight');
                      scope.selectedItems.push(rowData);
                   }

                   scope.$emit("selectionChange", scope.selectedItems);
                });

                function isRowSelected(row) {
                   return scope.selectedItems.some(function (item) {
                      if (item._rowId === row._DT_RowIndex) {
                         return true;
                      }
                   });
                }
             });
          }
       }

       function setWatchOnTheSource(scope, element) {
          var isInitilize = true,
            dataSource = scope.dataSource;
          if (dataSource) {
             scope.$watch('dataSource', function (source) {
                if (isInitilize && source && source.length > 0) {
                   initilizeTable(source, element, scope);
                   isInitilize = false;
                } else if (!isInitilize) {
                   refreshData(source);
                }
             });
          }
       }

       function refreshData(source) {
          table.fnClearTable(false);
          if (source) {
             table.fnAddData(source);
          }
          table.fnDraw();
       }
    }
  ]);
;angular.module('common.directives.timepicker', [])
    .directive('imTimepicker', function () {
       return {
          restrict: 'A',
          require: '?ngModel',
          scope: {

          },
          link: postLink
       };

       function postLink(scope, element, attrs, ngModel) {
          element.timepicker();
       }
    });
;angular.module('common.directives.widget', [])
    .directive('itJarvis', function () {
        var defaultOptions = {
            grid: 'article',
            widgets: '.jarviswidget',
            localStorage: true,
            deleteSettingsKey: '#deletesettingskey-options',
            settingsKeyLabel: 'Reset settings?',
            deletePositionKey: '#deletepositionkey-options',
            positionKeyLabel: 'Reset position?',
            sortable: true,
            buttonsHidden: false,
            
            toggleButton: true,
            toggleClass: 'fa fa-minus | fa fa-plus',
            toggleSpeed: 200,
            onToggle: function () {
            },
            
            deleteButton: true,
            deleteClass: 'fa fa-times',
            deleteSpeed: 200,
            
            
            
            editButton: true,
            editPlaceholder: '.jarviswidget-editbox',
            editClass: 'fa fa-cog | fa fa-save',
            editSpeed: 200,
            
            
            
            colorButton: true,
            
            fullscreenButton: true,
            fullscreenClass: 'fa fa-expand | fa fa-compress',
            fullscreenDiff: 3,
            
            
            
            customButton: false,
            customClass: 'folder-10 | next-10',
            
            
            
            
            
            
            
            buttonOrder: '%refresh% %custom% %edit% %toggle% %fullscreen% %delete%',
            opacity: 1.0,
            dragHandle: '> header',
            placeholderClass: 'jarviswidget-placeholder',
            indicator: true,
            indicatorTime: 600,
            ajax: true,
            timestampPlaceholder: '.jarviswidget-timestamp',
            timestampFormat: 'Last update: %m%/%d%/%y% %h%:%i%:%s%',
            refreshButton: true,
            refreshButtonClass: 'fa fa-refresh',
            labelError: 'Sorry but there was a error:',
            labelUpdated: 'Last Update:',
            labelRefresh: 'Refresh',
            labelDelete: 'Delete widget:',
            
            
            rtl: false, 
            
            
            
            
            
            
            ajaxnav: $.navAsAjax 
        };

        return {
            restrict: 'A',
            link: function (scope, element, attrs) {
                element.jarvisWidgets(defaultOptions);
            }
        }
    })
    .directive('swWidget', function () {

        var defaultOptions = {
            grid: 'article',
            widgets: '.jarviswidget',
            localStorage: true,
            deleteSettingsKey: '#deletesettingskey-options',
            settingsKeyLabel: 'Reset settings?',
            deletePositionKey: '#deletepositionkey-options',
            positionKeyLabel: 'Reset position?',
            sortable: true,
            buttonsHidden: false,
            
            toggleButton: true,
            toggleClass: 'fa fa-minus | fa fa-plus',
            toggleSpeed: 200,
            onToggle: function () {
            },
            
            deleteButton: true,
            deleteClass: 'fa fa-times',
            deleteSpeed: 200,
            
            
            
            editButton: true,
            editPlaceholder: '.jarviswidget-editbox',
            editClass: 'fa fa-cog | fa fa-save',
            editSpeed: 200,
            
            
            
            colorButton: true,
            
            fullscreenButton: true,
            fullscreenClass: 'fa fa-resize-full | fa fa-resize-small',
            fullscreenDiff: 3,
            
            
            
            customButton: false,
            customClass: 'folder-10 | next-10',
            
            
            
            
            
            
            
            buttonOrder: '%refresh% %custom% %edit% %toggle% %fullscreen% %delete%',
            opacity: 1.0,
            dragHandle: '> header',
            placeholderClass: 'jarviswidget-placeholder',
            indicator: true,
            indicatorTime: 600,
            ajax: true,
            timestampPlaceholder: '.jarviswidget-timestamp',
            timestampFormat: 'Last update: %m%/%d%/%y% %h%:%i%:%s%',
            refreshButton: true,
            refreshButtonClass: 'fa fa-refresh',
            labelError: 'Sorry but there was a error:',
            labelUpdated: 'Last Update:',
            labelRefresh: 'Refresh',
            labelDelete: 'Delete widget:',
            
            
            rtl: false, 
            
            
            
            
            
            
            ajaxnav: $.navAsAjax 
        };

        return {
            restrict: 'A',
            scope: {

            },
            transclude: true,
            templateUrl: 'common/widget/swwidget.tpl.html',
            link: function (scope, element, attrs) {
                element.jarvisWidgets(defaultOptions);
            }
        };
    });
;angular
    .module('itms.dashboard', ['ui.router', 'ui.bootstrap'])
    .config(['$stateProvider',
        function($stateProvider) {
            $stateProvider
                .state('app.user.dashboard', {
                    url: '/dashboard',
                    data: {
                        displayName: '我的iTMS'
                    },
                    views: {
                        '': {
                            templateUrl: 'app/dashboard/dashboard.tpl.html',
                            controller: 'DashboardCtrl'
                        }
                    }
                });
        }
    ]);
;angular
    .module('itms.login', ['ui.router', 'ui.bootstrap'])
    .config(['$stateProvider',
        function($stateProvider) {
            $stateProvider
                .state('app.login', {
                    url: '/login',
                    data: {
                        showOnMenu: false,
                        displayName: '登陆'
                    },
                    views: {
                        '': {
                            templateUrl: 'app/login/login.tpl.html',
                            controller: LoginCtrl
                        }
                    }
                });
        }
    ]);
;angular
    .module('itms.map', ['ui.router', 'ui.bootstrap'])
    .config(['$stateProvider',
        function ($stateProvider) {
           $stateProvider
               .state('app.user.map', {
                  url: '/map',
                  data: {
                     showOnMenu: false,
                     displayName: '地图'
                  },
                  views: {
                     '': {
                        templateUrl: 'app/map/map.tpl.html',
                        controller: LoginCtrl
                     }
                  }
               });
        }
    ]);
;angular
    .module('itms.planning.adjustment', [
        'ui.router',
        'ui.bootstrap',
        'itms.planning.common'
    ])
    .config(['$stateProvider', function ($stateProvider) {
        $stateProvider
            .state('app.user.planning.adjustment', {
                url: '/adjust',
                data: {
                    displayName: '分配调整'
                },
                views: {
                    '@app.user': {
                        templateUrl: 'app/planning/adjustment/adjustment.tpl.html',
                        controller: 'EOAssignAdjustCtrl'

                    }
                }
            });
    }]);
;angular
    .module("itms.planning.assignment", [
        "ui.router",
        "ui.bootstrap",
        "itms.planning.common"
    ])
   .config(["$stateProvider", function ($stateProvider) {
      $stateProvider
         .state("app.user.planning.assignment", {
            "url": "/assignment",
            "data": {
               displayName: "需求分配"
            },
            "views": {
               "@app.user": {
                  templateUrl: "app/planning/assignment/assignment.tpl.html",
                  controller: "EOAssignCtrl"
               }
            }
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
               
            
            
            
            
            

         });
   }]);
;angular
    .module("itms.planning.erPlanibm", [
        "ui.router",
        "ui.bootstrap",
        "itms.planning.common"
    ])
   .config(["$stateProvider", function ($stateProvider) {
      $stateProvider
         .state("app.user.planning.erPlanibm", {
             "url": "/erPlan",
            "data": {
               displayName: "资源计划"
            },
            "views": {
               "@app.user": {
                   templateUrl: "app/planning/erPlanibm/erPlanibm.tpl.html",
                   controller: "erPlanibmCtrl"
               }
            }
         });
   }]);
;angular
    .module('itms.planning', [
        'itms.planning.adjustment',
        'itms.planning.assignment',
        'itms.planning.erPlanibm'
    ])
    .config(['$stateProvider',
        function($stateProvider) {
            $stateProvider
                .state('app.user.planning', {
                    abstract: true,
                    url: '/planning',
                    data: {
                        displayName: '计划'
                    },
                    
                    controller: ['$scope', '$state', 'contacts', 'utils',
                        function($scope, $state, contacts, utils) {

                        }
                    ]
                });

        }
    ]);
angular.module('itms.planning.common', []);

;angular.module('itms.requirement.create',[
        'ui.router',
        'ui.bootstrap'
    ])
    .config(['$stateProvider', function($stateProvider){
        $stateProvider
            .state('app.user.requirement.create',{
                url: '/create',
                data: {
                    displayName: '新建需求'
                },
                views: {
                    '@app.user': {
                        templateUrl: 'app/requirement/create/lotusNewER.html',
                        controller: function($scope){
                        }
                    }
                }
            })
    }]);
;angular
    .module('itms.requirement', [
        'itms.requirement.upload',
        'itms.requirement.uploadibm',
        'itms.requirement.create'
    ])
    .config(['$stateProvider',
        function($stateProvider) {
            $stateProvider
                .state('app.user.requirement', {
                    abstract: true,
                    data: {
                        displayName: '需求管理'
                    },
                    url: '/requirement'
                });

        }
    ]);
;angular
    .module('itms.requirement.upload', [
        'ui.router',
        'ui.bootstrap'
    ])
    .config(['$stateProvider', function ($stateProvider) {
        $stateProvider
            .state('app.user.requirement.upload', {
                url: '/upload',
                data: {
                    displayName: '需求上载'
                },
                views: {
                    '@app.user': {
                        templateUrl: 'app/requirement/upload/requirementUpload.tpl.html',
                        controller: 'requirementUploadCtrl'

                    }
                }
            });
    }]);
;angular
    .module('itms.requirement.uploadibm', [
])
    .config(['$stateProvider', function ($stateProvider) {
        $stateProvider
            .state('app.user.requirement.uploadibm', {
                url: '/upload2',
                data: {
                    displayName: '海通需求上载'
                },
                views: {
                    '@app.user': {
                        templateUrl: 'app/requirement/upload_ibm/requirementUpload2.tpl.html',
                        controller: 'requirementUploadIbmCtrl'

                    }
                }
            });
    }]);
;angular
    .module('itms.transport.eoMaintain', [
        'ui.router',
        'ui.bootstrap'
    ])
    .config(['$stateProvider', function ($stateProvider) {
        $stateProvider
            .state('app.user.transport.eoMaintain', {
                url: '/eoMaintain',
                data: {
                    displayName: '运单查询/维护'
                },
                views: {
                    '@app.user': {
                        templateUrl: 'app/transport/eoMaintain/eoMaintainSearch.tpl.html',
                        controller: 'EOMaintainSearchCtrl'
                    }
                }
            });
    }]);
;angular
    .module('itms.transport.eoMaintainMap', [
        'ui.router',
        'ui.bootstrap'
    ])
    .config(['$stateProvider', function ($stateProvider) {
       $stateProvider
           .state('app.user.transport.eoMaintainMap', {
              url: '/eoMaintainMap',
              data: {
                 displayName: '运单查询/维护'
              },
              views: {
                 '@app.user': {
                    templateUrl: 'app/transport/eoMaintainMap/eoMaintainMap.tpl.html',
                    controller: 'eoMaintainMapCtrl'
                 }
              }
           });
    }]);
;angular
    .module('itms.transport.eoMaintainibm', [
        'ui.router',
        'ui.bootstrap'
    ])
    .config(['$stateProvider', function ($stateProvider) {
        $stateProvider
        
            .state('app.user.transport.eoMaintainibm', {
                url: '/eoMaintain2',
                data: {
                    displayName: '运单查询/维护'
                },
                views: {
                    '@app.user': {
                        templateUrl: 'app/transport/eoMaintainibm/eoMaintainibm.tpl.html',
                        controller: 'eoMaintainibmCtrl'
                    }
                }
            });
    }]);
;angular
    .module('itms.transport.event', [
        'ui.router',
        'ui.bootstrap'
    ])
    .config(['$stateProvider', function ($stateProvider) {
       $stateProvider
           .state('app.user.transport.event', {
              url: '/event',
              data: {
                 displayName: '运单事件'
              },
              views: {
                 '@app.user': {
                    templateUrl: 'app/transport/event/event.tpl.html',
                    controller: 'EventMaintenanceCtrl'
                 }
              },
              resolve: {
                 eolist:
                     function () {
                        return [];
                        
                        
                        
                     }
              }
           })
           .state('app.user.transport.eventSearch', {
              url: '/eventSearch',
              data: {
                 displayName: '事件查询'
              },
              views: {
                 '@app.user': {
                    templateUrl: 'app/transport/event/eventSearch.tpl.html',
                    controller: 'EventSearchCtrl'
                 }
              }
           })
           .state('app.user.transport.eventSearch.search', {
              "abstract": true,
              "url": ''
           })
           .state('app.user.transport.eventSearch.search.searchByEvent', {
              url: '',
              views: {
                 'search@app.user.transport.eventSearch': {
                    templateUrl: 'app/transport/event/eventquicksearch.tpl.html'
                 }
              }
           })
           .state('app.user.transport.eventSearch.search.searchByEr', {
              views: {
                 'search@app.user.transport.eventSearch': {
                    templateUrl: 'app/transport/event/ereventsearch.tpl.html'
                 }
              }
           })
           .state('app.user.transport.eventSearch.search.searchByEo', {
              views: {
                 'search@app.user.transport.eventSearch': {
                    templateUrl: 'app/transport/event/eoeventsearch.tpl.html'
                 }
              }
           });
    }]);
;angular
    .module('itms.transport.myElectricOrder', [])
    .config(['$stateProvider', function ($stateProvider) {
        $stateProvider
            .state('app.user.transport.myElectricOrder', {
                url: '/myElectricOrder',
                data: {
                    displayName: '运单查询/我的运单'
                },
                views: {
                    '@app.user': {
                        templateUrl: 'app/transport/myElectricOrder/myElectric.tpl.html',
                        controller: 'MyElectricOrderCtrl'
                    }
                }
            });
    }]);
;angular
    .module('itms.transport', [
        'itms.transport.event',
        'itms.transport.eoMaintain',
        'itms.transport.myElectricOrder',
        'itms.transport.eoMaintainibm',
        'itms.transport.eoMaintainMap'
    ])
    .config(['$stateProvider',
        function ($stateProvider) {
           $stateProvider
               .state('app.user.transport', {
                  "abstract": true,
                  url: '/transport',
                  data: {
                     displayName: '运输执行'
                  }
               });

        }
    ]);
;angular
  .module('itms', [
    'ui.router',
    'ui.bootstrap',
    'ngCookies',
    'angular-loading-bar',
    'common',
    'itms.auth',
    'itms.transport',
    'itms.planning',
    'itms.requirement',
    'itms.common',
    'itms.dashboard',
    'itms.login',
     'itms.map'
  ])
  .run(['$rootScope', '$state', '$stateParams', '$log', '$location', 'auth', bootstrap])
  .config(['$urlRouterProvider', '$stateProvider', '$locationProvider', routerConfig]);



function httpConfig($httpProvider) {
   $httpProvider.interceptors.push('authInterceptor');
}

angular.module('itms')
  .factory('authInterceptor', ['$rootScope', function ($rootScope) {
     return {
        request: function (config) {
           config.headers = config.headers || {};
           if ($rootScope.currentUser) {
              config.headers.Authorization = $rootScope.currentUser;
           }
           return config;
        }
     };
  }]);

function routerConfig($urlRouterProvider, $stateProvider, $locationProvider) {
   
   
   
   
   
   
   $stateProvider
     .state('app', {
        abstract: true,
        template: '<div data-ui-view></div>'
     })
     .state('app.user', {
        abstract: true,
        templateUrl: 'app/layout/shell.html',
        controller: 'shellCtrl'
     });
}

function bootstrap($rootScope, $state, $stateParams, $log, $location, auth) {
   $rootScope.$state = $state;
   $rootScope.$stateParams = $stateParams;
   $log.info('app start');

   if (auth.isLoginRequired()) {
      if ($state.current && $state.current.name && $state.current.name === 'app.login')
         return;
      else
         $state.go('app.login');
   }
   else if ($location.$$path === '') {
      $state.go('app.user.dashboard');
   }
}
;angular
    .module('itms.auth', [])
    .factory('Base64', function () {
        

        var keyStr = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';

        return {
            encode: function (input) {
                var output = "";
                var chr1, chr2, chr3 = "";
                var enc1, enc2, enc3, enc4 = "";
                var i = 0;

                do {
                    chr1 = input.charCodeAt(i++);
                    chr2 = input.charCodeAt(i++);
                    chr3 = input.charCodeAt(i++);

                    enc1 = chr1 >> 2;
                    enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
                    enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
                    enc4 = chr3 & 63;

                    if (isNaN(chr2)) {
                        enc3 = enc4 = 64;
                    } else if (isNaN(chr3)) {
                        enc4 = 64;
                    }

                    output = output +
                        keyStr.charAt(enc1) +
                        keyStr.charAt(enc2) +
                        keyStr.charAt(enc3) +
                        keyStr.charAt(enc4);
                    chr1 = chr2 = chr3 = "";
                    enc1 = enc2 = enc3 = enc4 = "";
                } while (i < input.length);

                return output;
            },

            decode: function (input) {
                var output = "";
                var chr1, chr2, chr3 = "";
                var enc1, enc2, enc3, enc4 = "";
                var i = 0;

                
                var base64test = /[^A-Za-z0-9\+\/\=]/g;
                if (base64test.exec(input)) {
                    window.alert("There were invalid base64 characters in the input text.\n" +
                        "Valid base64 characters are A-Z, a-z, 0-9, '+', '/',and '='\n" +
                        "Expect errors in decoding.");
                }
                input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");

                do {
                    enc1 = keyStr.indexOf(input.charAt(i++));
                    enc2 = keyStr.indexOf(input.charAt(i++));
                    enc3 = keyStr.indexOf(input.charAt(i++));
                    enc4 = keyStr.indexOf(input.charAt(i++));

                    chr1 = (enc1 << 2) | (enc2 >> 4);
                    chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
                    chr3 = ((enc3 & 3) << 6) | enc4;

                    output = output + String.fromCharCode(chr1);

                    if (enc3 != 64) {
                        output = output + String.fromCharCode(chr2);
                    }
                    if (enc4 != 64) {
                        output = output + String.fromCharCode(chr3);
                    }

                    chr1 = chr2 = chr3 = "";
                    enc1 = enc2 = enc3 = enc4 = "";

                } while (i < input.length);

                return output;
            }
        };

        
    })
    .factory('auth', ['$http', '$q', 'config', 'identity', auth]);

function auth($http, $q, config, identity) {

    var url = config.baseUrl + 'auth/login',
        authUrl = config.baseUrl + 'auth/getAuth';

    return {
        isLoginRequired: isLoginRequired,
        logon: logon,
        getAuth: getAuth
    };

    function isLoginRequired() {
        return identity.currentUser === undefined;
    }

    function logon(username, password) {
        var dfd = $q.defer();
        $http.postXSRF(url, {username: username, password: password})
            .success(function (userInfo) {
                if (userInfo.errorMessage) {
                    dfd.resolve({success: false, message: userInfo.errorMessage});
                } else {
                    identity.currentUser = userInfo;
                    dfd.resolve({success: true, result: userInfo});
                }
            });
        return dfd.promise;
    }

    function getAuth(userId) {
        var dfd = $q.defer();
        $http.postXSRF(authUrl, {userID: userId})
            .success(function (authInfo) {
                if (authInfo.errorMessage) {
                    dfd.resolve({success: false, message: authInfo.errorMessage});
                } else {
                    identity.currentUser.auth = authInfo[0];
                    dfd.resolve({success: true});
                }
            });
        return dfd.promise;
    }
};angular
    .module('itms.common', [])
    .factory('notifier', function () {

       var defaultOption = {
          timeout: 4000,
          successIcon: "fa fa-check fa-2x fadeInRight animated",
          successColor: "#659265",
          successTitle: "操作成功",
          cancelIcon: "fa fa-times fa-2x fadeInRight animated",
          cancelColor: "#C46A69",
          cancelTitle: "操作取消"
       };

       return {
          success: success,
          cancel: cancel
       };

       function success(message) {
          $.smallBox({
             title: defaultOption.successTitle,
             content: "<i class='fa fa-clock-o'></i> <i> " + message + " </i>",
             color: defaultOption.successColor,
             iconSmall: defaultOption.successIcon,
             timeout: defaultOption.timeout
          });
       }

       function cancel(message) {
          message = message || "操作取消...";
          $.smallBox({
             title: defaultOption.cancelTitle,
             content: "<i class='fa fa-clock-o'></i> <i> " + message + " </i>",
             color: defaultOption.cancelColor,
             iconSmall: defaultOption.cancelIcon,
             
          });
       }
    })
    .factory('fileHelper', function () {
       return {
          getExtName: function (name) {
             var index = name.lastIndexOf(".");
             return index < 0 ? "" : name.substring(index + 1).toLowerCase();
          }
       };
    })
    .factory('common', ['$q', 'notifier', 'fileHelper', common])
   .factory('dateTimeHelper', dateTimeHelper);

function dateTimeHelper() {
   var formatDate = function (dt) {
      if (!dt) return "";
      return moment(dt).format("YYYY-MM-DD");
   };
   var formatTime = function (dt) {
      if (!dt) return "";
      return moment(dt).format("HH:mm A");
   };
   var format = function (value, currentFormat, newFormat) {
      if (!value) return "";
      return moment(value, currentFormat).format(newFormat);
   };

   var mergeDateTime = function (date, time, sourceFormat, targetFormat) {
      if (!date) return "";
      if (!time) time = "12:00 AM";
      var dt = date + " " + time;
      sourceFormat = sourceFormat || "YYYY-MM-DD HH:mm A";
      targetFormat = targetFormat || "YYYY-MM-DD HH:mm:ss";
      return moment(dt, sourceFormat).format(targetFormat);
   };
   return {
      formatDate: formatDate,
      formatTime: formatTime,
      mergeDateTime: mergeDateTime,
      format: format
   };
}

function common($q, notifier, fileHelper) {

   return {
      notifier: notifier,
      fileHelper: fileHelper,
      messageBox: messageBox
   };

   function messageBox(option) {
      var confirm = option.confirm,
          cancel = option.cancel;
      if (!confirm && !cancel) {
         confirm = "是";
         cancel = "否";
      }
      var formatButton = function (text) {
         return text ? ("[" + text + "]") : "";
      };
      var defaultOption = {
         buttons: formatButton(cancel) + formatButton(confirm)
      };
      angular.extend(option, defaultOption);
      var deferred = $q.defer();
      $.SmartMessageBox(option, function (selection, value) {
         if (selection === confirm) {
            deferred.resolve(value);
         }
         if (selection === cancel) {
            deferred.reject(value);
         }
      });
      return deferred.promise;
   }


}


angular.module("itms.common")
    .factory("configService", ["$http", "$q", "config", configService])
    .factory("timelineService", ['$http', 'config', timelineService])
    .factory("eoDetailService", ['$http', '$q', 'config', 'dateTimeHelper', 'configService', eoDetailService])
    .factory("exportService", [exportService]);

function exportService() {
   var exportToExcel = function (columns, result) {
      var dataobj = result;
      $("#btnExport").battatech_excelexport({
         containerid: "btnExport"
          , datatype: 'json'
          , dataset: dataobj
          , columns: convertToExportedColumn(columns)
      });
   };
   return {
      "export": exportToExcel
   };
}

function convertToExportedColumn(columns) {
   var result = [];
   columns.forEach(function (value, index) {
      if (index == 0) return false;
      if (value.sTitle == '&nbsp;明细&nbsp;') return false;
      var newItem = { headertext: value.sTitle, datatype: "string", datafield: value.mData, ishidden: false };
      result.push(newItem);
   });
   return result;
}

function configService($http, $q, config) {
   var getEmptyCriteria = function () {

      return {
         "Code": null,
         "ConType": [],
         "Group1": null,
         "Group2": null,
         "Group3": null,
         "Language": ["ZHCN"]
      };
   };


   var criteria = getEmptyCriteria();

   var getConfig = function (type, code, group1, group2) {
      criteria = getEmptyCriteria();
      criteria.ConType = [type];
      if (code) criteria.Code = code;
      if (group1) criteria.Group1 = group1;
      if (group2) criteria.Group2 = group2;
      return $http({
         method: "GET",
         url: config.baseUrl + "Config/ConSearch" + "?" + $.param(criteria),
         dataType: "json"
      });

   };

   var getConfigs = function (configs) {
      var promises = {};
      for (var name in configs) {
         promises[name] = getConfig(name);
      }
      return $q.all(promises).then(
          function (result) {
             for (name in configs) {
                configs[name] = result[name].data;
             }
          }).then(function () {

          });
   };

   var getMaterial = function (option) {
      var param = {
         "SerType": "AND",
         "matnr": [""],
         "type": [],
         "cusmatnr": [""],
         "tag": [""],
         "customer": [""],
         "description": [""],
         "Owner": "",
         "LoadWgt": "",
         "LoadWgtWarning": "",
         "Speed": "",
         "Vol": "",
         "VolWarning": "",
         "SpecialTag1": "",
         "SpecialTag2": "",
         "SpecialTag3": "",
         "PckType": "",
         "Length": "",
         "Width": "",
         "High": "",
         "NetWeight": "",
         "GrossWeight": "",
         "StaQty": "",
         "DefaultPack": "",
         "vendor": "",
         "vendorlocation": "",
      };
      if (option.type)
         param.type.push(option.type);
      else {
         param.type = [""];
      }

      if (option.owner)
         param.Owner = option.owner;

      if (option.Owner)
         param.Owner = option.Owner;

      if (option.matnr)
         param.matnr[0] = option.matnr;
      if (option.description)
         param.description[0] = option.description;

      if (option.LoadWgt)
         param.LoadWgt = option.LoadWgt;

      if (option.Speed)
         param.Speed = option.Speed;
      if (option.Vol)
         param.Vol = option.Vol;
      if (option.SpecialTag1)
         param.SpecialTag1 = option.SpecialTag1;

      return $http({
         method: "GET",
         url: config.baseUrl + "search/Material" + "?" + $.param(param),
         dataType: "json"
      });
   };



   var getRoute = function (option) {
      var param = {
         "SerType": "AND",
         RouteID: "",
         RouteDesc: "",
         TRType: "",
         RouteOrigin: "",
         RouteOriginDesc: "",
         RouteDest: "",
         RouteDesiDesc: "",
         Distance1: "",
         Distance2: "",
         Distance3: "",
         AvgDuration1: "",
         AvgDuration2: "",
         AvgDuration3: "",
         avgCost1: "",
         avgCost2: "",
         avgCost3: "",
         trVendor: "",
         TRmode: "",
         SpecTag: "",
         Route: [],
      };
      if (option)
         $.extend(param, option);

      return $http({
         method: "GET",
         url: config.baseUrl + "search/Route" + "?" + $.param(param),
         dataType: "json"
      });
   };

   return {
      "getConfig": getConfig, "getConfigs": getConfigs,
      "getMaterial": getMaterial,
      "getRoute": getRoute,
   };
}

function timelineService($http, config) {
   var searchUrl = config.baseUrl + 'EO/EventSearch';

   return {
      getEventTimeLine: getEventTimeLine
   };

   function getEventTimeLine(options) {
      var queryOption = {
         serType: 'AND',
         createUser: '',
         eventType: [''],
         eventCode: '',
         eventListener1: '',
         eventListener2: '',
         eventListener3: '',
         eventListener4: '',
         EO: [options['eo']],
         ERID: [options['er']],
         ERITN: [options['eritn']],
         eventStatus: [''],
         resEventID: [''],
         memo: ''
      };
      return $http.postXSRF(searchUrl, queryOption);
   }

}

function eoDetailService($http, $q, config, dateTimeHelper, configService) {

   var searchUrl = config.baseUrl + 'EO/EOQuickSearch';
   var emoChangeUrl = config.baseUrl + 'EO/EOMChange';
   return {
      getEoDetail: getEoDetail,
      getAllConfigData: getAllConfigData,
      save: save
   };

   function getAllConfigData() {
      return $q.all([
          configService.getConfig('ERTP'),
          configService.getConfig('TRPY'),
          configService.getConfig('ERTG'),
          configService.getConfig('EOST'),
          configService.getConfig('EVST')
      ]).then(function (results) {
         var result = {};
         angular.forEach(results, function (res) {
            var confType = getConfType(res.data);
            result[confType] = res.data;
         });
         return result;
      });

      function getConfType(configs) {
         return configs[0].conType;
      }
   }


   function getEoDetail(queryOptions) {
      var data = {
         SerType: 'AND',
         EOStatus: [''],
         eventstatus: [''],
         EO: [queryOptions['eoid']],
         EOType: [''],
         EOTRType: [''],
         EOTag: [''],
         ERTag: "",
         EOTRVendor1: '',
         EOTRVendor2: '',
         EOTRVendor3: '',
         MesUnit1: '',
         reqDelDate: '',
         dep_Country: '',
         dep_State: '',
         dep_City: '',
         dep_Disc: '',
         dep_Group1: '',
         dep_Group2: '',
         rec_Country: '',
         rec_State: '',
         rec_City: '',
         rec_Disc: '',
         rec_Group1: '',
         rec_Group2: '',
         customerOrder1: '',
         customerOrder2: '',
         customerOrder3: '',
         VendorOrder1: '',
         VendorOrder2: '',
         VendorOrder3: '',
         reqDelDate1: '',
         reqDelDate2: '',
         reqDelDate3: '',
         reqDelDate4: '',
         ScheduleVendor1: '',
         ScheduleClass1: '',
         DepDate1: '',
         ArrDate1: '',
         DepTime1: '',
         Arrtime1: '',
         DeliverBP1: '',
         DeliverBP2: '',
         depCustomer: '',
         depLocCode: '',
         BP1: "",
         BP2: "",
         BP3: ""
      };
      return $http.postXSRF(searchUrl, data);
   }

   function save(data) {
      var eodetail = eoDataMapping(data);

      return $http.postXSRF(emoChangeUrl, eodetail);
   }

   function eoDataMapping(data) {
      return {
         EO: [data.dn.eo],
         userID: config.userID,
         EOStatus: data.dn.eoStatus,
         EOType: data.dn.eotype,
         EOTRType: data.dn.eotrtype,
         EOTag: data.dn.eotag,
         EOTRVendor1: data.dn.eotrvendor1,
         EOTRVendor2: data.dn.eotrvendor2,
         EOTRVendor3: data.dn.eotrvendor3,
         customerOrder1: data.dn.customerOrder1,
         customerOrder2: data.dn.customerOrder2,
         customerOrder3: data.dn.customerOrder3,
         VendorOrder1: data.dn.vendorOrder1,
         VendorOrder2: data.dn.vendorOrder2,
         VendorOrder3: data.dn.vendorOrder3,
         reqDelDate1: data.dn.reqDelDate1,
         reqDelDate2: data.dn.reqDelDate2,
         reqDelDate3: data.dn.reqDelDate3,
         reqDelDate4: data.dn.reqDelDate4,
         DeliverBP1: data.dn.deliverBP1,
         DeliverBP2: data.dn.deliverBP2,
         DeliverBP3: data.dn.deliverBP3,
         ScheduleVendor1: data.dn.scheduleVendor1,
         ScheduleVendor2: data.dn.scheduleVendor2,
         ScheduleVendor3: data.dn.scheduleVendor3,
         ScheduleClass1: data.dn.scheduleClass1,
         ScheduleClass2: data.dn.scheduleClass2,
         ScheduleClass3: data.dn.scheduleClass3,
         DepDate1: data.dn.depDate1,
         DepDate2: data.dn.depDate2,
         DepDate3: data.dn.depDate3,
         ArrDate1: data.dn.arrDate1,
         ArrDate2: data.dn.arrDate2,
         ArrDate3: data.dn.arrDate3,
         DepTime1: '',
         DepTime2: '',
         DepTime3: '',
         Arrtime1: dateTimeHelper.format(data.dn.arrTime1, 'HH:mm A', 'HH:mm:ss'),
         Arrtime2: dateTimeHelper.format(data.dn.arrTime2, 'HH:mm A', 'HH:mm:ss'),
         Arrtime3: dateTimeHelper.format(data.dn.arrTime3, 'HH:mm A', 'HH:mm:ss'),
         memo: data.dn.memo,
         "BP1": "",
         "BP2": "",
         "BP3": "",
         "project": "",
         "plannedID": ""
      };
   }
};angular
    .module('itms.common')
    .controller('EODetailCtrl', ['$scope', '$modalInstance', 'common', 'eoDetailService', 'eoService', 'dateTimeHelper', 'data', EODetailCtrl]);

function EODetailCtrl($scope, $modalInstance, common, eoDetailService, eoService, dateTimeHelper, data) {

   activate();


   function activate() {
      var queryOption = {};
      if (data.eoid) {
         queryOption['eoid'] = data.eoid;
      } else if (data.requirementDetail) {
         queryOption['eoid'] = data.requirementDetail.pk.eoID;
      } else if (data.eoID) {
         queryOption['eoid'] = data.eoID;
      } else if (data.eo) {
         queryOption['eoid'] = data.eo;
      }

      eoDetailService.getAllConfigData().then(function (result) {
         $scope.configData = result;
      });


      $scope.data = {};
      eoDetailService.getEoDetail(queryOption).then(function (result) {
         console.log(result);
         if (result.data.errorMessage) {
            $scope.data = {};
         } else {
            $scope.data = result.data[0];

            var dateToFormat = ["reqDelDate1", "reqDelDate2", "reqDelDate3", "reqDelDate4", "depDate1", "depDate1act", "arrDate1", "arrDate1act"];
            dateToFormat.forEach(
               function (key) {
                  $scope.data.dn[key] = dateTimeHelper.formatDate($scope.data.dn[key]);
               }
            );

            var timeToFormat = ["reqDelTime1", "reqDelTime2", "reqDelTime3", "reqDelTime4", "depTime1", "detTime1act", "arrtime1", "arrtime1act"];
            timeToFormat.forEach(
               function (key) {
                  $scope.data.dn[key] = dateTimeHelper.formatTime($scope.data.dn[key]);
               });
         }
      });
   }

   $scope.event = {
      eventType: '',
      eventDate: dateTimeHelper.formatDate(new Date()),
      eventTime: dateTimeHelper.formatTime(new Date()),
      eventCode: "",
      memo: '',
      reset: function () {
         var date = dateTimeHelper.formatDate(new Date());
         var time = dateTimeHelper.formatTime(new Date());
         this.eventDate = date;
         this.eventTime = time;
         this.eventCode = '';
         this.eventType = '';
         this.memo = '';
      }
   };
   $scope.save = function (tempData) {
      
      
      tempData.BP1 = "";
      tempData.BP2 = "";
      tempData.BP3 = "";

      eoDetailService.save(tempData).success(function (result) {
         $modalInstance.close(result);
      });
   };
   $scope.codes = [];
   $scope.types = [
       {
          value: 'DELY',
          text: '延迟事件'
       },
       {
          value: 'NORM',
          text: '正常事件'
       },
       {
          value: 'UNRP',
          text: '未报告事件'
       },
       {
          value: 'UNXP',
          text: '未期事件'
       }
   ];

   $scope.getEventCode = function (eventType) {
      eoService.getEventCode(eventType)
          .success(function (tempData) {
             $scope.codes = _.map(tempData, function (item) {
                return {
                   value: item.group2,
                   text: item.description
                };
             });
          });
   };

   $scope.ok = function () {
      var dt = dateTimeHelper.mergeDateTime($scope.event.eventDate, $scope.event.eventTime);
      eoService
          .createEvent({
             eventType: $scope.event.eventType,
             eventCode: $scope.event.eventCode,
             eventDateTime: dt,
             memo: $scope.event.memo,
             EO: [$scope.data.dn.eo || '-1'],
             ERID: [$scope.data.erItem.pk.erID],
             ERITN: [$scope.data.erItem.pk.erITN]
          })
          .success(function () {
             common.notifier.success("创建成功...");
             $scope.event.reset();
          });
   };

};angular.module("itms.common")
    .controller("erDetailCtrl", ["$scope",
        "$http", "$q", "$modalInstance", "config", "common", "configService", "eoService", "dateTimeHelper", erDetailCtrl]);

function erDetailCtrl($scope, $http, $q, $modalInstance, config, common, configService, eoService, dateTimeHelper, data) {
   var queryOption;
   
   
   if (data && data.requirementDetail) {
      queryOption = {
         "erID": data.requirementDetail.pk.erID,
         "erITN": data.requirementDetail.pk.erITN,
         "eoID": data.requirementDetail.eoid
      };
   } else {
      queryOption = {
         "erID": data.erID || data['erid'],
         "erITN": data.erITN || data['eritn']
      };
   }
   if (data && (data.eoID || data.eoid || data.eo)) {
      queryOption['eoID'] = data.eoID || data.eoid || data.eo;
   }

   var param = {
      SerType: "AND",
      userID: "",
      depAreaCode: '',
      depCustomer: '',
      depLocCode: '',
      recCustomer: '',
      recLocCode: '',
      createDate: '',
      ERType: [''],
      ERITNStatus: [""],
      customerOrder1: '',
      customerOrder2: '',
      customerOrder3: '',
      ERTag: [''],
      MesUnit1: '',
      reqDelDate: '',
      dep_Country: '',
      dep_State: '',
      dep_City: '',
      dep_Disc: '',
      dep_Group1: '',
      dep_Group2: '',
      rec_Country: '',
      rec_State: '',
      rec_City: '',
      rec_Disc: '',
      rec_Group1: '',
      rec_Group2: '',
      ERID: [queryOption['erID']],
      ERITN: [queryOption['erITN']],
      ERTRType: [""],
      ERStatus: [""],
      project: "",
      plannedID: "",
      OMSOrderID: "",
      contractID: "",
      pickERDate: "",
      ERTRVendor: "",
      BP1: "",
      BP2: "",
      BP3: "",
      TransResPlanTag: "",
      ItemSplitPlan: "",
      RoutePlanTag: "",
      PackNum: "",
      PackNum2: "",
      PackNum3: "",
      SubPackNum: "",
      SubPackNum2: "",
      SubPackNum3: "",
      vendor: "",
      MatIID: "",
      customerMatID: "",
      RouteID: "",
      RouteClassName: "",
      RouteClassID: "",
      TranResType: "",
      TranResID: "",
      TranResLicense: "",
      TransDriverID: "",
      TrVendor: "",
      resType1: "",
      resID1: "",
      resType2: "",
      resID2: "",
      resType3: "",
      resID3: "",
      ResAmtCS1: "",
      ResAmtCS2: "",
      ResAmtCS3: "",
      EOID: ""
   };

   var configData = {
      "ERST": null,
      "ERNT": null,
      "ERTP": null,
      "TRPY": null,
      "ERTG": null,
      "PKST": null
   };
   $scope.configs = {};
   configService.getConfigs(configData).then(
       function () {
          $.extend($scope.configs, configData);
       }
   );


   $scope.basicData = {};
   $http.postXSRF(config.baseUrl + "ER/ERQuickSearch", param)
       .then(function (result) {
          data = result.data[0];
       })
       .then(function () {
          if (data) {
             formatData(data);
             $scope.basicData = data;
          }
       });

   configService.getMaterial({ "type": "TRES" }).then(
       function (result) {
          $scope.configs.material = result.data;
       }
   );


   function formatData(result) {
      result.requirement.resMemo = "";
      var dateToFormat = ["recERDate", "pickERDate", "oprERDate", "reqDelDate", "createDate"];
      dateToFormat.forEach(
         function (key) {
            result.requirement[key] = dateTimeHelper.formatDate(result.requirement[key]);
         }
      );

      var timeToFormat = ["recERTime", "pickERStartTime", "oprERFinishTime", "reqDelTimeE",
         "LoadERTimeF", "LoadERTimeS", "createTime", "loadERStartTime", "oprERFinishUnloadTime", "oprERTimeULF",
      "oprERTimeULS", "oprERStartTime", "oprERStartUnloadTime", "oprERTimeS", "pickERFinishTime", "pickERTimeF", "loadERFinishTime"];
      timeToFormat.forEach(
         function (key) {
            result.requirement[key] = dateTimeHelper.formatTime(result.requirement[key]);
         });
   };


   $scope.save = function () {
      var saveHead = function () {
         var tempData = $scope.basicData.requirement;
         var time = dateTimeHelper.format(tempData.lastChangeTime, "YYYY-MM-DD HH:mm:ss", "HH:mm:ss");

         var tempParam = {
            ERID: tempData.erID,
            ERStatus: tempData.erStatus,
            lastChangeUser: tempData.lastChangeUser,
            lastChangeDate: tempData.lastChangeDate,
            lastChangeTime: time,
            ERType: tempData.erType,
            ERTRType: tempData.erTRType,
            ERTRTypeSM: tempData.ertrtypeSM,
            ERTag: tempData.erTag,
            ERTRVendor: tempData.ertrvendor,
            ERTRVendorSM: tempData.ertrvendorSM,
            preERID: tempData.preERID,
            preEOID: tempData.preEOID,
            customerOrder1: tempData.customerOrder1,
            customerOrder2: tempData.customerOrder2,
            customerOrder3: tempData.customerOrder3,
            preCustomerOrder1: tempData.preCustomerOrder1,
            preCustomerOrder2: tempData.preCustomerOrder2,
            preCustomerOrder3: tempData.preCustomerOrder3,
            totalAmt: tempData.totalAmt,
            totalWgt: tempData.totalWgt,
            totalVol: tempData.totalVol,
            totalVolWgt: tempData.totalVolWgt,
            resType1: tempData.resType1,
            ResAmt1: tempData.resAmt1,
            resType2: tempData.resType2,
            ResAmt2: tempData.resAmt2,
            resType3: tempData.resType3,
            ResAmt3: tempData.resAmt3,
            memo: tempData.memo,
            reqDelDate: tempData.reqDelDate,
            reqDelTimeE: tempData.reqDelTimeE,
            reqDelTimeL: tempData.reqDelTimeL,
            recERDate: tempData.recERDate,
            recERTime: tempData.recERTime,
            pickERDate: tempData.pickERDate,
            pickERTimeS: tempData.pickERStartTime,
            pickERTimeF: tempData.pickERFinishTime,
            LoadERTimeS: tempData.loadERStartTime,
            LoadERTimeF: tempData.loadERFinishTime,
            oprERDate: tempData.oprERDate,
            oprERTimeULS: tempData.oprERStartUnloadTime,
            oprERTimeULF: tempData.oprERFinishUnloadTime,
            oprERTimeS: tempData.oprERStartTime,
            oprERTimeF: tempData.oprERFinishTime,
            depAreaCode: tempData.depAreaCode,
            depCustomer: tempData.depCustomer,
            depCustomerContact: tempData.depCustomerContact,
            depCustomerEmail: tempData.depCustomerEmail,
            depCustomerPhone: tempData.depCustomerPhone,
            depLocCode: tempData.depLocCode,
            depMemo: tempData.depMemo,
            recCustomer: tempData.recCustomer,
            recCustomerContact: tempData.recCustomerContact,
            recCustomerEmail: tempData.recCustomerEmail,
            recCustomerPhone: tempData.recCustomerPhone,
            recLocCode: tempData.recLocCode,
            recMemo: tempData.recMemo,
            ResMemo: tempData.resMemo,
            
            "BP1": "",
            "BP2": "",
            "BP3": "",
            "project": tempData.project,
            "plannedID": tempData.plannedID
         };
         var timeToFormat = [
               "reqDelTimeE",
               "reqDelTimeL",
               "recERTime",
               "pickERTimeS",
               "pickERTimeF",
               "LoadERTimeS",
               "LoadERTimeF",
               "oprERTimeULS",
               "oprERTimeULF",
               "oprERTimeS",
               "oprERTimeF"
         ];
         timeToFormat.forEach(
            function (key) {
               tempParam[key] = dateTimeHelper.format(tempParam[key], 'HH:mm A', 'HH:mm:ss');
            });
         return $http.postXSRF(config.baseUrl + "ER/ERChange", tempParam);
      };
      var saveItem = function () {
         var tempData = $scope.basicData.requirementDetail;
         var time = dateTimeHelper.format(tempData.lastChangeTime, "YYYY-MM-DD HH:mm:ss", "HH:mm:ss");

         var tempParam = {


            ERID: tempData.pk.erID,
            ERITN: tempData.pk.erITN,
            ERITNStatus: tempData.ERITNStatus,
            EOID: tempData.eoid,
            lastChangeUser: tempData.lastChangeUser,
            lastChangeDate: tempData.lastChangeDate,
            lastChangeTime: time,
            ERITNType: tempData.erITNType,
            ERITNTag: tempData.erITNTag,
            Status: tempData.status,
            MatIID: tempData.matIID,
            customerMatID: tempData.customerMatID,
            customerOrder2: tempData.customerOrder2,
            Amt: tempData.amt,
            Wgt: tempData.wgt,
            Vol: tempData.vol,
            VolWgt: tempData.volWgt,
            "long": tempData.longe,
            width: tempData.width,
            height: tempData.height,
            PackNum: tempData.packNum,
            Memo: tempData.memo,
            RouteID: tempData.routeID,
            RouteClassName: tempData.routeClassName,
            RouteClassID: tempData.routeClassID,
            TranResType: tempData.tranResType,
            TranResID: tempData.tranResID,
            TranResLicense: tempData.tranResLicense,
            TransDriverID: tempData.transDriverID,
            ResAmt1: tempData.resAmt1,
            ResAmt2: tempData.resAmt2,
            ResAmt3: tempData.resAmt3,
            ResAmtCS1: tempData.resAmtCS1,
            ResAmtCS2: tempData.resAmtCS2,
            ResAmtCS3: tempData.resAmtCS3,
            StorageLocation: tempData.storageLocation,
            DockLoaction: tempData.dockLoaction,
            PortLocation: tempData.portLocation,
            TrVendor: tempData.trVendor
         };

         return $http.postXSRF(config.baseUrl + "ER/ERItemChange", tempParam);
      };
      $q.all([saveHead(), saveItem()]).then(
          function (res) {
             if (isSuccess(res[0].data) && isSuccess(res[1].data)) {
                common.notifier.success("修改成功...");
                $modalInstance.close();
             }
          }
      );
   };

   function isSuccess(result) {
      return result && (!result.errorMessage || result.errorMessage == "OK");
   }


   $scope.event = {
      eventType: '',
      eventDate: dateTimeHelper.formatDate(new Date()),
      eventTime: dateTimeHelper.formatTime(new Date()),
      eventCode: "",
      memo: '',
      reset: function () {
         var date = dateTimeHelper.formatDate(new Date());
         var time = dateTimeHelper.formatTime(new Date());
         this.eventDate = date;
         this.eventTime = time;
         this.eventCode = '';
         this.eventType = '';
         this.memo = '';
      }
   };


   $scope.types = [
       {
          value: 'DELY',
          text: '延迟事件'
       },
       {
          value: 'NORM',
          text: '正常事件'
       },
       {
          value: 'UNRP',
          text: '未报告事件'
       },
       {
          value: 'UNXP',
          text: '未期事件'
       }
   ];

   $scope.getEventCode = function (eventType) {
      eoService.getEventCode(eventType)
          .success(function (result) {
             $scope.codes = _.map(result, function (item) {
                return {
                   value: item.group2,
                   text: item.description
                };
             });
          });
   };

   $scope.ok = function () {
      var dt = dateTimeHelper.mergeDateTime($scope.event.eventDate, $scope.event.eventTime);
      eoService
          .createEvent({
             eventType: $scope.event.eventType,
             eventCode: $scope.event.eventCode,
             eventDateTime: dt,
             
             
             memo: $scope.event.memo,
             EO: [queryOption['eoID'] || '-1'],
             ERID: [queryOption['erID']],
             ERITN: [queryOption['erITN']]
          })
          .success(function () {
             common.notifier.success("创建成功...");
             $scope.event.reset();
          });
   };

};angular
    .module('itms.common')
    .controller('TimeLineCtrl', ['$scope', 'timelineService', 'data', TimeLineCtrl]);

function TimeLineCtrl($scope, timelineService, data) {

    activate();

    function activate() {
        var queryOption = {},
            eoNumber;
        if (data.eoNumber) {
            eoNumber = data.eoNumber.split('/');
            queryOption['eo'] = eoNumber[0];
            queryOption['er'] = eoNumber[1];
            queryOption['eritn'] = eoNumber[2];
        } else if (data.requirementDetail) {
            queryOption['er'] = data.requirementDetail.pk.erID;
            queryOption['eritn'] = data.requirementDetail.pk.erITN;
        } else if (data.eoID || data.eo) {
            queryOption['eo'] = data.eoID || data.eo;
            queryOption['er'] = data.erID;
            queryOption['eritn'] = data.erITN;
        }
        timelineService.getEventTimeLine(queryOption).then(function (result) {
            if (result.data.errorMessage) {
                $scope.timelines = [];
            } else {
                $scope.timelines = result.data
            }
        });
    }

};angular
    .module('itms.auth')
    .factory('identity', function(){
        return {
            currentUser: undefined
        }
    });
;var config = {
   version: '0.0.1',
   mode: 'production', 
   baseUrl: 'http://211.144.85.15:8080/itms/rest/',
   userID: ""
};

angular
    .module('itms')
    .config(['$logProvider', configLog])
    .config(['$provide', configProvider])



    .value('config', config);


function configProvider($provide) {
   $provide.decorator('$exceptionHandler', function ($log) {
      return function (exception, cause) {
         var error = { exception: exception, cause: cause };
         $log.debug(error.exception);
         throw error;
      };
   });

   $provide.decorator('$q', function ($delegate) {
      var defer = $delegate.defer;
      $delegate.defer = function () {
         var deferred = defer();
         deferred.promise.success = function (fn) {
            deferred.promise.then(function (value) {
               fn(value);
            });
            return deferred.promise;
         };

         deferred.promise.error = function (fn) {
            deferred.promise.then(null, function (value) {
               fn(value);
            });
            return deferred.promise;
         };
         return deferred;
      };
      return $delegate;
   });

   $provide.decorator('$http', function ($delegate) {
      $delegate['postXSRF'] = function (url, data) {
         if (data) {
            for (var i in data) {
               var val = data[i];
               if ($.isArray(val) && val.length == 0) {
                  data[i] = [""];
               }
            }
         }
         return $delegate({
            method: 'POST',
            url: url,
            data: $.param(data),
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
         });
      };
      return $delegate;
   });
}

function configLog($logProvider) {
   if ($logProvider.debugEnabled) {
      $logProvider.debugEnabled(true);
   }
};angular.module('itms.dashboard')
    .controller('DashboardCtrl', function($scope) {
        $scope.module = 'iTMS';
        $scope.title = 'my iTMS';
    })
    .controller('CarouselDemoCtrl', CarouselDemoCtrl)
    .controller('CarouselDemoCtrl2', CarouselDemoCtrl2)
    .controller('CarouselDemoCtrl3', CarouselDemoCtrl3)
    .controller('CarouselDemoCtrl4', CarouselDemoCtrl4)
    .controller('CarouselDemoCtrl5', CarouselDemoCtrl5);

function CarouselDemoCtrl($scope) {
    $scope.myInterval = 5000;
    $scope.slides = [{
        image: 'img/demo/cr_event.png',
        text: 'adsf'
    }, {
        image: 'img/demo/crd-2.png',
        text: 'adsfdsadd'
    }, {
        image: 'img/demo/crb-2.png',
        text: 'adsf'
    }];
}

function CarouselDemoCtrl2($scope) {
    $scope.myInterval = 5000;
    $scope.slides = [{
        image: 'img/demo/cr_event.png',
        text: 'adsf'
    }, {
        image: 'img/demo/m6-2.png',
        text: 'adsf'
    }, {
        image: 'img/demo/m6.png',
        text: 'adsf'
    }];
}

function CarouselDemoCtrl3($scope) {
    $scope.myInterval = 5000;
    $scope.slides = [{
        image: 'img/demo/mre1.png',
        text: 'adsf'
    }, {
        image: 'img/demo/mre2.png',
        text: 'adsf'
    }, {
        image: 'img/demo/mre3.png',
        text: 'adsf'
    }, {
        image: 'img/demo/mre2.png',
        text: 'aaaaaaaaaaa'
    }];
}

function CarouselDemoCtrl4($scope) {
    $scope.myInterval = 5000;
    $scope.slides = [{
        image: 'img/demo/m4-2.png',
        text: 'adsf'
    }, {
        image: 'img/demo/m4-1.png',
        text: 'adsf'
    }, {
        image: 'img/demo/m4.png',
        text: 'adsf'
    }];
}

function CarouselDemoCtrl5($scope) {
    $scope.myInterval = 5000;
    $scope.slides = [{
        image: 'img/demo/m5.png',
        text: 'adsf'
    }, {
        image: 'img/demo/m5-1.png',
        text: 'adsf'
    }, {
        image: 'img/demo/m5-2.png',
        text: 'adsf'
    }];
}
;angular.module('itms')
    .controller('shellCtrl', ['$rootScope', '$state', 'auth', 'identity', "config", 'common',
        function ($rootScope, $state, auth, identity, config, common) {
           var userTypes = {
              "1": "管理员",
              "2": "海通业务员",
              "3": "合作伙伴"
           };
           $rootScope.logout = function () {
              $rootScope.currentUser = undefined;
              identity.currentUser = undefined;
              window.location.reload(true);
              
           };

           $rootScope.askLogout = function () {
              common.messageBox({
                 title: "提示信息:",
                 content: "是否退出系统?"
              }).success($rootScope.logout)
                  .error(function () { });
           };



           $rootScope.refreshPage = function () {
              window.location.reload(true);
           };
           $rootScope.isLoginRequired = auth.isLoginRequired;
           $rootScope.currentUser = identity.currentUser;

           if (identity.currentUser) {
              $rootScope.currentUser.displayName = identity.currentUser.lastName + identity.currentUser.fisrtName;
              $rootScope.currentUser.userType = userTypes[identity.currentUser.userType];
              config.userID = identity.currentUser.userID;
           }
           $rootScope.$on('$stateChangeSuccess',
               function (event, toState, toParams, fromState, fromParams) {
                  $rootScope.paths = [];
                  getPath(toState);
                  if (toState.name && toState.name != "app.login")
                     saveLastState(toState.name);
               }
           );

           function getLastState() {
              if (window.localStorage) {
                 return localStorage['lastState'];
              }
              return null;
           }

           function getPath(state) {
              var parent;
              state.data && $rootScope.paths.unshift({
                 state: state.name,
                 displayName: state.data.displayName
              });
              if (state.name.indexOf('.') > 0) {
                 parent = state.name.split('.')[0];
                 getPath($rootScope.$state.get(parent));
              }
           }

           function saveLastState(state) {

              if (window.localStorage) {
                 localStorage['lastState'] = state;
              }
           }

           $('#activity').click(function (e) {
              var $this = $(this);

              if ($this.find('.badge').hasClass('bg-color-red')) {
                 $this.find('.badge').removeClassPrefix('bg-color-');
                 $this.find('.badge').text("0");
              }

              if (!$this.next('.ajax-dropdown').is(':visible')) {
                 $this.next('.ajax-dropdown').fadeIn(150);
                 $this.addClass('active');
              } else {
                 $this.next('.ajax-dropdown').fadeOut(150);
                 $this.removeClass('active');
              }
              $this.next('.ajax-dropdown').find('.btn-group > .active > input').attr('id');
              e.preventDefault();
           });


           var lastState = getLastState();


           if (auth.isLoginRequired()) {
              if (!($state.current && $state.current.name && $state.current.name === 'app.login'))
                 $state.go('app.login');
           }
           else if (lastState) {
              if (lastState == 'app.login')
                 $state.go("app.user.dashboard");
              else
                 $state.go(lastState);
           }
        }
    ]);
;angular
    .module('itms.login')
    .controller('LoginCtrl'['$http', '$scope', '$state', 'auth', 'common', 'identity', 'Base64', LoginCtrl]);

function LoginCtrl($http, $scope, $state, auth, common, identity, Base64) {
    $scope.username = '';
    $scope.password = '';
    $scope.logon = function (username, password) {
        auth
            .logon(username, password)
            .then(function (isLoggedin) {
                if (isLoggedin.success) {
		    var authdata = Base64.encode(username + ':' + password);
                    $http.defaults.headers.common['Authorization'] = 'Basic ' + authdata;
                    auth
                        .getAuth(isLoggedin.result.userID)
                        .then(function (result) {
                            if (result.success) {
                                $state.go('app.user.dashboard');
                            }
                        });
                } else {
                    common.notifier.cancel(isLoggedin.message === 'NO_USER' ? '用户不存在' : '密码错误');
                }
            });
    }

};angular.module('itms.map')
    .controller('mapCtrl', ['$scope', mapCtrl]);

function mapCtrl($scope) {
  
}
;angular.module('itms.planning.adjustment')
    .controller('EOAssignAdjustCtrl', ['$scope', '$modal', '$log', 'orderService', 'common', '$http', 'configService', 'customerService', 'exportService', 'config', '$q', EOAssignAdjustCtrl]);

function EOAssignAdjustCtrl($scope, $modal, $log, orderService, common, $http, configService, customerService, exportService, config, $q) {
   var notifier = common.notifier;

   $scope.module = '计划';
   $scope.title = '分配调整';
   $scope.ERType = [""];
   $scope.orders = [];
   $scope.selectedItems = [];
   $scope.selectedSite = [];
   $scope.selectedPosition = { "dep": [], "rec": [] };
   $scope.selectedCustomer = { "dep": [], "rec": [] };
   $scope.customerOrder1 = "";
   $scope.customerOrder2 = "";
   $scope.customerOrder3 = "";
   $scope.ERTag = [''];
   $scope.ERTRType = [''];
   $scope.ERID = [''];
   $scope.ERITN = [''];
   $scope.createDate = "";
   $scope.reset = function () {
      $scope.selectedCustomer = { "dep": [], "rec": [] };
      $scope.selectedSite = [];
      $scope.selectedPosition = { "dep": [], "rec": [] };
      $scope.createDate = "";
      $scope.user = "";
      $scope.ERType = [""];
      $scope.customerOrder1 = "";
      $scope.customerOrder2 = "";
      $scope.customerOrder3 = "";
      $scope.ERTag = [''];
      $scope.ERTRType = [''];
      $scope.dep_Group1 = "";
      $scope.dep_State = "";
      $scope.dep_City = "";
      $scope.rec_State = "";
      $scope.rec_City = "";

   };
   configService.getConfig("ERST").then(function (result) {
      $scope.erst = result.data;
   });

   configService.getConfig("ERNT").then(function (result) {
      $scope.ernt = result.data;
   });

   configService.getConfig("MDAT", null, "MATERIAL", "TRES").then(function (result) {
      $scope.resourceTypes = result.data;
   });
   configService.getConfig("TRPY").then(function (result) {
      $scope.transportTypes = result.data;
   });
   customerService.searchCustomer("car").then(function (result) {
      $scope.carriers = result.data;
   });
   configService.getConfig("ERTP").then(function (result) {
      $scope.eoTypes = result.data;
   });
   configService.getConfig("ERTG").then(function (result) {
      $scope.tags = result.data;
   });
   customerService.searchCustomer("net").then(function (result) {
      $scope.nets = result.data;
   });
   customerService.searchCustomer("all").then(function (result) {
      $scope.alls = result.data;
   });
   customerService.searchCustomer("dep").then(function (result) {
      $scope.deps = result.data;
   });
   $scope.handleEvent = function () {
      var modalInstance = $modal.open({
         templateUrl: 'app/transport/event/handleEvent.tpl.html',
         controller: 'HandleEventCtrl',
         resolve: {
            items: function () {
               return $scope.selectedItems;
            }
         }
      });
      modalInstance.result.then(function () {
         common.notifier.success("操作成功");
      });
   };


   $scope.rowItemSplit = function () {

      if (!$scope.isOnlyOneSelected())
         return;
      var modalInstance = $modal.open({
         templateUrl: "app/planning/rowItemSplit.tpl.html",
         controller: "rowItemSplitCtrl",
         resolve: {
            item: function () {
               console.log(JSON.stringify($scope.selectedItems[0]));
               return $scope.selectedItems[0];
            }
         }
      });
      modalInstance.result.then(function () {
         refresh();
      }, function () {
         $log.info('Modal dismissed at: ' + new Date());
      });
   };


   $scope.packUpdate = function () {
      if ($scope.disableAction()) return;

      var modalInstance = $modal.open({
         templateUrl: "app/planning/packUpdate.tpl.html",
         controller: "packUpdateCtrl",
         resolve: {
            items: function () {
               return $scope.selectedItems.map(function (i) {
                  return { "erID": i.erID, "erITN": i.erITN };
               });
            }
         }
      });
      modalInstance.result.then(function () {
         refresh();
      }, function () {
         $log.info('Modal dismissed at: ' + new Date());
      });
   };

   $scope.searchAssignableRequest = function () {
      var param = {
         SerType: 'AND',
         userID: "",
         depAreaCode: $scope.selectedSite.toString(),
         depCustomer: $scope.selectedCustomer.dep.toString(),
         depLocCode: $scope.selectedPosition.dep.toString(),
         recCustomer: $scope.selectedCustomer.rec.toString(),
         recLocCode: $scope.selectedPosition.rec.toString(),
         createDate: $scope.createDate,
         ERType: $scope.ERType,
         customerOrder1: $scope.customerOrder1,
         customerOrder2: $scope.customerOrder2,
         customerOrder3: $scope.customerOrder3,
         ERTag: $scope.ERTag,
         ERTRType: $scope.ERTRType,
         MesUnit1: '',
         reqDelDate: '',
         dep_Country: '',
         dep_State: $scope.dep_State,
         dep_City: $scope.dep_City,
         dep_Disc: '',
         dep_Group1: $scope.dep_Group1,
         dep_Group2: '',
         rec_Country: '',
         rec_State: $scope.rec_State,
         rec_City: $scope.rec_City,
         rec_Disc: '',
         rec_Group1: '',
         rec_Group2: '',
         ERITNStatus: ['ASGN'],
         ERStatus: [''],
         ERID: $scope.ERID,
         ERITN: $scope.ERITN,
         project: "",
         plannedID: "",
         OMSOrderID: "",
         contractID: "",
         pickERDate: "",
         ERTRVendor: "",
         BP1: "",
         BP2: "",
         BP3: "",
         TransResPlanTag: "",
         ItemSplitPlan: "",
         RoutePlanTag: "",
         PackNum: "",
         PackNum2: "",
         PackNum3: "",
         SubPackNum: "",
         SubPackNum2: "",
         SubPackNum3: "",
         vendor: "",
         MatIID: "",
         customerMatID: "",
         RouteID: "",
         RouteClassName: "",
         RouteClassID: "",
         TranResType: "",
         TranResID: "",
         TranResLicense: "",
         TransDriverID: "",
         TrVendor: "",
         resType1: "",
         resID1: "",
         resType2: "",
         resID2: "",
         resType3: "",
         resID3: "",
         ResAmtCS1: "",
         ResAmtCS2: "",
         ResAmtCS3: "",
         EOID: ""
      };
      $scope.isInUnionSearch = false;
      orderService.query(param).success(callback);
   };

   $scope.unionParam = orderService.buildUnionParam();

   var refresh = function () {
      if ($scope.isInUnionSearch)
         $scope.unionSearch();
      else
         $scope.searchAssignableRequest();
   };

   var callback = function (data) {
      $scope.selectedItems = [];
      var icon = $("#wid-result");
      $scope.orders = orderService.getRequirementPartial(data);
      if (icon.hasClass("jarviswidget-collapsed"))
         icon.find(".jarviswidget-toggle-btn").click();
   };


   $scope.isInUnionSearch = false;
   $scope.unionReset = function () {
      $scope.unionParam = orderService.buildUnionParam();
   };
   $scope.unionSearch = function () {
      $scope.isInUnionSearch = true;
      orderService.unionSearch(2, $scope.unionParam).then(function (result) {
         callback(result.data);
      });
   };

   $scope.reallocate = function () {
      var reallocate = function (value) {
         orderService
             .erAssignChange({
                selectedItems: $scope.selectedItems,
                eoid: value
             })
             .success(function () {
                notifier.success("已成功分配至订单" + value);
                refresh();
             });
      };

      var cancel = function () {
         notifier.cancel("操作取消...");
      };

      if ($scope.selectedItems.length > 0) {
         common
             .messageBox({
                title: "将所选的" + $scope.selectedItems.length + "条记录" + "分配至其它运单",
                content: "请输入运单号",
                input: "text",
                placeholder: "EO运单编号"
             })
             .success(reallocate)
             .error(cancel);


      }
   };

   $scope.cancelAssignment = function () {
      var doCancelAssignment = function () {
         orderService
            .erDeleteAssignment({
               selectedItems: $scope.selectedItems
            })
            .success(function () {
               notifier.success("已成功取消运单分配...");
               refresh();
            });
      };
      if ($scope.selectedItems.length > 0) {
         common.messageBox({
            title: "提示信息!",
            content: "是否取消所选择" + $scope.selectedItems.length + "条记录的运单分配?"
         })
             .success(doCancelAssignment)
             .error(function () {
                notifier.cancel();
             });
      }
   };

   $scope.deleteErItem = function () {
      if ($scope.disableAction()) return;
      common.messageBox({
         title: "提示信息:",
         content: "是否删除所选择的" + $scope.selectedItems.length + "条记录?"
      }).success($scope.doDeleteErItem)
          .error(function () {
             common.notifier.cancel("已取消...");
          });
   };

   $scope.doDeleteErItem = function () {
      $http.postXSRF(config.baseUrl + "ER/ERDelItem", {
         "ERID": $scope.selectedItems.map(function (i) {
            return i.erID;
         }),
         "ERITN": $scope.selectedItems.map(function (i) {
            return i.erITN;
         }),
         "userID": config.userID
      }).then(
           function (result) {
              if (!result.errorMessage || result.errorMessage === "OK") {
                 common.notifier.success("删除操作成功...");
              }
           }).then(function () {
              refresh();
           });
   };



   $scope.disableAction = function () {
      return $scope.selectedItems.length === 0;
   };
   $scope.isOnlyOneSelected = function () {
      return $scope.selectedItems.length === 1;
   };



   $scope.columns = [
       { "mData": "eoID", "sTitle": "EO" },
       { "mData": "erID", "sTitle": "ER" },
       { "mData": "erITN", "sTitle": "ERITN" },
       { "mData": "erTypeDesc", "sTitle": "类型" },
       { "mData": "erTag", "sTitle": "特殊" },
       { "mData": "depCustomerDesc", "sTitle": "发货方", "sWidth": 150 },
       { "mData": "recCustomerDesc", "sTitle": "收货方", "sWidth": 150 },
       { "mData": "project", "sTitle": "项目简称" },
       { "mData": "plannedID", "sTitle": "周计划" },
       { "mData": "customerOrder1", "sTitle": "客户订单号", "sWidth": 150 },
       { "mData": "customerOrder2", "sTitle": "海通运单号", "sWidth": 120 },
       { "mData": "customerOrder3", "sTitle": "海通委托单号", "sWidth": 120 },
       { "mData": "matIID", "sTitle": "物料" },
       { "mData": "resAmtCS1", "sTitle": "箱型" },
       { "mData": "subPackNumner", "sTitle": "封号" },
       { "mData": "packNum", "sTitle": "箱号" },
       { "mData": "amt", "sTitle": "件数" },
       { "mData": "resID1", "sTitle": "包装编码" },
       { "mData": "resAmt1", "sTitle": "包装数量" },
       { "mData": "pickERDate", "sTitle": "预计装箱日期", "sWidth": 150 },
       { "mData": "reqDelDate", "sTitle": "送达日期", "sWidth": 150 },
       { "mData": "ertrTypeDesc", "sTitle": "方式" },
       { "mData": "eritnstatusDesc", "sTitle": "状态" },
       { "mData": "ertrVendorDesc", "sTitle": "第三方" }
   ];

   $scope.searchCriteria = {
      site: '',
      senderCode: 'AB00011',
      receiverCode: 'AB00012',
      senderLocation: 'AB00013',
      receiverLocation: 'AB00014',
      reset: function () {
         this.site = '';
         this.senderCode = '';
         this.receiverCode = '';
         this.senderLocation = '';
         this.receiverLocation = '';
      }
   };


   $scope.searchSite = function () {
      var modalInstance = $modal.open({
         templateUrl: "app/planning/searchSite.tpl.html",
         controller: "searchSiteCtrl"
      });
      modalInstance.result.then(function (keys) {
         $scope.selectedSite = keys;
      }, function () {
         $log.info('Modal dismissed at: ' + new Date());
      });
   };

   $scope.searchCustomer = function (type) {
      var modalInstance = $modal.open({
         templateUrl: "app/planning/searchCustomer.tpl.html",
         controller: "searchCustomerCtrl",
         resolve: {
            type: function () {
               return type;
            }
         }
      });
      modalInstance.result.then(function (selectedItem) {
         $scope.selectedCustomer[type] = selectedItem;
      }, function () {
         $log.info('Modal dismissed at: ' + new Date());
      });
   };

   $scope.searchLocation = function () {
      var modalInstance = $modal.open({
         templateUrl: "",
         controller: "searchLocationCtrl",
         resolve: {
            items: function () {
               return $scope.selectedItems();
            }
         }
      });
      modalInstance.result.then(function (selectedItem) {
         $scope.selected = selectedItem;
      }, function () {
         $log.info('Modal dismissed at: ' + new Date());
      });
   };


   $scope.batchUpdate = function () {

      if ($scope.disableAction()) return;

      var modalInstance = $modal.open({
         templateUrl: "app/planning/batchUpdate.tpl.html",
         controller: "batchUpdateCtrl",
         resolve: {
            transportTypes: function () {
               var deferred = $q.defer();
               configService.getConfig("TRPY").then(function (result) {
                  deferred.resolve(result.data);
               });
               return deferred.promise;
            },
            carriers: function () {

               var deferred = $q.defer();
               customerService.searchCustomer("car").then(function (result) {
                  deferred.resolve(result.data);
               });
               return deferred.promise;
            },
            erID: function () {
               return $scope.selectedItems.map(function (i) {
                  return i.erID;
               });
            }
         }
      });
      modalInstance.result.then(function () {
         refresh();
      }, function () {
         $log.info('Modal dismissed at: ' + new Date());
      });

   };

   $scope.detailConfig = { erDetail: true, timeLine: true, eoDetail: true };

   $scope.export = function () {
      exportService.export($scope.columns, $scope.orders);

   };

}
;angular.module('itms.planning.adjustment')
    .factory('orderService', orderService);

function orderService($http, config) {

   var searchUrl = config.baseUrl + 'ER/ERQuickSearch';


   function queryAllRemote() {
      var data = {
         SerType: 'AND',
         userID: '',
         depAreaCode: '',
         depCustomer: '',
         depLocCode: '',
         recCustomer: '',
         recLocCode: '',
         createDate: '',
         ERType: [''],
         customerOrder1: '',
         customerOrder2: '',
         customerOrder3: '',
         ERTag: [''],
         ERTRType: [''],
         MesUnit1: '',
         reqDelDate: '',
         dep_Country: '',
         dep_State: '',
         dep_City: '',
         dep_Disc: '',
         dep_Group1: '',
         dep_Group2: '',
         rec_Country: '',
         rec_State: '',
         rec_City: '',
         rec_Disc: '',
         rec_Group1: '',
         rec_Group2: '',
         ERITNStatus: ['ASGN'],
         ERStatus: [''],
         ERID: [''],
         ERITN: [''],
         project: "",
         plannedID: "",
         OMSOrderID: "",
         contractID: "",
         pickERDate: "",
         ERTRVendor: "",
         BP1: "",
         BP2: "",
         BP3: "",
         TransResPlanTag: "",
         ItemSplitPlan: "",
         RoutePlanTag: "",
         PackNum: "",
         PackNum2: "",
         PackNum3: "",
         SubPackNum: "",
         SubPackNum2: "",
         SubPackNum3: "",
         vendor: "",
         MatIID: "",
         customerMatID: "",
         RouteID: "",
         RouteClassName: "",
         RouteClassID: "",
         TranResType: "",
         TranResID: "",
         TranResLicense: "",
         TransDriverID: "",
         TrVendor: "",
         resType1: "",
         resID1: "",
         resType2: "",
         resID2: "",
         resType3: "",
         resID3: "",
         ResAmtCS1: "",
         ResAmtCS2: "",
         ResAmtCS3: "",
         EOID: ""
      };
      return $http.postXSRF(searchUrl, data);
   }

   function query(data) {
      return $http.postXSRF(searchUrl, data);
   }

   
   function erAssignChange(data) {
      var erid = data.selectedItems.map(function (item) {
         return item.erID;
      });
      var eritn = data.selectedItems.map(function (item) {
         return item.erITN;
      });
      var assignChange = config.baseUrl + 'ER/ERAssignChange?ERID[]=' + erid.join() + '&ERITN[]=' + eritn.join() + '&EOID=' + data.eoid;
      return $http.post(assignChange);
   }

   
   function erDeleteAssignment(data) {
      var erid = data.selectedItems.map(function (item) {
         return item.erID;
      });
      var eritn = data.selectedItems.map(function (item) {
         return item.erITN;
      });
      var assignChange = config.baseUrl + 'ER/ERAssignDel?ERID[]=' + erid.join() + '&ERITN[]=' + eritn.join();
      return $http.post(assignChange);
   }

   function getRequirementPartial(items) {
      if (!items.map) return [];
      return items.map(mapRequirement);

      function mapRequirement(item) {
         return {
            eoID: item.requirementDetail && item.requirementDetail.eoid,
            erID: item.requirementDetail && item.requirementDetail.pk.erID,
            erITN: item.requirementDetail && item.requirementDetail.pk.erITN,
            erType: item.requirement.erType,
            erTypeDesc: item.ertypeDesc,
            erTag: item.requirement.erTag,
            depCustomer: item.requirement.depCustomer,
            depCustomerDesc: item.depCustomerDesc,
            recCustomer: item.recCustomer,
            recCustomerDesc: item.recCustomerDesc,
            project: item.requirement.project,
            plannedID: item.requirement.plannedID,
            customerOrder1: item.requirement.customerOrder1,
            customerOrder2: item.requirement.customerOrder2,
            customerOrder3: item.requirement.customerOrder3,
            matIID: item.requirementDetail && item.requirementDetail.matIID,
            resAmtCS1: item.requirementDetail && item.requirementDetail.resAmtCS1,
            subPackNumner: item.requirementDetail && item.requirementDetail.packNum,
            packNum: item.requirementDetail && item.requirementDetail.subPackNumner,
            amt: item.requirementDetail && item.requirementDetail.amt,
            resID1: item.requirementDetail && item.requirementDetail.resID1,
            resAmt1: item.requirementDetail && item.requirementDetail.resAmt1,
            pickERDate: item.requirement.pickERDate,
            reqDelDate: item.requirement.reqDelDate,
            ertrType: item.requirement.erTRType,
            ertrTypeDesc: item.ertrtypeDesc,
            eritnstatusDesc: item.eritnstatusDesc,
            ertrVendor: item.requirement.ertrvendor,
            ertrVendorDesc: item.ertrvendorDesc
         };
      }
   }

   function getRequirementPartialForAssigment(items) {
      if (!items.map) return [];
      return items.map(mapRequirement);

      function mapRequirement(item) {
         return {
            erID: item.requirementDetail && item.requirementDetail.pk.erID,
            erITN: item.requirementDetail && item.requirementDetail.pk.erITN,
            ertypeDesc: item.ertypeDesc,
            erTag: item.requirement.erTag,
            depCustomerDesc: item.depCustomerDesc,
            recCustomerDesc: item.recCustomerDesc,
            project: item.requirement.project,
            plannedID: item.requirement.plannedID,
            customerOrder1: item.requirement.customerOrder1,
            customerOrder2: item.requirement.customerOrder2,
            customerOrder3: item.requirement.customerOrder3,
            matIID: item.requirementDetail && item.requirementDetail.matIID,
            resID1: item.requirementDetail && item.requirementDetail.resID1,
            resAmt1: item.requirementDetail && item.requirementDetail.resAmt1,
            resAmtCS1: item.requirementDetail && item.requirementDetail.resAmtCS1,
            subPackNumner: item.requirementDetail && item.requirementDetail.packNum,
            packNum: item.requirementDetail && item.requirementDetail.subPackNumner,
            amt: item.requirementDetail && item.requirementDetail.amt,
            pickERDate: item.requirement.pickERDate,
            reqDelDate: item.requirement.reqDelDate,
            ertrtypeDesc: item.ertrtypeDesc,
            eritnstatusDesc: item.eritnstatusDesc,
            ertrvendorDesc: item.ertrvendorDesc,
            bp1Desc: item.bp1Desc,
            vendorDesc: item.vendorDesc
         };
      }
   }

   function buildUnionParam() {
      
    
      return {
         SerType: "AND",
         ERID: [],
         ERITN: [],
         userID: "",
         depAreaCode: "",
         depCustomer: "",
         depLocCode: "",
         recCustomer: "",
         recLocCode: "",
         createDate: "",
         ERType: [""],
         customerOrder1: "",
         customerOrder2: "",
         customerOrder3: "",
         ERTag: [""],
         ERTRType: [""],
         MesUnit1: '',
         reqDelDate: '',
         dep_Country: '',
         dep_State: "",
         dep_City: "",
         dep_Disc: '',
         dep_Group1: "",
         dep_Group2: '',
         rec_Country: '',
         rec_State: "",
         rec_City: "",
         rec_Disc: '',
         rec_Group1: '',
         rec_Group2: '',
         ERITNStatus: [""],
         ERStatus: [""],
         project: "",
         plannedID: "",
         OMSOrderID: "",
         contractID: "",
         pickERDate: "",
         ERTRVendor: "",
         BP1: "",
         BP2: "",
         BP3: "",
         TransResPlanTag: "",
         ItemSplitPlan: "",
         RoutePlanTag: "",
         PackNum: "",
         PackNum2: "",
         PackNum3: "",
         SubPackNum: "",
         SubPackNum2: "",
         SubPackNum3: "",
         vendor: "",
         MatIID: "",
         customerMatID: "",
         RouteID: "",
         RouteClassName: "",
         RouteClassID: "",
         TranResType: "",
         TranResID: "",
         TranResLicense: "",
         TransDriverID: "",
         TrVendor: "",
         resType1: "",
         resID1: "",
         resType2: "",
         resID2: "",
         resType3: "",
         resID3: "",
         ResAmtCS1: "",
         ResAmtCS2: "",
         ResAmtCS3: "",
         EOID: ""
      };
   }

   function unionSearch(type, data) {
      var methods = {
         "1": "ER/ERQuickSearch",
         "2": "ER/ERQuickSearchForEO",
         "3": "EO/EOQuickSearchForER",
      };
      return $http.postXSRF(config.baseUrl + methods[type], data);
   }

   var orderService = {
      getRequirementPartial: getRequirementPartial,
      erAssignChange: erAssignChange,
      erDeleteAssignment: erDeleteAssignment,
      getRequirementPartialForAssigment: getRequirementPartialForAssigment,
      queryAll: queryAllRemote,
      query: query,
      buildUnionParam: buildUnionParam,
      unionSearch: unionSearch


   };

   return orderService;
};angular.module("itms.planning.assignment")
   .controller("EOAssignCtrl", ["$scope", "$modal", "$log", "$http", "config", "common",
      "configService", "customerService", "exportService", "orderService", 'dateTimeHelper', EOAssignCtrl]);


function EOAssignCtrl($scope, $modal, $log, $http, config, common, configService, customerService, exportService, orderService, dateTimeHelper) {
   $scope.module = "计划";
   $scope.title = "需求分配";
   $scope.result = [];
   configService.getConfig("TRPY").then(function (result) {
      $scope.transportTypes = result.data;
   });

   configService.getConfig("ERST").then(function (result) {
      $scope.erst = result.data;
   });

   configService.getConfig("ERNT").then(function (result) {
      $scope.ernt = result.data;
   });


   configService.getConfig("MDAT", null, "MATERIAL", "TRES").then(function (result) {
      $scope.resourceTypes = result.data;
   });

   customerService.searchCustomer("car").then(function (result) {
      $scope.carriers = result.data;
   });
   configService.getConfig("ERTP").then(function (result) {
      $scope.eoTypes = result.data;
   });
   configService.getConfig("ERTG").then(function (result) {
      $scope.tags = result.data;
   });
   customerService.searchCustomer("net").then(function (result) {
      $scope.nets = result.data;
   });
   customerService.searchCustomer("all").then(function (result) {
      $scope.alls = result.data;
   });
   customerService.searchCustomer("dep").then(function (result) {
      $scope.deps = result.data;
   });

   $scope.detailConfig = { erDetail: true, timeLine: true };
   $scope.columns = [
      
        { "mData": "erID", "sTitle": "ER" },
        { "mData": "erITN", "sTitle": "ERITN" },
        { "mData": "ertypeDesc", "sTitle": "类型" },
        { "mData": "erTag", "sTitle": "特殊" },
        { "mData": "depCustomerDesc", "sTitle": "发货方", "sWidth": 150 },
        { "mData": "recCustomerDesc", "sTitle": "收货方", "sWidth": 150 },
        { "mData": "project", "sTitle": "项目简称" },
        { "mData": "plannedID", "sTitle": "周计划" },
        { "mData": "customerOrder1", "sTitle": "客户订单号", "sWidth": 150 },
        { "mData": "customerOrder2", "sTitle": "海通运单号", "sWidth": 120 },
        { "mData": "customerOrder3", "sTitle": "海通委托单号", "sWidth": 120 },
        { "mData": "matIID", "sTitle": "物料" },
        { "mData": "resID1", "sTitle": "包装编码" },
        { "mData": "resAmt1", "sTitle": "包装数量" },
        { "mData": "resAmtCS1", "sTitle": "箱型" },
        { "mData": "subPackNumner", "sTitle": "封号" },
        { "mData": "packNum", "sTitle": "箱号" },
        { "mData": "amt", "sTitle": "件数" },
        { "mData": "pickERDate", "sTitle": "预计装箱日期", "sWidth": 150 },
        { "mData": "reqDelDate", "sTitle": "送达日期", "sWidth": 150 },
        { "mData": "ertrtypeDesc", "sTitle": "方式", "sWidth": 120 },
        { "mData": "eritnstatusDesc", "sTitle": "状态" },
        { "mData": "ertrvendorDesc", "sTitle": "第三方" }
   ];
   $scope.selectedSite = [];
   $scope.selectedPosition = { "dep": [], "rec": [] };
   $scope.selectedCustomer = { "dep": [], "rec": [] };
   $scope.quickResult = [];
   $scope.createDate = "";
   $scope.ERID = [""];
   $scope.ERITN = [""];
   $scope.ERTag = [""];
   $scope.ERTRType = [""];
   $scope.ERType = [""];


   $scope.quickSearch = function () {
      var data = {
         SerType: "AND",
         ERID: $scope.ERID,
         ERITN: $scope.ERITN,
         userID: "",
         depAreaCode: $scope.selectedSite.toString(),
         depCustomer: $scope.selectedCustomer.dep.toString(),
         depLocCode: $scope.selectedPosition.dep.toString(),
         recCustomer: $scope.selectedCustomer.rec.toString(),
         recLocCode: $scope.selectedPosition.rec.toString(),
         createDate: $scope.createDate,
         ERType: $scope.ERType,
         customerOrder1: $scope.customerOrder1,
         customerOrder2: $scope.customerOrder2,
         customerOrder3: $scope.customerOrder3,
         ERTag: $scope.ERTag,
         ERTRType: $scope.ERTRType,
         MesUnit1: '',
         reqDelDate: '',
         dep_Country: '',
         dep_State: $scope.dep_State,
         dep_City: $scope.dep_City,
         dep_Disc: '',
         dep_Group1: $scope.dep_Group1,
         dep_Group2: '',
         rec_Country: '',
         rec_State: $scope.rec_State,
         rec_City: $scope.rec_City,
         rec_Disc: '',
         rec_Group1: '',
         rec_Group2: '',
         ERITNStatus: [""],
         ERStatus: [""],
         project: "",
         plannedID: "",
         OMSOrderID: "",
         contractID: "",
         pickERDate: "",
         ERTRVendor: "",
         BP1: "",
         BP2: "",
         BP3: "",
         TransResPlanTag: "",
         ItemSplitPlan: "",
         RoutePlanTag: "",
         PackNum: "",
         PackNum2: "",
         PackNum3: "",
         SubPackNum: "",
         SubPackNum2: "",
         SubPackNum3: "",
         vendor: "",
         MatIID: "",
         customerMatID: "",
         RouteID: "",
         RouteClassName: "",
         RouteClassID: "",
         TranResType: "",
         TranResID: "",
         TranResLicense: "",
         TransDriverID: "",
         TrVendor: "",
         resType1: "",
         resID1: "",
         resType2: "",
         resID2: "",
         resType3: "",
         resID3: "",
         ResAmtCS1: "",
         ResAmtCS2: "",
         ResAmtCS3: "",
         EOID: ""
      };
      $scope.isInUnionSearch = false;
      $http.postXSRF(config.baseUrl + "ER/ERQuickSearch", data).then($scope.callback);
   };


   $scope.callback = function (result) {
      $scope.adjustData = new AdjustData();
      $scope.createData = new CreateData();
      if (result.data.errorMessage)
         $scope.quickResult = [];
      else
         $scope.quickResult = orderService.getRequirementPartialForAssigment(result.data);
      $scope.selectedItems = [];
      if ($scope.quickResult.length) {
         var icon = $("#wid-result");
         if (icon.hasClass("jarviswidget-collapsed"))
            icon.find(".jarviswidget-toggle-btn").click();
      }
   };

   $scope.reset = function () {
      $scope.selectedCustomer = { "dep": [], "rec": [] };
      $scope.selectedSite = [];
      $scope.selectedPosition = { "dep": [], "rec": [] };
      $scope.createDate = "";
      $scope.user = "";
      $scope.dep_State = "";
      $scope.dep_City = "";
      $scope.dep_Group1 = "";
      $scope.rec_State = "";
      $scope.rec_City = "";
      $scope.ERID = [""];
      $scope.ERITN = [""];
      $scope.ERTag = [""];
      $scope.ERTRType = [""];
      $scope.ERType = [""];
      $scope.customerOrder1 = "";
      $scope.customerOrder2 = "";
      $scope.customerOrder3 = "";
   };

   $scope.unionParam = orderService.buildUnionParam();

   var refresh = function() {

      if ($scope.isInUnionSearch)
         $scope.unionSearch();
      else 
         $scope.quickSearch();
   };

   $scope.isInUnionSearch = false;
   $scope.unionReset = function () {
      $scope.unionParam = orderService.buildUnionParam();
   };
   $scope.unionSearch = function () {
      $scope.isInUnionSearch = true;
      orderService.unionSearch(1, $scope.unionParam).then($scope.callback);
   };
   $scope.handleEvent = function () {
      var modalInstance = $modal.open({
         templateUrl: 'app/transport/event/handleEvent.tpl.html',
         controller: 'HandleEventCtrl',
         resolve: {
            items: function () {
               return $scope.selectedItems;
            }
         }
      });
      modalInstance.result.then(function () {
         common.notifier.success("操作成功");
      });
   };

   $scope.selectedItems = [];

   $scope.searchSite = function () {
      var modalInstance = $modal.open({
         templateUrl: "app/planning/searchSite.tpl.html",
         controller: "searchSiteCtrl"
      });

      modalInstance.result.then(function (keys) {
         $scope.selectedSite = keys;
      }, function () {
         $log.info('Modal dismissed at: ' + new Date());
      });
   };

   $scope.searchCustomer = function (type) {
      var modalInstance = $modal.open({
         templateUrl: "app/planning/searchCustomer.tpl.html",
         controller: "searchCustomerCtrl",
         resolve: {
            type: function () {
               return type;
            }
         }
      });
      modalInstance.result.then(function (selectedItem) {
         $scope.selectedCustomer[type] = selectedItem;
      }, function () {
         $log.info('Modal dismissed at: ' + new Date());
      });
   };

   $scope.searchLocation = function () {
      var modalInstance = $modal.open({
         templateUrl: "",
         controller: "searchLocationCtrl",
         resolve: {
            items: function () {
               return $scope.selectedItems();
            }
         }
      });
      modalInstance.result.then(function (selectedItem) {
         $scope.selected = selectedItem;
      }, function () {
         $log.info('Modal dismissed at: ' + new Date());
      });
   };

   var AdjustData = function () {
      this.userID = config.userID;
      this.ERID = [];
      this.ERTRType = "";
      this.ERTRVendor = "";
   };

   $scope.adjustData = new AdjustData();
   var CreateData = function () {
      this.EOType = "";
      this.userID = config.userID;
      this.EOTRType = "";
      this.EOTag = "0";
      this.EOTRVendor1 = "";
      this.VendorOrder1 = "";

      this.VendorOrder2 = "";

      this.VendorOrder3 = "";
      this.BP1 = "";
      this.BP2 = "";
      this.BP3 = "";
      this.DeliverBP1 = "";
      this.reqDelDate1 = "";
      this.reqDelDate2 = "";
      this.customerOrder1 = "";
      this.customerOrder2 = "";
      this.customerOrder3 = "";

      this.ERID = [];
      this.ERITN = [];
      this.memo = "";
   };

   $scope.createData = CreateData();

   $scope.isAnythingSelected = function () {
      return ($scope.selectedItems.length > 0);
   };
   $scope.isOnlyOneSelected = function () {
      return ($scope.selectedItems.length == 1);
   };
   $scope.modalInstance = null;
   $scope.create = function () {
      if (!$scope.isAnythingSelected())
         return;
      $scope.modalInstance = $modal.open({
         templateUrl: "app/planning/assignment/merge.tpl.html",
         scope: $scope
      });
   };

   $scope.confirmCreate = function () {
      if (!$scope.isAnythingSelected())
         return;
      common.messageBox({
         title: "提示信息:",
         content: "是否分配所选择需求至运单?"
      }).success($scope.doCreate)
          .error(function () {
             $scope.modalInstance.dismiss();

             common.notifier.cancel("分配已取消...");
          });
   };

   $scope.doCreate = function () {
      if (!$scope.isAnythingSelected()) return;

      
      $scope.createData.relDelTime1 = dateTimeHelper.format($scope.createData.relDelTime1, 'HH:mm A', 'HH:mm:ss');
      
      $scope.createData.relDelTime2 = dateTimeHelper.format($scope.createData.relDelTime2, 'HH:mm A', 'HH:mm:ss');


      $scope.createData.ERID = $scope.selectedItems.map(function (i) {
         return i.erID;
      });
      $scope.createData.ERITN = $scope.selectedItems.map(function (i) {
         return i.erITN;
      });

      $http
      .post(config.baseUrl + "EO/EOQuickCreate" + "?" + $.param($scope.createData))
      .then(function (result) {
         $scope.modalInstance.dismiss();
         if (!result.errorMessage || result.errorMessage === "OK") {
            common.notifier.success("运单已成功创建...");
         }
      }).then(function () {
         refresh();
      });
   };

   $scope.adjust = function () {
      if (!$scope.isAnythingSelected())
         return;
      $scope.modalInstance = $modal.open({
         templateUrl: "app/planning/assignment/adjustDeliveryMethod.tpl.html",
         scope: $scope
      });
   };

   $scope.confirmAdjust = function () {
      if (!$scope.isAnythingSelected()) return;
      common.messageBox({
         title: "提示信息:",
         content: "是否修改运输方式及承运商?"
      }).success($scope.doAdjust)
          .error(function () {
             $scope.modalInstance.dismiss();
             common.notifier.cancel("已取消...");
          });
   };

   $scope.doAdjust = function () {
      if (!$scope.isAnythingSelected()) return;
      $scope.adjustData.ERID = $scope.selectedItems.map(function (i) {
         return i.erID;
      });

      $http
          .postXSRF(config.baseUrl + "ER/ERTRChange", $scope.adjustData)
          .then(function (result) {
             $scope.modalInstance.dismiss();
             if (!result.errorMessage || result.errorMessage === "OK") {
                common.notifier.success("数据更新成功...");
             }
          }).then(function () {
             refresh();
          });
   };

   $scope.deleteEr = function () {
      if (!$scope.isAnythingSelected()) return;
      common.messageBox({
         title: "提示信息:",
         content: "是否删除所选择的" + $scope.selectedItems.length + "条ER需求?"
      }).success($scope.doDeleteEr)
          .error(function () {
             common.notifier.cancel("已取消...");
          });
   };

   $scope.doDeleteEr = function () {
      $http.postXSRF(config.baseUrl + "ER/ERDel", {
         "ERID": $scope.selectedItems.map(function (i) {
            return i.erID;
         }),
         "userID": config.userID
      }).then(
          function (result) {
             if (!result.errorMessage || result.errorMessage === "OK") {
                common.notifier.success("删除操作成功...");
             }
          }).then(function () {
             refresh();
          });
   };

   
   $scope.createEOByER = function () {
      if (!$scope.isAnythingSelected())
         return;
      common.messageBox({
         title: "提示信息:",
         content: "是否根据所选择的" + $scope.selectedItems.length + "条ER需求创建EO运单?"
      }).success($scope.doCreateEOByER)
           .error(function () {
              common.notifier.cancel("已取消...");
           });
   };

   
   $scope.doCreateEOByER = function () {
      $http.postXSRF(config.baseUrl + "ER/EOERQuickCreateWOValidation", {
         "ERID": $scope.selectedItems.map(function (i) {
            return i.erID;
         }),
         user: config.userID
      }).then(
         function (result) {
            if (!result.errorMessage || result.errorMessage === "OK") {
               common.notifier.success("创建EO运单操作成功...");
            }
         }).then(function () {
            refresh();
         });
   };

   
   $scope.createEOByERITN = function () {
      if (!$scope.isAnythingSelected())
         return;
      common.messageBox({
         title: "提示信息:",
         content: "是否根据所选择的" + $scope.selectedItems.length + "条ER需求项目创建EO运单?"
      }).success($scope.doCreateEOByERITN)
          .error(function () {
             common.notifier.cancel("已取消...");
          });
   };

   
   $scope.doCreateEOByERITN = function () {
      $http.postXSRF(config.baseUrl + "ER/EOERItnQuickCreateWOValidation", {
         "ERID": $scope.selectedItems.map(function (i) {
            return i.erID;
         }),
         "ERITN": $scope.selectedItems.map(function (i) {
            return i.erITN;
         }),
         user: config.userID
      }).then(
         function (result) {
            if (!result.errorMessage || result.errorMessage === "OK") {
               common.notifier.success("创建EO运单操作成功...");
            }
         }).then(function () {
            refresh();
         });
   };

   
   $scope.autoSplitERITN = function () {
      $http.postXSRF(config.baseUrl + "ER/ERItnAutoSplit", {
         "ERID": $scope.selectedItems.map(function (i) {
            return i.erID;
         }),
         "ERITN": $scope.selectedItems.map(function (i) {
            return i.erITN;
         }),
         user: config.userID
      }).then(
         function (result) {
            if (!result.errorMessage || result.errorMessage === "OK") {
               common.notifier.success("包装数量调整完毕...");
            }
         }).then(function () {
            refresh();
         });
   };



   $scope.packUpdate = function () {

      if (!$scope.isAnythingSelected())
         return;
      var modalInstance = $modal.open({
         templateUrl: "app/planning/packUpdate.tpl.html",
         controller: "packUpdateCtrl",
         resolve: {
            items: function () {
               return $scope.selectedItems.map(function (i) {
                  return { "erID": i.erID, "erITN": i.erITN };
               });
            }
         }
      });
      modalInstance.result.then(function () {
         refresh();
      }, function () {
         $log.info('Modal dismissed at: ' + new Date());
      });
   };

   $scope.rowItemSplit = function () {

      if (!$scope.isOnlyOneSelected())
         return;
      var modalInstance = $modal.open({
         templateUrl: "app/planning/rowItemSplit.tpl.html",
         controller: "rowItemSplitCtrl",
         resolve: {
            item: function () {
               console.log(JSON.stringify($scope.selectedItems[0]));
               return $scope.selectedItems[0];
            }
         }
      });
      modalInstance.result.then(function () {
         refresh();
      }, function () {
         $log.info('Modal dismissed at: ' + new Date());
      });
   };


   $scope.batchUpdate = function () {

      if (!$scope.isAnythingSelected())
         return;

      var modalInstance = $modal.open({
         templateUrl: "app/planning/batchUpdate.tpl.html",
         controller: "batchUpdateCtrl",
         resolve: {
            transportTypes: function () {
               return $scope.transportTypes;
            },
            carriers: function () {
               return $scope.carriers;
            },
            erID: function () {
               return $scope.selectedItems.map(function (i) {
                  return i.erID;
               });
            }
         }
      });
      modalInstance.result.then(function () {
         refresh();
      }, function () {
         $log.info('Modal dismissed at: ' + new Date());
      });

   };
   $scope.assignRoute = function () {

      if (!$scope.isAnythingSelected())
         return;

      var modalInstance = $modal.open({
         templateUrl: "app/planning/assignment/assignRoute.tpl.html",
         controller: "routeCtrl",
         resolve: {

            types: function () {
               return configService.getConfig("TRPY", null, "TRTYPE");
            },
            erID: function () {
               return $scope.selectedItems.map(function (i) {
                  return i.erID;
               });
            },
            erITN: function () {
               return $scope.selectedItems.map(function (i) {
                  return i.erITN;
               });
            }


         }
      });
      modalInstance.result.then(function () {
         refresh();
      });

   };

   $scope.deleteEritm = function () {
      if (!$scope.isAnythingSelected())
         return;
      common.messageBox({
         title: "提示信息:",
         content: "是否删除所选择的" + $scope.selectedItems.length + "条ER需求明细项?"
      }).success($scope.doDeleteEritm)
          .error(function () {
             common.notifier.cancel("已取消...");
          });
   };

   $scope.doDeleteEritm = function () {
      $http
          .postXSRF(
              config.baseUrl + "ER/ERDelItem", {
                 "ERID": $scope.selectedItems.map(function (i) {
                    return i.erID;
                 }),
                 "ERITN": $scope.selectedItems.map(function (i) {
                    return i.erITN;
                 }),
                 "userID": config.userID
              }
          ).then(function (result) {
             if (!result.errorMessage || result.errorMessage === "OK") {
                common.notifier.success("删除操作成功...");
             }
          }).then(function () {
             refresh();
          });
   };

   $scope.export = function () {
      exportService.export($scope.columns, $scope.quickResult);

   };

   $scope.assignResource = function () {

      if (!$scope.isAnythingSelected())
         return;

      var modalInstance = $modal.open({
         templateUrl: "app/planning/assignment/assignResource.tpl.html",
         controller: "resourceCtrl",
         resolve: {
            owners: function () {
               return configService.getConfig("MDAT", null, "MATERIAL", "OWNER");
            },
            types: function () {
               return configService.getConfig("MDAT", null, "MATERIAL", "TRES");
            },
            erID: function () {
               return $scope.selectedItems.map(function (i) {
                  return i.erID;
               });
            },
            erITN: function () {
               return $scope.selectedItems.map(function (i) {
                  return i.erITN;
               });
            }


         }
      });
      modalInstance.result.then(function () {
         refresh();
      });

   };


}
;angular
   .module('itms.planning.common')
   .controller('searchSiteCtrl', ['$scope', '$http', 'config', '$modalInstance', searchSiteCtrl])
   .controller('searchCustomerCtrl', ['$scope', '$http', 'config', '$modalInstance', 'customerService', 'type', searchCustomerCtrl])
   .controller('searchLocationCtrl', ['$scope', '$modalInstance', 'items', searchLocationCtrl])
   .controller('batchUpdateCtrl', ['$scope', '$http', 'config', 'common', '$modalInstance', 'transportTypes', 'carriers', 'erID', batchUpdateCtrl])
   .controller('packUpdateCtrl', ['$scope', '$http', 'config', 'common', '$modalInstance', 'items', packUpdateCtrl])
   .controller('rowItemSplitCtrl', ['$scope', '$http', 'config', 'common', '$modalInstance', 'item', rowItemSplitCtrl])
   .controller("resourceCtrl", ["$scope", "$modal", "$log", "$http", "config", "common",
      "configService", "customerService", "exportService", "orderService", 'dateTimeHelper', '$modalInstance',
      'owners', 'types', 'erID', 'erITN', resourceCtrl])
   .controller("routeCtrl", ["$scope", "$modal", "$log", "$http", "config", "common",
      "configService", "customerService", "exportService", "orderService", 'dateTimeHelper', '$modalInstance', 'types',
      'erID', 'erITN', routeCtrl]);

function searchSiteCtrl($scope, $http, config, $modalInstance) {
   $scope.items = [];
   $scope.adjust = {
      deliveryMethod: '',
      vendor: ''
   };
   $scope.ok = function () {
      var keys = $scope.items.filter(
          function (item) {
             return item.checked;
          }
      ).map(function (item) {
         return item.locID;
      });
      $modalInstance.close(keys);
   };
   $scope.cancel = function () {
      $modalInstance.dismiss('cancel');
   };
   $scope.criteria = {
      "SerType": "OR",
      "type": [1],
      "LocID": [""],
      "description": [""],
      "Country": [""],
      "State": [""],
      "City": [""],
      "Disc": [""],
      "postcode": [""],
      "address1": [""],
      "SalesArea": [""],
      "Group1": [""],
      "Group2": [""]
   };
   $scope.search = function () {
      $http({
         method: "GET",
         url: config.baseUrl + "search/Location" + "?" + $.param($scope.criteria),
         dataType: "json"
      }).then(function (result) {
         $scope.items = result.data;
      });
   };
}

function searchCustomerCtrl($scope, $http, config, $modalInstance, customerService, type) {


   var Criteria = function () {
      this.SerType = "OR";
      this.customer = [""];
      this.name = [""];
      this.contact = [""];
      this.Email = [""];
      this.phone = [""];
      this.Country = [""];
      this.State = [""];
      this.City = [""];
      this.Disc = [""];
      this.postcode = [""];
      this.address1 = [""];
      this.SalesArea = [""];
      this.Group1 = [""];
      this.Group2 = [""];
   };

   $scope.criteria = new Criteria();

   $scope.type = type;
   $scope.items = [];
   $scope.ok = function () {
      var keys = $scope.items.filter(
          function (item) {
             return item.checked;
          }
      ).map(function (item) {
         return item.customer;
      });
      $modalInstance.close(keys);
   };
   $scope.search = function () {
      customerService.searchCustomer(type, $scope.criteria).then(function (result) {
         $scope.items = result.data;
      });
   };
   $scope.cancel = function () {
      $modalInstance.dismiss('cancel');
   };
}

function searchLocationCtrl($scope, $modalInstance, items) {
   $scope.items = items;
   $scope.adjust = {
      deliveryMethod: '',
      vendor: ''
   };
   $scope.ok = function () {
      $scope.items.forEach(function (element) {
         if (!!element.selected) {
            element.deliveryMethod = $scope.adjust.deliveryMethod;
            element.thirdParty = $scope.adjust.vendor;
         }
      });
      $modalInstance.close($scope.items);
   };
   $scope.cancel = function () {
      $modalInstance.dismiss('cancel');
   };
}

function batchUpdateCtrl($scope, $http, config, common, $modalInstance, transportTypes, carriers, erID) {
   $scope.data = {
      "ERTRType": "",
      "ERTRVendor": "",
      "BP1": "",
      "BP2": "",
      "BP3": "",
      "customerOrder1": "",
      "recERDate": "",
      "reqDelDate": "",
      "ERID": [],
      "ERStatus": "",
      "lastChangeUser": "",
      "lastChangeDate": "",
      "lastChangeTime": "",
      "ERTRTypeSM": "",
      "ERTag": "",
      "ERTRVendorSM": "",
      "preERID": "",
      "preEOID": "",
      "customerOrder2": "",
      "customerOrder3": "",
      "preCustomerOrder1": "",
      "preCustomerOrder2": "",
      "preCustomerOrder3": "",
      "totalAmt": "",
      "totalWgt": "",
      "totalVol": "",
      "totalVolWgt": "",
      "resType1": "",
      "ResAmt1": "",
      "resType2": "",
      "ResAmt2": "",
      "resType3": "",
      "ResAmt3": "",
      "ResMemo": "",
      "memo": "",
      "reqDelTimeE": "",
      "reqDelTimeL": "",
      "recERTime": "",
      "pickERDate": "",
      "pickERTimeS": "",
      "pickERTimeF": "",
      "LoadERTimeS": "",
      "LoadERTimeF": "",
      "oprERDate": "",
      "oprERTimeULS": "",
      "oprERTimeULF": "",
      "oprERTimeS": "",
      "oprERTimeF": "",
      "depAreaCode": "",
      "depCustomer": "",
      "depCustomerContact": "",
      "depCustomerEmail": "",
      "depCustomerPhone": "",
      "depLocCode": "",
      "depMemo": "",
      "recCustomer": "",
      "recCustomerContact": "",
      "recCustomerEmail": "",
      "recCustomerPhone": "",
      "recLocCode": "",
      "recMemo": "",
      "project": "",
      "plannedID": "",
      "ERType": ""
   };
   var distinct = function (arr) {
      var result = [];
      arr.forEach(function (i) {
         if (result.indexOf(i) < 0)
            result.push(i);
      });
      return result;
   };
   $scope.data.ERID = distinct(erID);
   $scope.transportTypes = transportTypes;
   $scope.carriers = carriers;
   $scope.save = function () {

      $http.postXSRF(config.baseUrl + "ER/ERMChange", $scope.data).then(
         function (result) {
            if (!result.data.errorMessage || result.data.errorMessage === "OK") {
               common.notifier.success("更新成功...");
               $modalInstance.close();
            };
         });
   };
}

function packUpdateCtrl($scope, $http, config, common, $modalInstance, items) {
   $scope.data = {
      ERID: items.map(function (i) {
         return i.erID;
      }),
      ERITN: items.map(function (i) {
         return i.erITN;
      }),
      userID: config.userID,
      ERITNStatus: "",
      EOID: "",
      lastChangeUser: "",
      lastChangeDate: "",
      lastChangeTime: "",
      ERITNType: "",
      ERITNTag: "",
      Status: "",
      MatIID: "",
      customerMatID: "",
      customerOrder2: "",
      Amt: "",
      Wgt: "",
      Vol: "",
      VolWgt: "",
      "long": "",
      width: "",
      height: "",
      Memo: "",
      RouteID: "",
      RouteClassName: "",
      RouteClassID: "",
      TranResType: "",
      TranResID: "",
      TranResLicense: "",
      TransDriverID: "",
      ResAmt1: "",
      ResAmtCS1: "",
      ResAmt2: "",
      ResAmtCS2: "",
      ResAmt3: "",
      ResAmtCS3: "",
      StorageLocation: "",
      DockLoaction: "",
      PortLocation: "",
      PackNum: "",
      PackNum2: "",
      PackNum3: "",
      SubPackNum: "",
      SubPackNum2: "",
      SubPackNum3: "",
      TrVendor: ""

   };

   $scope.save = function () {

      $http.postXSRF(config.baseUrl + "ER/ERItemMChange", $scope.data).then(
         function (result) {
            if (!result.data.errorMessage || result.data.errorMessage === "OK") {
               common.notifier.success("更新成功...");
               $modalInstance.close();
            };
         });
   };

}

function rowItemSplitCtrl($scope, $http, config, common, $modalInstance, item) {
   $scope.isError = false;
   $scope.clearError = function () {
      $scope.isError = false;
   };
   $scope.data = {
      "ERID": item.erID,
      "ERITN": item.erITN,
      Amt: "",
      PackNum: "",
      PackNum2: "",
      PackNum3: "",
      ResAmt1: "",
      ResAmtCS1: "",
      ResAmt2: "",
      ResAmtCS2: "",
      ResAmt3: "",
      ResAmtCS3: "",
      SubPackNum: "",
      SubPackNum2: "",
      SubPackNum3: "",
      userID: config.userID,



      customerOrder1: item.customerOrder1,
      "matIID": item.matIID,
      availableAmt: item.amt,
      bp1Desc: item.bp1Desc,
      vendorDesc: item.vendorDesc


   };


   $scope.save = function (isDraft) {

      var amt = parseInt($scope.data.Amt);
      if (isNaN(amt) || amt <= 0) {
         alert("请输入拆分数量");
         return;
      }
      var availableAmt = parseInt($scope.data.availableAmt);
      if (amt > availableAmt) {
         $scope.isError = true;
         return;
      }
      var tempData = {
         "ERID": $scope.data.ERID,
         "ERITN": $scope.data.ERITN,
         Amt: $scope.data.Amt,
         PackNum: $scope.data.PackNum,
         PackNum2: $scope.data.PackNum2,
         PackNum3: $scope.data.PackNum3,
         ResAmt1: $scope.data.ResAmt1,
         ResAmtCS1: $scope.data.ResAmtCS1,
         ResAmt2: $scope.data.ResAmt2,
         ResAmtCS2: $scope.data.ResAmtCS2,
         ResAmt3: $scope.data.ResAmt3,
         ResAmtCS3: $scope.data.ResAmtCS3,
         SubPackNum: $scope.data.SubPackNum,
         SubPackNum2: $scope.data.SubPackNum2,
         SubPackNum3: $scope.data.SubPackNum3,
         userID: $scope.data.userID
      };

      var name = isDraft ? "ER/ERItnSplitDraft" : "ER/ERItnSplitConfirm";
      var message = isDraft ? "已成功保存为草稿" : "已成功保存并确认";
      $http.postXSRF(config.baseUrl + name, tempData).then(
         function (result) {
            if (!result.data.errorMessage || result.data.errorMessage === "OK") {
               common.notifier.success(message + "...");
               $modalInstance.close();
            };
         });
   };
}

function resourceCtrl($scope, $modal, $log, $http, config, common, configService, customerService,
   exportService, orderService, dateTimeHelper, $modalInstance, owners, types, erID, erITN) {
   $scope.resourceData = {
      ERID: erID,
      ERITN: erITN,
      TranResType: "",
      TranResID: "",
      TranResLicense: "",
      TransDriverID: ""
   };

   $scope.owners = owners.data;
   $scope.types = types.data;

   $scope.resourceSearchOption = {
      type: "",
      owner: "",
      matnr: "",
      description: "",
      LoadWgt: "",
      Speed: "",
      Vol: "",
      SpecialTag1: ""
   };

   $scope.showResult = false;
   $scope.resources = [];
   $scope.resourceSearch = function () {
      $scope.resourceData.TranResID = "";
      
      
      configService.getMaterial($scope.resourceSearchOption).then(

        function (result) {
           $scope.showResult = true;
           if (result.data &&
              (!result.data.errorMessage || result.data.errorMessage == "OK")) {
              result.data.forEach(
              function (item) {
                 item.selected = false;

              }
           );

              $scope.resources = result.data;


           } else {
              $scope.resources = [];
           }
        }
      );
   };

   $scope.select = function (i) {
      $scope.resources.forEach(
        function (temp) {
           temp.selected = false;
        });

      var item = $scope.resources[i];
      item.selected = true;
      $scope.resourceData.TranResID = item.matnr;
      console.log($scope.resourceData.TranResID);
   };

   $scope.doAssignResource = function (isDraft) {

      var data = $scope.resourceData;

      if (!data.TranResID || !data.TranResLicense || !data.TransDriverID) {
         alert("请输入完整信息");
         return;
      }
      var message = isDraft ? "已成功分配并保存为草稿" : "已成功分配并确认";

      var method = isDraft ? "ERItemResAssignDraft" : "ERItemResAssignConfirm";
      $http.postXSRF(config.baseUrl + "ER/" + method, data).then(function (result) {
         if (result.data &&
            (!result.data.errorMessage || result.data.errorMessage == "OK")) {
            $modalInstance.close();
            common.notifier.success(message + "...");

         }
      });

   };

}




function routeCtrl($scope, $modal, $log, $http, config, common, configService, customerService,
   exportService, orderService, dateTimeHelper, $modalInstance, types, erID, erITN) {
   $scope.types = types.data;
   $scope.searchData = {
      RouteID: "",
      RouteDesc: "",
      TRType: "",
      RouteOrigin: "",
      RouteOriginDesc: "",
      RouteDest: "",
      RouteDesiDesc: "",
   };

   $scope.routes = [];
   $scope.select = function (i) {
      $scope.routes.forEach(
         function (temp) {
            temp.selected = false;
         });

      var item = $scope.routes[i];
      item.selected = true;
      $scope.routeData.routeID = item.routeID;
      console.log($scope.routeData.routeID);
   };
   $scope.search = function () {
      $scope.routeData.routeID = "";
      configService.getRoute($scope.searchData).then(
      function (result) {
         $scope.showResult = true;
         if (result.data &&
            (!result.data.errorMessage || result.data.errorMessage == "OK")) {
            result.data.forEach(
            function (item) {
               item.selected = false;
            }
         );

            $scope.routes = result.data;
         } else {
            $scope.routes = [];
         }
      }
    );
   };
   $scope.routeData = {
      ERID: erID,
      ERITN: erITN,
      routeID: "",
      routeClassID: "",
      dateS: "",
      timeS: "",
      dateE: "",
      timeE: "",
      routeClassTimeS: "",
      routeClassTimeE: "",
      TRVendor: ""
   };
   $scope.routeData.routeID = "";
   $scope.routeData.routeClassID = "";
   $scope.routeData.routeClassTimeS = "";
   $scope.routeData.routeClassTimeE = "";
   var initDate = dateTimeHelper.formatDate(new Date());
   $scope.routeData.dateS = initDate;
   $scope.routeData.timeS = "";
   $scope.routeData.dateE = initDate;
   $scope.routeData.timeE = "";
   $scope.routeData.TRVendor = "";

   $scope.routeData.checked = false;
   $scope.routeData.resetRouteClassID = function () {
      if ($scope.routeData.checked)
         $scope.routeData.routeClassID = "";
   };

   $scope.routeData.resetChecked = function () {
      if ($scope.routeData.routeClassID.length > 0) {
         $scope.routeData.checked = false;
      }
   };

   $scope.doAssignRoute = function (isDraft) {
      var data = {
         ERID: $scope.routeData.ERID,
         ERITN: $scope.routeData.ERITN,
         RouteID: $scope.routeData.routeID,
         RouteClassID: $scope.routeData.routeClassID,
         TRVendor: $scope.routeData.TRVendor,
         RouteClassTimeS: "",
         RouteClassTimeE: ""
      };


      data.RouteClassTimeS = dateTimeHelper.mergeDateTime($scope.routeData.dateS, $scope.routeData.timeS);
      data.RouteClassTimeE = dateTimeHelper.mergeDateTime($scope.routeData.dateE, $scope.routeData.timeE);

      if (!data.RouteID
         || !data.RouteClassID
         || !data.TRVendor
         || !data.RouteClassTimeS
         || !data.RouteClassTimeE) {
         alert("请输入完整信息");
         return;
      }
      var method = isDraft ? "ERItemRouteAssignDraft" : "ERItemRouteAssignConfirm";
      var message = isDraft ? "已成功分配并保存为草稿" : "已成功分配并确认";
      $http.postXSRF(config.baseUrl + "ER/" + method, data).then(function (result) {
         if (result.data &&
            (!result.data.errorMessage || result.data.errorMessage == "OK")) {
            $modalInstance.close();
            common.notifier.success(message + "...");
         }
      });

   };
}


;angular.module('itms.planning.common')
    .factory('customerService', ['$http', 'config', customerService]);

function customerService($http, config) {

    return { "searchCustomer": searchCustomer };

    function Criteria(type) {
        this.type = [];
        this.SerType = "AND";
        this.customer = [""];
        this.name = [""];
        this.contact = [""];
        this.Email = [""];
        this.phone = [""];
        this.Country = [""];
        this.State = [""];
        this.City = [""];
        this.Disc = [""];
        this.postcode = [""];
        this.address1 = [""];
        this.SalesArea = [""];
        this.Group1 = [""];
        this.Group2 = [""];

        switch (type) {
            case "dep":
                this.type = [1];
                break;
            case "rec":
                this.type = [2];
                break;
            case "car":
                this.type = [5];
                break;
            case "net":
                this.type = [3];
                this.Group1 = ["TTP2"];
                break;
            case "all":
                this.type = [""];
                break;
        }
    }

    function searchCustomer(type,param) {
       var criteria = new Criteria(type);
       if (param) {
          for (var i in param) {
             criteria[i] = param[i];
          }
       }
       return $http({
            method: "GET",
            url: config.baseUrl + "search/Customer" + "?" + $.param(criteria),
            dataType: "json"
        });
    }

};angular.module("itms.planning.erPlanibm")
    .controller("erPlanibmCtrl", ["$scope", "$modal", "$log",
        "$http", "config", "common", "configService", "customerService", "exportService", "orderService", erPlanibmCtrl]);

function erPlanibmCtrl($scope, $modal, $log, $http, config, common, configService, customerService, exportService, orderService) {
   $scope.module = "计划";
   $scope.title = "资源计划";
   $scope.result = [];
   configService.getConfig("TRPY").then(function (result) {
      $scope.transportTypes = result.data;
   });
   customerService.searchCustomer("car").then(function (result) {
      $scope.carriers = result.data;
   });
   configService.getConfig("ERTP").then(function (result) {
      $scope.eoTypes = result.data;
   });
   configService.getConfig("ERTG").then(function (result) {
      $scope.tags = result.data;
   });
   customerService.searchCustomer("net").then(function (result) {
      $scope.nets = result.data;
   });

   $scope.detailConfig = { erDetail: true, timeLine: true };
   $scope.columns = [
        { "mData": "erID", "sTitle": "ER" },
        { "mData": "erITN", "sTitle": "ERITN" },
        { "mData": "ertypeDesc", "sTitle": "类型" },
        { "mData": "erTag", "sTitle": "特殊" },
        { "mData": "depCustomerDesc", "sTitle": "发货方" },
        { "mData": "recCustomerDesc", "sTitle": "收货方" },
        { "mData": "project", "sTitle": "项目简称" },
        { "mData": "plannedID", "sTitle": "周计划" },
        { "mData": "customerOrder1", "sTitle": "客户订单号" },
        { "mData": "customerOrder2", "sTitle": "海通运单号" },
        { "mData": "customerOrder3", "sTitle": "海通委托单号" },
        { "mData": "matIID", "sTitle": "物料" },
        { "mData": "resID1", "sTitle": "包装编码" },
        { "mData": "resAmt1", "sTitle": "包装数量" },
        { "mData": "resAmtCS1", "sTitle": "箱型" },
        { "mData": "subPackNumner", "sTitle": "封号" },
        { "mData": "packNum", "sTitle": "箱号" },
        { "mData": "amt", "sTitle": "件数" },
        { "mData": "pickERDate", "sTitle": "预计装箱日期" },
        { "mData": "reqDelDate", "sTitle": "送达日期" },
        { "mData": "ertrtypeDesc", "sTitle": "方式" },
        { "mData": "eritnstatusDesc", "sTitle": "状态" },
        { "mData": "ertrvendorDesc", "sTitle": "第三方" }
   ];
   $scope.selectedSite = [];
   $scope.selectedPosition = { "dep": [], "rec": [] };
   $scope.selectedCustomer = { "dep": [], "rec": [] };
   $scope.quickResult = [];
   $scope.createDate = "";
   $scope.ERID = [""];
   $scope.ERITN = [""];
   $scope.ERTag = [""];
   $scope.ERTRType = [""];
   $scope.ERType = [""];
   $scope.quickSearch = function () {
      var data = {
         SerType: "AND",
         ERID: $scope.ERID,
         ERITN: $scope.ERITN,
         userID: "",
         depAreaCode: $scope.selectedSite.toString(),
         depCustomer: $scope.selectedCustomer.dep.toString(),
         depLocCode: $scope.selectedPosition.dep.toString(),
         recCustomer: $scope.selectedCustomer.rec.toString(),
         recLocCode: $scope.selectedPosition.rec.toString(),
         createDate: $scope.createDate,
         ERType: $scope.ERType,
         customerOrder1: $scope.customerOrder1,
         customerOrder2: $scope.customerOrder2,
         customerOrder3: $scope.customerOrder3,
         ERTag: $scope.ERTag,
         ERTRType: $scope.ERTRType,
         MesUnit1: '',
         reqDelDate: '',
         dep_Country: '',
         dep_State: $scope.dep_State,
         dep_City: $scope.dep_City,
         dep_Disc: '',
         dep_Group1: $scope.dep_Group1,
         dep_Group2: '',
         rec_Country: '',
         rec_State: $scope.rec_State,
         rec_City: $scope.rec_City,
         rec_Disc: '',
         rec_Group1: '',
         rec_Group2: '',
         ERITNStatus: [""],
         ERStatus: [""],
         project: "",
         plannedID: "",
         OMSOrderID: "",
         contractID: "",
         pickERDate: "",
         ERTRVendor: "",
         BP1: "",
         BP2: "",
         BP3: "",
         TransResPlanTag: "",
         ItemSplitPlan: "",
         RoutePlanTag: "",
         PackNum: "",
         PackNum2: "",
         PackNum3: "",
         SubPackNum: "",
         SubPackNum2: "",
         SubPackNum3: "",
         vendor: "",
         MatIID: "",
         customerMatID: "",
         RouteID: "",
         RouteClassName: "",
         RouteClassID: "",
         TranResType: "",
         TranResID: "",
         TranResLicense: "",
         TransDriverID: "",
         TrVendor: "",
         resType1: "",
         resID1: "",
         resType2: "",
         resID2: "",
         resType3: "",
         resID3: "",
         ResAmtCS1: "",
         ResAmtCS2: "",
         ResAmtCS3: "",
         EOID: ""
      };
      $http.postXSRF(config.baseUrl + "ER/ERQuickSearch", data).then(function (result) {
         $scope.adjustData = new AdjustData();
         $scope.createData = new CreateData();
         if (result.data.errorMessage)
            $scope.quickResult = [];
         else
            $scope.quickResult = orderService.getRequirementPartialForAssigment(result.data);
         $scope.selectedItems = [];
         if ($scope.quickResult.length) {
            var icon = $("#wid-result");
            if (icon.hasClass("jarviswidget-collapsed"))
               icon.find(".jarviswidget-toggle-btn").click();
         }
      });
   };

   $scope.reset = function () {
      $scope.selectedCustomer = { "dep": [], "rec": [] };
      $scope.selectedSite = [];
      $scope.selectedPosition = { "dep": [], "rec": [] };
      $scope.createDate = "";
      $scope.user = "";
   };

   $scope.handleEvent = function () {
      var modalInstance = $modal.open({
         templateUrl: 'app/transport/event/handleEvent.tpl.html',
         controller: 'HandleEventCtrl',
         resolve: {
            items: function () {
               return $scope.selectedItems;
            }
         }
      });
      modalInstance.result.then(function () {
         common.notifier.success("操作成功");
      });
   };

   $scope.selectedItems = [];

   $scope.searchSite = function () {
      var modalInstance = $modal.open({
         templateUrl: "app/planning/searchSite.tpl.html",
         controller: searchSiteCtrl
      });

      modalInstance.result.then(function (keys) {
         $scope.selectedSite = keys;
      }, function () {
         $log.info('Modal dismissed at: ' + new Date());
      });
   };

   $scope.searchCustomer = function (type) {
      var modalInstance = $modal.open({
         templateUrl: "app/planning/searchCustomer.tpl.html",
         controller: searchCustomerCtrl,
         resolve: {
            type: function () {
               return type;
            }
         }
      });
      modalInstance.result.then(function (selectedItem) {
         $scope.selectedCustomer[type] = selectedItem;
      }, function () {
         $log.info('Modal dismissed at: ' + new Date());
      });
   };

   $scope.searchLocation = function () {
      var modalInstance = $modal.open({
         templateUrl: "",
         controller: searchLocationCtrl,
         resolve: {
            items: function () {
               return $scope.selectedItems();
            }
         }
      });
      modalInstance.result.then(function (selectedItem) {
         $scope.selected = selectedItem;
      }, function () {
         $log.info('Modal dismissed at: ' + new Date());
      });
   };

   var AdjustData = function () {
      this.userID = config.userID;
      this.ERID = [];
      this.ERTRType = "";
      this.ERTRVendor = "";
   };

   $scope.adjustData = new AdjustData();
   var CreateData = function () {
      this.EOType = "";
      this.userID = config.userID;
      this.EOTRType = "";
      this.EOTag = "0";
      this.EOTRVendor1 = "";
      this.VendorOrder1 = "";
      this.DeliverBP1 = "";
      this.reqDelDate1 = "";
      this.reqDelDate2 = "";
      this.customerOrder1 = "";
      this.ERID = [];
      this.ERITN = [];
      this.memo = "";
   };

   $scope.createData = CreateData();

   $scope.isAnythingSelected = function () {
      return ($scope.selectedItems.length > 0);
   };

   $scope.modalInstance = null;
   $scope.create = function () {
      if (!$scope.isAnythingSelected())
         return;
      $scope.modalInstance = $modal.open({
         templateUrl: "app/planning/assignment/merge.tpl.html",
         scope: $scope
      });
   };

   $scope.confirmCreate = function () {
      if (!$scope.isAnythingSelected())
         return;
      common.messageBox({
         title: "提示信息:",
         content: "是否分配所选择需求至运单?"
      }).success($scope.doCreate)
          .error(function () {
             $scope.modalInstance.dismiss();

             common.notifier.cancel("分配已取消...");
          });
   };

   $scope.doCreate = function () {

      if (!$scope.isAnythingSelected()) return;

      $scope.createData.reqDelDate1 = $("#arriveDate").val();
      $scope.createData.reqDelDate2 = $("#sendDate").val();

      $scope.createData.ERID = $scope.selectedItems.map(function (i) {
         return i.erID;
      });
      $scope.createData.ERITN = $scope.selectedItems.map(function (i) {
         return i.erITN;
      });
      $http
          .postXSRF(config.baseUrl + "EO/EOQuickCreate", $scope.createData)
          .then(function (result) {
             $scope.modalInstance.dismiss();
             if (!result.errorMessage || result.errorMessage === "OK") {
                common.notifier.success("运单已成功创建...");
             }
          }).then(function () {
             $scope.quickSearch();
          });
   };

   $scope.adjust = function () {
      if (!$scope.isAnythingSelected())
         return;
      $scope.modalInstance = $modal.open({
         templateUrl: "app/planning/assignment/adjustDeliveryMethod.tpl.html",
         scope: $scope
      });
   };

   $scope.confirmAdjust = function () {
      if (!$scope.isAnythingSelected()) return;
      common.messageBox({
         title: "提示信息:",
         content: "是否修改运输方式及承运商?"
      }).success($scope.doAdjust)
          .error(function () {
             $scope.modalInstance.dismiss();
             common.notifier.cancel("已取消...");
          });
   };

   $scope.doAdjust = function () {
      if (!$scope.isAnythingSelected()) return;
      $scope.adjustData.ERID = $scope.selectedItems.map(function (i) {
         return i.erID;
      });

      $http
          .postXSRF(config.baseUrl + "ER/ERTRChange", $scope.adjustData)
          .then(function (result) {
             $scope.modalInstance.dismiss();
             if (!result.errorMessage || result.errorMessage === "OK") {
                common.notifier.success("数据更新成功...");
             }
          }).then(function () {
             $scope.quickSearch();
          });
   };

   $scope.deleteEr = function () {
      if (!$scope.isAnythingSelected()) return;
      common.messageBox({
         title: "提示信息:",
         content: "是否删除所选择ER需求?"
      }).success($scope.doDeleteEr)
          .error(function () {
             common.notifier.cancel("已取消...");
          });
   };

   $scope.doDeleteEr = function () {
      $http.postXSRF(config.baseUrl + "ER/ERDel", {
         "ERID": $scope.selectedItems.map(function (i) {
            return i.erID;
         }),
         "userID": config.userID
      }).then(
          function (result) {
             if (!result.errorMessage || result.errorMessage === "OK") {
                common.notifier.success("删除操作成功...");
             }
          }).then(function () {
             $scope.quickSearch();
          });
   };

   
   $scope.createEOByER = function () {
      if (!$scope.isAnythingSelected())
         return;
      common.messageBox({
         title: "提示信息:",
         content: "是否根据所选择ER需求创建EO运单?"
      }).success($scope.doCreateEOByER)
           .error(function () {
              common.notifier.cancel("已取消...");
           });
   };

   
   $scope.doCreateEOByER = function () {
      $http.postXSRF(config.baseUrl + "ER/EOERQuickCreateWOValidation", {
         "ERID": $scope.selectedItems.map(function (i) {
            return i.erID;
         }),
         user: config.userID
      }).then(
         function (result) {
            if (!result.errorMessage || result.errorMessage === "OK") {
               common.notifier.success("创建EO运单操作成功...");
            }
         }).then(function () {
            $scope.quickSearch();
         });
   };

   
   $scope.createEOByERITN = function () {
      if (!$scope.isAnythingSelected())
         return;
      common.messageBox({
         title: "提示信息:",
         content: "是否根据所选择ER需求项目创建EO运单?"
      }).success($scope.doCreateEOByERITN)
          .error(function () {
             common.notifier.cancel("已取消...");
          });
   };

   
   $scope.doCreateEOByERITN = function () {
      $http.postXSRF(config.baseUrl + "ER/EOERItnQuickCreateWOValidation", {
         "ERID": $scope.selectedItems.map(function (i) {
            return i.erID;
         }),
         "ERITN": $scope.selectedItems.map(function (i) {
            return i.erITN;
         }),
         user: config.userID
      }).then(
         function (result) {
            if (!result.errorMessage || result.errorMessage === "OK") {
               common.notifier.success("创建EO运单操作成功...");
            }
         }).then(function () {
            $scope.quickSearch();
         });
   };

   
   $scope.autoSplitERITN = function () {
      $http.postXSRF(config.baseUrl + "ER/ERItnAutoSplit", {
         "ERID": $scope.selectedItems.map(function (i) {
            return i.erID;
         }),
         "ERITN": $scope.selectedItems.map(function (i) {
            return i.erITN;
         }),
         user: config.userID
      }).then(
         function (result) {
            if (!result.errorMessage || result.errorMessage === "OK") {
               common.notifier.success("包装数量调整完毕...");
            }
         }).then(function () {
            $scope.quickSearch();
         });
   };

   $scope.deleteEritm = function () {
      if (!$scope.isAnythingSelected())
         return;
      common.messageBox({
         title: "提示信息:",
         content: "是否删除所选择ER需求明细项?"
      }).success($scope.doDeleteEritm)
          .error(function () {
             common.notifier.cancel("已取消...");
          });
   };

   $scope.doDeleteEritm = function () {
      $http
          .postXSRF(
              config.baseUrl + "ER/ERDelItem", {
                 "ERID": $scope.selectedItems.map(function (i) {
                    return i.erID;
                 }),
                 "ERITN": $scope.selectedItems.map(function (i) {
                    return i.erITN;
                 }),
                 "userID": config.userID
              }
          ).then(function (result) {
             if (!result.errorMessage || result.errorMessage === "OK") {
                common.notifier.success("删除操作成功...");
             }
          }).then(function () {
             $scope.quickSearch();
          });
   };

   $scope.export = function () {
      exportService.export($scope.columns, $scope.quickResult);

   };
};angular.module("itms.requirement.upload").controller("requirementUploadCtrl",
    ["$scope", "$http", "config", "common", "cfpLoadingBar", "uploadSvc", 'Base64', 'identity', controller]);

function controller($scope, $http, config, common, cfpLoadingBar, uploadSvc, Base64, identity) {
   var fileHelper = common.fileHelper;

   $scope.module = "需求管理";
   $scope.title = "站点上载";
   $scope.columns = [
       
       { "mData": "erType", "sTitle": "类型" },
       { "mData": "id.customerOrder1", "sTitle": "客户订单号", "sWidth": 150 },
       { "mData": "id.erITN", "sTitle": "ERITN", "sWidth": 100 },
       { "mData": "matIID", "sTitle": "物料描述", "sWidth": 100 },
       { "mData": "amt", "sTitle": "数量" },
       { "mData": "packNum", "sTitle": "箱号" },
       { "mData": "depAreaCode", "sTitle": "客户名称", "sWidth": 100 },
       { "mData": "customerOrder2", "sTitle": "海通运单号", "sWidth": 120 },
       { "mData": "customerOrder3", "sTitle": "海通委托单号", "sWidth": 150 },
       { "mData": "depCustomer", "sTitle": "收货地", "sWidth": 100 },
       { "mData": "recLocCode", "sTitle": "目的地", "sWidth": 100 },
       { "mData": "reqDelDate", "sTitle": "要求到达日期", "sWidth": 150 }
   ];
   $scope.previewData = {
      "key": null,
      "list": []
   };
   $scope.test = [];
   $scope.hasUploaded = false;

   $scope.selectFile = function (element) {
      $("#fileDisplay").val($(element).val());
   };

   $scope.updateTable = function (data) {
      $scope.previewData = data;
      $scope.test = $scope.previewData.list;
   };

   $scope.handleUpload = function () {
      var $uploadFileInput = $("#fileUpload");
      var msg = uploadSvc.validate($uploadFileInput);
      if (msg) {
         common.messageBox({
            title: "错误信息:",
            content: msg,
            cancel: "取消"
         });

      } else {
         
         $("#type").val(fileHelper.getExtName($uploadFileInput[0].files[0].name));
         var submitData = {
            type: 'post',
            dataType: "",
            url: config.baseUrl + "ER/Upload",
            beforeSend: function (data) {
               var auth = "Basic " + Base64.encode(identity.currentUser.username + ":" + identity.currentUser.password);
               data.setRequestHeader("Authorization", auth);
            },
            success: function (data) {
               cfpLoadingBar.complete();
               $scope.updateTable(data);
               if (data && data.key) {
                  common.notifier.success("上载内容已成功");
                  $scope.hasUploaded = true;
                  $scope.expandTable();
               } else {
                  common.notifier.cancel(data);
                  $scope.hasUploaded = false;
               }

               $scope.$apply();
            },
            error: function (data) {
               cfpLoadingBar.complete();
               common.notifier.cancel(data);
            }
         };
         cfpLoadingBar.start();
         $('#checkout-form').ajaxSubmit(submitData);
      }
   };

   $scope.confirm = function () {
      if (!$scope.hasUploaded)
         return;
      var data = {
         "userID": config.userID,
         "KEY": $scope.previewData.key
      };
      $http.postXSRF(config.baseUrl + "ER/UploadConfirm", data)
           
           .success(function (result) {
              if (result.errorMessage)
                 common.notifier.success("上载操作已成功完成");
              $scope.hasUploaded = false;
           });
   };

   $scope.cancel = function () {
      if (!$scope.hasUploaded)
         return;
      var data = {
         "userID": config.userID,
         "KEY": $scope.previewData.key
      };
      $http.postXSRF(config.baseUrl + "ER/UploadCancel", data)
           
           .success(function (result) {
              if (result.errorMessage && result.errorMessage == "OK")
                 common.notifier.success("上载内容已取消");
              $scope.updateTable({
                 "key": null,
                 "list": []
              });
              $scope.hasUploaded = false;
           }
       );
   };

   $scope.expandTable = function () {
      var icon = $("#widgetPreview");
      if (icon.hasClass("jarviswidget-collapsed"))
         icon.find(".jarviswidget-toggle-btn").click();
   };

};angular
    .module('itms.requirement.upload')
    .factory('uploadSvc', ['common', uploadService]);

function uploadService(common){
    return {
        validate: validate
    };

    function validate(element){
        var ele = element[0];
        if (!ele.files
            || !ele.files[0])
            return "请选择上传文件";
        var file = ele.files[0];

        if (file.size > 2000000)
            return "文件太大";
        var extName = common.fileHelper.getExtName(file.name);
        if (extName != "xls" && extName != "xlsx")
            return "文件类型错误";
        return null;
    }

}
;angular.module("itms.requirement.uploadibm").controller("requirementUploadIbmCtrl",
    ["$scope", "$http", "config", "common", "cfpLoadingBar", "uploadSvc", 'Base64','identity', controller]);

function controller($scope, $http, config, common, cfpLoadingBar, uploadSvc, Base64, identity) {
    var fileHelper = common.fileHelper;

    $scope.module = "需求管理";
    $scope.title = "上载";
    $scope.columns = [
        
        { "mData": "transportType", "sTitle": "运输方式", "sWidth": 150 },
        { "mData": "customerCode1", "sTitle": "合同客户编码", "bVisible": false, "sWidth": 150 },
        { "mData": "customerCode2", "sTitle": "结算客户编码", "bVisible": false, "sWidth": 150 },
        { "mData": "customerCode3", "sTitle": "货主客户编码", "sWidth": 150 },
        { "mData": "projectShortName", "sTitle": "项目简称", "sWidth": 150 },
        { "mData": "transportWeek", "sTitle": "发运周", "sWidth": 150 },
        { "mData": "customerPONumber", "sTitle": "客户订单号", "sWidth": 150 },
        { "mData": "haitongPONumber", "sTitle": "海通订单号", "sWidth": 150 },
        { "mData": "haitongPOCreatedDate", "sTitle": "海通订单生成日", "bVisible": false, "sWidth": 150 },
        { "mData": "haitongTONumber", "sTitle": "海通委托单号", "bVisible": false, "sWidth": 150 },
        { "mData": "haitongTOCreatedDate", "sTitle": "海通委托单生成日", "bVisible": false, "sWidth": 150 },
        { "mData": "quantity", "sTitle": "数量", "sWidth": 150 },
        { "mData": "carrierCode", "sTitle": "运输车队编码", "sWidth": 150 },
        { "mData": "shipfromLocationID", "sTitle": "始发门点编码", "sWidth": 150 },
        { "mData": "shipformCity", "sTitle": "始发市", "bVisible": false, "sWidth": 150 },
        { "mData": "shiptoLocationID", "sTitle": "目的门点编码", "sWidth": 150 },
        { "mData": "shiptoCity", "sTitle": "目的市", "bVisible": false, "sWidth": 150 },
        { "mData": "estimatedPickupDate", "sTitle": "预计装箱日期", visible: false, "sWidth": 150 },
        { "mData": "estimatedPickupTime", "sTitle": "预计装箱时间", "sWidth": 150 },
        { "mData": "estimatedArrivingDate", "sTitle": "预计到达日期", "sWidth": 150 },
        { "mData": "estimatedArrivingTime", "sTitle": "预计到达时间", "sWidth": 150 },
        { "mData": "partCode", "sTitle": "零件编码", visible: false, "sWidth": 150 },
        { "mData": "boxType", "sTitle": "箱类", "bVisible": false, "sWidth": 150 },
        { "mData": "containerType", "sTitle": "箱型", visible: false, "sWidth": 150 },
        { "mData": "containerNo", "sTitle": "箱号", "sWidth": 150 },
        { "mData": "sealNumber", "sTitle": "封号", "sWidth": 150 },
        { "mData": "supplierDUNS", "sTitle": "零件供应商编码", "sWidth": 150 },
        { "mData": "vesselName", "sTitle": "船名", "bVisible": false, "sWidth": 150 },
        { "mData": "voyage", "sTitle": "航次", "bVisible": false, "sWidth": 150 },
        { "mData": "billOfLandingNumber", "sTitle": "运单号", "bVisible": false, "sWidth": 150 },
        { "mData": "materialType", "sTitle": "物料分类", "bVisible": false, "sWidth": 150 },
        { "mData": "packingTypeID", "sTitle": "包装编码", "bVisible": false, "sWidth": 150 },
        { "mData": "packingQuantity", "sTitle": "包装内零件数", "bVisible": false, "sWidth": 150 },
        { "mData": "packingType", "sTitle": "包装类型", "bVisible": false, "sWidth": 150 },
        { "mData": "haitongStorageNo", "sTitle": "暂存区", "bVisible": false, "sWidth": 150 },
        { "mData": "uploadPort", "sTitle": "卸货口", "bVisible": false, "sWidth": 150 },
        { "mData": "errorIndicator", "sTitle": "ERROR", "sWidth": 150 }

    ];
    $scope.previewData = {
        "key": null,
        "list": []
    };
    $scope.test = [];
    $scope.hasUploaded = false;

    $scope.selectFile = function (element) {
        $("#fileDisplay").val($(element).val());
    };

    $scope.updateTable = function (data) {
        $scope.previewData = data;
        $scope.test = $scope.previewData.list;
    };

    $scope.handleUpload = function () {
        var $uploadFileInput = $("#fileUpload");
        var msg = uploadSvc.validate($uploadFileInput);


        if (msg) {
            common.messageBox({
                title: "错误信息:",
                content: msg,
                cancel: "取消"
            });

        } else {
            

            $("#type").val(fileHelper.getExtName($uploadFileInput[0].files[0].name));
            var submitData = {
                type: 'post',
                dataType: "",
                url: config.baseUrl + "ER1/ERUpload",
				beforeSend: function(data) {
				var auth = "Basic " + Base64.encode(identity.currentUser.username + ":" + identity.currentUser.password);
				data.setRequestHeader("Authorization", auth);
				},
                success: function (data) {
                    cfpLoadingBar.complete();
                    $scope.updateTable(data);
                    data.flag
                    if (data && data.key) {
                        common.notifier.success("上载内容已成功,请确认数据.");
                        $scope.hasUploaded = true;
                        $scope.expandTable();
                        $('#fileDisplay').val('')
                    } else {
                        common.notifier.cancel(data.errorMessage);
                        $scope.hasUploaded = false;
                    }
                    $scope.$apply();
                },
                error: function (data) {
                    cfpLoadingBar.complete();
                    common.notifier.cancel(data);
                }
            };
            cfpLoadingBar.start();
            $('#checkout-form').ajaxSubmit(submitData);
        }
    };

    $scope.confirm = function () {
        if (!$scope.hasUploaded)
            return;
        var data = {
            "userID": config.userID,
            "KEY": $scope.previewData.key
        };
        $http.post(config.baseUrl + "ER1/ERCreateDefaultValueCopy" + "?" + $.param(data))
            
            .success(function (result) {
                if (result.errorMessage)
                    common.notifier.success("上载操作已成功完成");
                $scope.hasUploaded = false;
            });
    };

    $scope.cancel = function () {
        if (!$scope.hasUploaded)
            return;
        var data = {
            "userID": config.userID,
            "KEY": $scope.previewData.key
        };
        $http.post(config.baseUrl + "ER/UploadCancel" + "?" + $.param(data))
            
            .success(function (result) {
                if (result.errorMessage && result.errorMessage == "OK")
                    common.notifier.success("上载内容已取消");
                $scope.updateTable({
                    "key": null,
                    "list": []
                });
                $scope.hasUploaded = false;
            }
        );
    };

    $scope.expandTable = function () {
        var icon = $("#widgetPreview");
        if (icon.hasClass("jarviswidget-collapsed"))
            icon.find(".jarviswidget-toggle-btn").click();
    };

};angular.module('itms.transport.eoMaintain')
   .controller('EOMaintainCtrl', ['$scope', "$http", "config", "common", '$modal',
      '$log', 'eoMaintainService', 'configService', 'customerService', 'exportService', 'orderService', EOMaintainSearchCtrl]);

function EOMaintainSearchCtrl($scope, $http, config, common, $modal, $log, eoMaintainService, configService, customerService, exportService, orderService) {
   $scope.module = "运输执行";
   $scope.title = "运单查询/维护";
   $scope.queryOption = {
      SerType: 'AND',
      EO: [''],
      EOStatus: [''],
      eventstatus: [''],
      EOType: [''],
      EOTRType: [''],
      EOTag: [''],
      EOTRVendor1: '',
      EOTRVendor2: '',
      EOTRVendor3: '',
      customerOrder1: '',
      customerOrder2: '',
      customerOrder3: '',
      VendorOrder1: '',
      VendorOrder2: '',
      VendorOrder3: '',
      reqDelDate1: '',
      reqDelDate2: '',
      reqDelDate3: '',
      reqDelDate4: '',
      ScheduleVendor1: '',
      ScheduleClass1: '',
      DepDate1: '',
      ArrDate1: '',
      DepTime1: '',
      Arrtime1: '',
      DeliverBP1: '',
      DeliverBP2: '',
      depCustomer: '',
      depLocCode: '',
      ERTag: '',
      MesUnit1: '',
      reqDelDate: '',
      dep_Country: '',
      dep_State: '',
      dep_City: '',
      dep_Disc: '',
      dep_Group1: '',
      dep_Group2: '',
      rec_Country: '',
      rec_State: '',
      rec_City: '',
      rec_Disc: '',
      rec_Group1: '',
      rec_Group2: '',
      recCustomer: '',
      recLocCode: '',
      BP1: "",
      BP2: "",
      BP3: ""


   };

   configService.getConfig("TRPY").then(function (result) {
      $scope.transportTypes = result.data;
   });
   customerService.searchCustomer("car").then(function (result) {
      $scope.carriers = result.data;
   });
   configService.getConfig("ERST").then(function (result) {
      $scope.erst = result.data;
   });
   configService.getConfig("ERTP").then(function (result) {
      $scope.eoTypes = result.data;
   });
   configService.getConfig("ERNT").then(function (result) {
      $scope.ernt = result.data;
   });

   configService.getConfig("MDAT", null, "MATERIAL", "TRES").then(function (result) {
      $scope.resourceTypes = result.data;
   });
   $scope.results = [];
   $scope.detailConfig = {
      erDetail: true,
      timeLine: true,
      eoDetail: true
   };
   $scope.columns = [{
      "mData": "eo",
      "sTitle": "EO"
   }, {
      "mData": "erID",
      "sTitle": "ER"
   }, {
      "mData": "erITN",
      "sTitle": "ERITN"
   }, {
      "mData": "eoStatus",
      "sTitle": "运单状态",
      "sWidth": 150
   }, {
      "mData": "project",
      "sTitle": "项目简称"
   }, {
      "mData": "plannedID",
      "sTitle": "周计划"
   }, {
      "mData": "customerOrder",
      "sTitle": "客户订单号",
      "sWidth": 150
   }, {
      "mData": "eoType",
      "sTitle": "类型",
      "sWidth": 150
   }, {
      "mData": "eventstatus",
      "sTitle": "事件状态"
   }, {
      "mData": "routeClassID",
      "sTitle": "路单号"
   }, {
      "mData": "tranResLicense",
      "sTitle": "车牌"
   }, {
      "mData": "transDriverID",
      "sTitle": "司机"
   }, {
      "mData": "resAmtCS1",
      "sTitle": "箱型"
   }, {
      "mData": "subPackNumner",
      "sTitle": "封号"
   }, {
      "mData": "amt",
      "sTitle": "件数"
   }, {
      "mData": "resID1",
      "sTitle": "包装编码"
   }, {
      "mData": "resAmt1",
      "sTitle": "包装数量"
   }, {
      "mData": "matIIDDesc",
      "sTitle": "物料名称",
      "sWidth": 120
   }, {
      "mData": "eoTag",
      "sTitle": "特殊"
   }, {
      "mData": "depCustomer",
      "sTitle": "发货方",
      "sWidth": 150
   }, {
      "mData": "recCustomer",
      "sTitle": "收货方",
      "sWidth": 150
   }, {
      "mData": "pickERDate",
      "sTitle": "预计装箱日期",
      "sWidth": 150
   }, {
      "mData": "reDelDate",
      "sTitle": "送达日期",
      "sWidth": 150
   }, {
      "mData": "eoTrtype",
      "sTitle": "方式",
      "sWidth": 150
   }, {
      "mData": "eoTrvendor",
      "sTitle": "承运方"
   }, {
      "mData": "vendorOrder",
      "sTitle": "承运方路单",
      "sWidth": 120
   }, {
      "mData": "deliverBP1",
      "sTitle": "司机ID",
      "sWidth": 120
   }];
   $scope.selectedItems = [];

   var configData = {
      "ERTP": null,
      "EOST": null,
      "EVST": null,
      "TRPY": null,
      "ERTG": null
   };

   var leftQty = function () {
      this.realQty = "";
      this.leftQty = "";
   };

   $scope.leftQty = new leftQty();

   $scope.mutiOptionDataSource = {};
   configService.getConfigs(configData).then(
       function () {
          $.extend($scope.mutiOptionDataSource, configData);
       }
   );


   $scope.unionParam = orderService.buildUnionParam();

   var refresh = function () {
      if ($scope.isInUnionSearch)
         $scope.unionSearch();
      else
         $scope.eoMaintainSearch();
   };

   var callback = function (res) {
      $scope.selectedItems = [];

      if (!res || res.errorMessage)
         $scope.results = [];
      else
         $scope.results = eoMaintainService.getResultPartial(res);

      if ($scope.results.length) {
         var icon = $("#wid-result");
         if (icon.hasClass("jarviswidget-collapsed"))
            icon.find(".jarviswidget-toggle-btn").click();
      }
   };


   $scope.isInUnionSearch = false;
   $scope.unionReset = function () {
      $scope.unionParam = orderService.buildUnionParam();
   };
   $scope.unionSearch = function () {
      $scope.isInUnionSearch = true;
      orderService.unionSearch(3, $scope.unionParam).then(function (result) {
         callback(result.data);
      });
   };

   $scope.eoMaintainSearch = function () {

      $scope.isInUnionSearch = false;
      var data = $scope.queryOption;

      eoMaintainService.quickSearch(data)
          .success(callback)
          .error(function () {
             $log.error('EOMaintainSearchCtrl: quickSearch');
          });
   };

   $scope.resetEoMaintain = function () {
      $scope.queryOption.SerType = 'AND';
      $scope.queryOption.EO = [''];
      $scope.queryOption.EOStatus = [''];
      $scope.queryOption.eventstatus = [''];
      $scope.queryOption.EOType = [''];
      $scope.queryOption.EOTRType = [''];
      $scope.queryOption.EOTag = [''];
      $scope.queryOption.EOTRVendor1 = '';
      $scope.queryOption.EOTRVendor2 = '';
      $scope.queryOption.EOTRVendor3 = '';
      $scope.queryOption.customerOrder1 = '';
      $scope.queryOption.customerOrder2 = '';
      $scope.queryOption.customerOrder3 = '';
      $scope.queryOption.VendorOrder1 = '';
      $scope.queryOption.VendorOrder2 = '';
      $scope.queryOption.VendorOrder3 = '';
      $scope.queryOption.reqDelDate1 = '';
      $scope.queryOption.reqDelDate2 = '';
      $scope.queryOption.reqDelDate3 = '';
      $scope.queryOption.reqDelDate4 = '';
      $scope.queryOption.ScheduleVendor1 = '';
      $scope.queryOption.ScheduleClass1 = '';
      $scope.queryOption.DepDate1 = '';
      $scope.queryOption.ArrDate1 = '';
      $scope.queryOption.DepTime1 = '';
      $scope.queryOption.Arrtime1 = '';
      $scope.queryOption.DeliverBP1 = '';
      $scope.queryOption.DeliverBP2 = '';
      $scope.queryOption.depCustomer = '';
      $scope.queryOption.depLocCode = '';
      $scope.queryOption.ERTag = '';
      $scope.queryOption.MesUnit1 = '';
      $scope.queryOption.reqDelDate = '';
      $scope.queryOption.dep_Country = '';
      $scope.queryOption.dep_State = '';
      $scope.queryOption.dep_City = '';
      $scope.queryOption.dep_Disc = '';
      $scope.queryOption.dep_Group1 = '';
      $scope.queryOption.dep_Group2 = '';
      $scope.queryOption.rec_Country = '';
      $scope.queryOption.rec_State = '';
      $scope.queryOption.rec_City = '';
      $scope.queryOption.rec_Disc = '';
      $scope.queryOption.rec_Group1 = '';
      $scope.queryOption.rec_Group2 = '';
      $scope.queryOption.recCustomer = '';
      $scope.queryOption.recLocCode = '';
      $scope.queryOption.BP1 = "";
      $scope.queryOption.BP2 = "";
      $scope.queryOption.BP3 = "";
   };
   $scope.handleEvent = function () {
      var modalInstance = $modal.open({
         templateUrl: 'app/transport/event/handleEvent.tpl.html',
         controller: 'HandleEventCtrl',
         resolve: {
            items: function () {
               return $scope.selectedItems;
            }
         }
      });
      modalInstance.result.then(function () {
         refresh();
         common.notifier.success("操作成功");
      });
   };

   $scope.isAnythingSelected = function () {
      return ($scope.selectedItems.length > 0);
   };

   $scope.eoBatchUpdate = function () {
      if (!$scope.isAnythingSelected())
         return;
      $scope.batchUpdateData = $scope.createBatchUpdateData();
      $scope.modalInstance = $modal.open({
         templateUrl: "app/transport/eoMaintain/eoBatchUpdate.tpl.html",
         scope: $scope
      });

   };
   $scope.createBatchUpdateData = function () {
      return {
         "EO": [],
         "userID": "",
         "EOStatus": "",
         "EOType": "",
         "EOTRType": "",
         "EOTag": "",
         "EOTRVendor1": "",
         "EOTRVendor2": "",
         "EOTRVendor3": "",
         "customerOrder1": "",
         "customerOrder2": "",
         "customerOrder3": "",
         "VendorOrder1": "",
         "VendorOrder2": "",
         "VendorOrder3": "",
         "reqDelDate1": "",
         "reqDelDate2": "",
         "reqDelDate3": "",
         "reqDelDate4": "",
         "DeliverBP1": "",
         "DeliverBP2": "",
         "DeliverBP3": "",
         "ScheduleVendor1": "",
         "ScheduleVendor2": "",
         "ScheduleVendor3": "",
         "ScheduleClass1": "",
         "ScheduleClass2": "",
         "ScheduleClass3": "",
         "DepDate1": "",
         "DepDate2": "",
         "DepDate3": "",
         "ArrDate1": "",
         "ArrDate2": "",
         "ArrDate3": "",
         "DepTime1": "",
         "DepTime2": "",
         "DepTime3": "",
         "Arrtime1": "",
         "Arrtime2": "",
         "Arrtime3": "",
         "BP1": "",
         "BP2": "",
         "BP3": "",
         "memo": ""
      };

   };
   $scope.batchUpdateData = $scope.createBatchUpdateData();
   $scope.doBatchUpdate = function () {
      var distinct = function (arr) {
         var result = [];
         arr.forEach(function (i) {
            if (result.indexOf(i) < 0)
               result.push(i);
         });
         return result;
      };
      var eos = $scope.selectedItems.map(function (i) {
         return i.eo;
      });
      $scope.batchUpdateData.EO = distinct(eos);

      $http.postXSRF(config.baseUrl + "EO/EOMChange", $scope.batchUpdateData).then(
         function (result) {
            if (!result.data.errorMessage || result.data.errorMessage === "OK") {
               common.notifier.success("更新成功");
               refresh();
               $scope.modalInstance.close();
            }
            ;
         });
   };




   
   $scope.isOnlyOneSelected = function () {
      return ($scope.selectedItems.length == 1);
   };

   
   $scope.leftQtyEvent = function () {
      $scope.modalInstance = $modal.open({
         templateUrl: "app/transport/eoMaintain/eoMaintainLeftQuantity.tpl.html",
         scope: $scope
      });
      
   };

   
   $scope.confirmLeftQtyEvent = function () {
      common.messageBox({
         title: "提示信息:",
         content: "是否更新剩余数量?"
      }).success($scope.doConfirmLeftQtyEvent)
          .error(function () {
             common.notifier.cancel("已取消...");
          });
   };

   
   $scope.doConfirmLeftQtyEvent = function () {
      $http.postXSRF(config.baseUrl + "ER/ItemLeftQtyCreate", {
         "ERID": $scope.selectedItems.map(function (i) {
            return i.erID;
         }),
         "ERITN": $scope.selectedItems.map(function (i) {
            return i.erITN;
         }),
         "ActQty[]": $scope.leftQty.realQty,
         "LeftQty[]": $scope.leftQty.leftQty,
         "userID": config.userID
      }).then(
           function (result) {
              $scope.modalInstance.dismiss();
              if (!result.errorMessage || result.errorMessage === "OK") {
                 common.notifier.success("操作成功...");
              }
           }).then(function () {
              refresh();
           });
   };


   $scope.searchAssignableRequest = function () {
      var options =
      {
         selectedCustomer: $scope.selectedCustomer,
         selectedSite: $scope.selectedSite,
         selectedPosition: $scope.selectedPosition,
         createDate: $scope.createDate,
         
         dep_State: $scope.dep_State,
         dep_City: $scope.dep_City,
         dep_Group1: $scope.dep_Group1,
         rec_State: $scope.rec_State,
         rec_City: $scope.rec_City,
         ERTag: $scope.ERTag,
         ERTRType: $scope.ERTRType,
         ERType: $scope.ERType,
         customerOrder1: $scope.customerOrder1,
         customerOrder2: $scope.customerOrder2,
         customerOrder3: $scope.customerOrder3
      };
      eoMaintainService.queryER(options).success(function (data) {
         var icon = $("#wid-result");
         $scope.orders = orderService.getRequirementPartial(data);
         if (icon.hasClass("jarviswidget-collapsed"))
            icon.find(".jarviswidget-toggle-btn").click();
      });
   };

   $scope.reset = function () {

      $scope.selectedCustomer = { "dep": [], "rec": [] };
      $scope.selectedSite = [];
      $scope.selectedPosition = { "dep": [], "rec": [] };
      $scope.createDate = "";
      $scope.user = "";
      $scope.dep_State = "";
      $scope.dep_City = "";
      $scope.dep_Group1 = "";
      $scope.rec_State = "";
      $scope.rec_City = "";
      $scope.ERTag = [""];
      $scope.ERTRType = [""];
      $scope.ERType = [""];
      $scope.customerOrder1 = "";
      $scope.customerOrder2 = "";
      $scope.customerOrder3 = "";

   };

   $scope.export = function () {
      exportService.export($scope.columns, $scope.results);
   };

}
;angular.module('itms.transport.eoMaintain')
    .factory('eoMaintainService', ['$http', 'config', function ($http, config) {

       return {
          quickSearch: quickSearch,
          getResultPartial: getResultPartial,
          queryER: queryER,
          getLocation: getLocation,
          getEventLocation: getEventLocation,
          getRoutePath: getRoutePath
       };

       function getLocation(option) {
          $.extend(option, { S: ["S1"], E: ["E1"] });
          return $http.postXSRF(config.baseUrl + 'EO/EOItemLocationSearch', option);
       }

       function getEventLocation(option) {
          return $http.postXSRF(config.baseUrl + 'EO/EOItemEventLocationSearch', option);

       }

       function getRoutePath(option) {
          $.extend(option, { S: ["S1"], E: ["E1"] });
          return $http.postXSRF(config.baseUrl + 'EO/EOItemRoutePathSearch', option);

       };

       function quickSearch(param) {
          var data = param;
          return $http.postXSRF(config.baseUrl + 'EO/EOQuickSearch', data);
       }

       function getResultPartial(items) {
          return items.map(mapResult);

          function mapResult(item) {
             return {
                eo: item.dn.eo,
                erID: item.erHead.erID,
                erITN: item.erItem.pk.erITN,
                eoStatus: item.eostatusDesc,
                customerOrder: item.dn.customerOrder1,
                eoType: item.eotypeDesc,
                eoTag: item.dn.eotag,
                depCustomer: item.depCustomerDesc,
                recCustomer: item.recCustomerDesc,
                reDelDate: item.dn.reqDelDate1,
                eoTrtype: item.eotrtypeDesc,
                eoTrvendor: item.eotrvendor1Desc,
                vendorOrder: item.dn.vendorOrder1,
                eventstatus: item.dn.eventstatus,
                routeClassID: item.erItem.routeClassID,
                tranResLicense: item.erItem.tranResLicense,
                transDriverID: item.erItem.transDriverID,
                resAmt1: item.erItem.resAmt1,
                matIIDDesc: item.matIIDDesc,
                amt: item.erItem.amt,
                deliverBP1: item.dn.deliverBP1,
                project: item.erHead.project,
                plannedID: item.erHead.plannedID,
                pickERDate: item.erHead.pickERDate,
                resID1: item.erItem.resID1,
                subPackNumner: item.erItem.subPackNumner,
                resAmtCS1: item.erItem.resAmtCS1

             };
          }
       }


       function queryER(option) {
          var data = {
             SerType: 'AND',
             userID: '',
             depAreaCode: '',
             depCustomer: '',
             depLocCode: '',
             recCustomer: '',
             recLocCode: '',
             createDate: '',
             ERType: [''],
             customerOrder1: '',
             customerOrder2: '',
             customerOrder3: '',
             ERTag: [''],
             ERTRTag: [''],
             MesUnit1: '',
             reqDelDate: '',
             dep_Country: '',
             dep_State: '',
             dep_City: '',
             dep_Disc: '',
             dep_Group1: '',
             dep_Group2: '',
             rec_Country: '',
             rec_State: '',
             rec_City: '',
             rec_Disc: '',
             rec_Group1: '',
             rec_Group2: '',
             ERITNStatus: ['ASGN'],
             ERStatus: [''],
             ERID: [''],
             ERITN: [''],
             ERTRType: [""],
             project: "",
             plannedID: "",
             OMSOrderID: "",
             contractID: "",
             pickERDate: "",
             ERTRVendor: "",
             BP1: "",
             BP2: "",
             BP3: "",
             TransResPlanTag: "",
             ItemSplitPlan: "",
             RoutePlanTag: "",
             PackNum: "",
             PackNum2: "",
             PackNum3: "",
             SubPackNum: "",
             SubPackNum2: "",
             SubPackNum3: "",
             vendor: "",
             MatIID: "",
             customerMatID: "",
             RouteID: "",
             RouteClassName: "",
             RouteClassID: "",
             TranResType: "",
             TranResID: "",
             TranResLicense: "",
             TransDriverID: "",
             TrVendor: "",
             resType1: "",
             resID1: "",
             resType2: "",
             resID2: "",
             resType3: "",
             resID3: "",
             ResAmtCS1: "",
             ResAmtCS2: "",
             ResAmtCS3: "",
             EOID: ""
          };
          $.extend(data, option);
          return $http.postXSRF(config.baseUrl + 'ER/ERQuickSearch', data);
       }

    }]);;angular.module('itms.transport.eoMaintainMap')
   .controller('eoMaintainMapCtrl', ['$scope', "$http", "config", "common", '$modal', '$log',
      'eoMaintainService', 'configService', 'customerService', 'exportService','orderService', '$q', mapCtrl]);

function mapCtrl($scope, $http, config, common, $modal, $log, eoMaintainService,
   configService, customerService, exportService, orderService,$q) {
   $scope.module = "运输执行";
   $scope.title = "运单查询/维护";
   $scope.queryOption = {
      SerType: 'AND',
      EO: [''],
      EOStatus: [''],
      eventstatus: [''],
      EOType: [''],
      EOTRType: [''],
      EOTag: [''],
      EOTRVendor1: '',
      EOTRVendor2: '',
      EOTRVendor3: '',
      customerOrder1: '',
      customerOrder2: '',
      customerOrder3: '',
      VendorOrder1: '',
      VendorOrder2: '',
      VendorOrder3: '',
      reqDelDate1: '',
      reqDelDate2: '',
      reqDelDate3: '',
      reqDelDate4: '',
      ScheduleVendor1: '',
      ScheduleClass1: '',
      DepDate1: '',
      ArrDate1: '',
      DepTime1: '',
      Arrtime1: '',
      DeliverBP1: '',
      DeliverBP2: '',
      depCustomer: '',
      depLocCode: '',
      ERTag: '',
      MesUnit1: '',
      reqDelDate: '',
      dep_Country: '',
      dep_State: '',
      dep_City: '',
      dep_Disc: '',
      dep_Group1: '',
      dep_Group2: '',
      rec_Country: '',
      rec_State: '',
      rec_City: '',
      rec_Disc: '',
      rec_Group1: '',
      rec_Group2: '',
      recCustomer: '',
      recLocCode: '',
      BP1: "",
      BP2: "",
      BP3: ""
   };

   configService.getConfig("TRPY").then(function (result) {
      $scope.transportTypes = result.data;
   });
   customerService.searchCustomer("car").then(function (result) {
      $scope.carriers = result.data;
   });
   configService.getConfig("ERST").then(function (result) {
      $scope.erst = result.data;
   });
   configService.getConfig("ERTP").then(function (result) {
      $scope.eoTypes = result.data;
   });
   configService.getConfig("ERNT").then(function (result) {
      $scope.ernt = result.data;
   });

   configService.getConfig("MDAT", null, "MATERIAL", "TRES").then(function (result) {
      $scope.resourceTypes = result.data;
   });
   $scope.results = [];
   $scope.detailConfig = {
      erDetail: true,
      timeLine: true,
      eoDetail: true
   };

   $scope.columns = [{
      "mData": "eo",
      "sTitle": "EO"
   }, {
      "mData": "erID",
      "sTitle": "ER"
   }, {
      "mData": "erITN",
      "sTitle": "ERITN"
   }, {
      "mData": "eoStatus",
      "sTitle": "运单状态",
      "sWidth": 150
   }, {
      "mData": "project",
      "sTitle": "项目简称"
   }, {
      "mData": "plannedID",
      "sTitle": "周计划"
   }, {
      "mData": "customerOrder",
      "sTitle": "客户订单号",
      "sWidth": 150
   }, {
      "mData": "eoType",
      "sTitle": "类型",
      "sWidth": 150
   }, {
      "mData": "eventstatus",
      "sTitle": "事件状态"
   }, {
      "mData": "routeClassID",
      "sTitle": "路单号"
   }, {
      "mData": "tranResLicense",
      "sTitle": "车牌"
   }, {
      "mData": "transDriverID",
      "sTitle": "司机"
   }, {
      "mData": "resAmtCS1",
      "sTitle": "箱型"
   }, {
      "mData": "subPackNumner",
      "sTitle": "封号"
   }, {
      "mData": "amt",
      "sTitle": "件数"
   }, {
      "mData": "resID1",
      "sTitle": "包装编码"
   }, {
      "mData": "resAmt1",
      "sTitle": "包装数量"
   }, {
      "mData": "matIIDDesc",
      "sTitle": "物料名称",
      "sWidth": 120
   }, {
      "mData": "eoTag",
      "sTitle": "特殊"
   }, {
      "mData": "depCustomer",
      "sTitle": "发货方",
      "sWidth": 150
   }, {
      "mData": "recCustomer",
      "sTitle": "收货方",
      "sWidth": 150
   }, {
      "mData": "pickERDate",
      "sTitle": "预计装箱日期",
      "sWidth": 150
   }, {
      "mData": "reDelDate",
      "sTitle": "送达日期",
      "sWidth": 150
   }, {
      "mData": "eoTrtype",
      "sTitle": "方式",
      "sWidth": 150
   }, {
      "mData": "eoTrvendor",
      "sTitle": "承运方"
   }, {
      "mData": "vendorOrder",
      "sTitle": "承运方路单",
      "sWidth": 120
   }, {
      "mData": "deliverBP1",
      "sTitle": "司机ID",
      "sWidth": 120
   }];

   $scope.selectedItems = [];

   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   $scope.showMap = false;
   $scope.$on("selectionChange", function (ev, data) {
      var icon = $("#wid-map");
      if (data.length === 1) {
         var option = { "EO": [data[0].eo], "ER": [data[0].erID], "ERITN": [data[0].erITN] };
         $q.all(
         [eoMaintainService.getLocation(option),
            eoMaintainService.getEventLocation(option),
            eoMaintainService.getRoutePath(option)]
         ).then(
            function (datas) {

               var success = false;
               if (datas && datas[0] && datas[0].data && datas[0].data[0]
               && datas[1] && datas[1].data && datas[1].data[0]
               && datas[2] && datas[2].data && datas[2].data[0]) {
                  success = mapFrame.window.drawMap(datas[0].data[0], datas[1].data[0], datas[2].data[0]);
               }

               if (icon.hasClass("jarviswidget-collapsed"))
                  icon.find(".jarviswidget-toggle-btn").click();
               $scope.showMap = success;

            });
      }
   });

   var configData = {
      "ERTP": null,
      "EOST": null,
      "EVST": null,
      "TRPY": null,
      "ERTG": null
   };

   var leftQty = function () {
      this.realQty = "";
      this.leftQty = "";
   };

   $scope.leftQty = new leftQty();

   $scope.mutiOptionDataSource = {};
   configService.getConfigs(configData).then(
       function () {
          $.extend($scope.mutiOptionDataSource, configData);
       }
   );

   $scope.unionParam = orderService.buildUnionParam();

   var refresh = function () {
      if ($scope.isInUnionSearch)
         $scope.unionSearch();
      else
         $scope.eoMaintainSearch();
   };

   var callback = function (res) {
      $scope.selectedItems = [];

      if (!res || res.errorMessage)
         $scope.results = [];
      else
         $scope.results = eoMaintainService.getResultPartial(res);

      if ($scope.results.length) {
         var icon = $("#wid-result");
         if (icon.hasClass("jarviswidget-collapsed"))
            icon.find(".jarviswidget-toggle-btn").click();
      }
   };


   $scope.isInUnionSearch = false;
   $scope.unionReset = function () {
      $scope.unionParam = orderService.buildUnionParam();
   };
   $scope.unionSearch = function () {
      $scope.isInUnionSearch = true;
      orderService.unionSearch(3, $scope.unionParam).then(function (result) {
         callback(result.data);
      });
   };

   $scope.eoMaintainSearch = function () {

      $scope.isInUnionSearch = false;
      var data = $scope.queryOption;

      eoMaintainService.quickSearch(data)
          .success(callback)
          .error(function () {
             $log.error('EOMaintainSearchCtrl: quickSearch');
          });
   };

   $scope.resetEoMaintain = function () {
      $scope.queryOption.SerType = 'AND';
      $scope.queryOption.EO = [''];
      $scope.queryOption.EOStatus = [''];
      $scope.queryOption.eventstatus = [''];
      $scope.queryOption.EOType = [''];
      $scope.queryOption.EOTRType = [''];
      $scope.queryOption.EOTag = [''];
      $scope.queryOption.EOTRVendor1 = '';
      $scope.queryOption.EOTRVendor2 = '';
      $scope.queryOption.EOTRVendor3 = '';
      $scope.queryOption.customerOrder1 = '';
      $scope.queryOption.customerOrder2 = '';
      $scope.queryOption.customerOrder3 = '';
      $scope.queryOption.VendorOrder1 = '';
      $scope.queryOption.VendorOrder2 = '';
      $scope.queryOption.VendorOrder3 = '';
      $scope.queryOption.reqDelDate1 = '';
      $scope.queryOption.reqDelDate2 = '';
      $scope.queryOption.reqDelDate3 = '';
      $scope.queryOption.reqDelDate4 = '';
      $scope.queryOption.ScheduleVendor1 = '';
      $scope.queryOption.ScheduleClass1 = '';
      $scope.queryOption.DepDate1 = '';
      $scope.queryOption.ArrDate1 = '';
      $scope.queryOption.DepTime1 = '';
      $scope.queryOption.Arrtime1 = '';
      $scope.queryOption.DeliverBP1 = '';
      $scope.queryOption.DeliverBP2 = '';
      $scope.queryOption.depCustomer = '';
      $scope.queryOption.depLocCode = '';
      $scope.queryOption.ERTag = '';
      $scope.queryOption.MesUnit1 = '';
      $scope.queryOption.reqDelDate = '';
      $scope.queryOption.dep_Country = '';
      $scope.queryOption.dep_State = '';
      $scope.queryOption.dep_City = '';
      $scope.queryOption.dep_Disc = '';
      $scope.queryOption.dep_Group1 = '';
      $scope.queryOption.dep_Group2 = '';
      $scope.queryOption.rec_Country = '';
      $scope.queryOption.rec_State = '';
      $scope.queryOption.rec_City = '';
      $scope.queryOption.rec_Disc = '';
      $scope.queryOption.rec_Group1 = '';
      $scope.queryOption.rec_Group2 = '';
      $scope.queryOption.recCustomer = '';
      $scope.queryOption.recLocCode = '';
      $scope.queryOption.BP1 = "";
      $scope.queryOption.BP2 = "";
      $scope.queryOption.BP3 = "";



   };
   $scope.handleEvent = function () {
      var modalInstance = $modal.open({
         templateUrl: 'app/transport/event/handleEvent.tpl.html',
         controller: 'HandleEventCtrl',
         resolve: {
            items: function () {
               return $scope.selectedItems;
            }
         }
      });
      modalInstance.result.then(function () {
 refresh();
         common.notifier.success("操作成功");
      });
   };

   $scope.isAnythingSelected = function () {
      return ($scope.selectedItems.length > 0);
   };

   $scope.eoBatchUpdate = function () {
      if (!$scope.isAnythingSelected())
         return;
      $scope.batchUpdateData = $scope.createBatchUpdateData();
      $scope.modalInstance = $modal.open({
         templateUrl: "app/transport/eoMaintain/eoBatchUpdate.tpl.html",
         scope: $scope
      });

   };
   $scope.createBatchUpdateData = function () {
      return {
         "EO": [],
         "userID": "",
         "EOStatus": "",
         "EOType": "",
         "EOTRType": "",
         "EOTag": "",
         "EOTRVendor1": "",
         "EOTRVendor2": "",
         "EOTRVendor3": "",
         "customerOrder1": "",
         "customerOrder2": "",
         "customerOrder3": "",
         "VendorOrder1": "",
         "VendorOrder2": "",
         "VendorOrder3": "",
         "reqDelDate1": "",
         "reqDelDate2": "",
         "reqDelDate3": "",
         "reqDelDate4": "",
         "DeliverBP1": "",
         "DeliverBP2": "",
         "DeliverBP3": "",
         "ScheduleVendor1": "",
         "ScheduleVendor2": "",
         "ScheduleVendor3": "",
         "ScheduleClass1": "",
         "ScheduleClass2": "",
         "ScheduleClass3": "",
         "DepDate1": "",
         "DepDate2": "",
         "DepDate3": "",
         "ArrDate1": "",
         "ArrDate2": "",
         "ArrDate3": "",
         "DepTime1": "",
         "DepTime2": "",
         "DepTime3": "",
         "Arrtime1": "",
         "Arrtime2": "",
         "Arrtime3": "",
         "BP1": "",
         "BP2": "",
         "BP3": "",
         "memo": ""
      };

   };
   $scope.batchUpdateData = $scope.createBatchUpdateData();
   $scope.doBatchUpdate = function () {
      var distinct = function (arr) {
         var result = [];
         arr.forEach(function (i) {
            if (result.indexOf(i) < 0)
               result.push(i);
         });
         return result;
      };
      var eos = $scope.selectedItems.map(function (i) {
         return i.eo;
      });
      $scope.batchUpdateData.EO = distinct(eos);

      $http.postXSRF(config.baseUrl + "EO/EOMChange", $scope.batchUpdateData).then(
         function (result) {
            if (!result.data.errorMessage || result.data.errorMessage === "OK") {
               common.notifier.success("更新成功");
               $scope.eoMaintainSearch();
               $scope.modalInstance.close();
            }
            ;
         });
   };


   $scope.isOnlyOneSelected = function () {
      return ($scope.selectedItems.length == 1);
   };

   $scope.leftQtyEvent = function () {
      $scope.modalInstance = $modal.open({
         templateUrl: "app/transport/eoMaintain/eoMaintainLeftQuantity.tpl.html",
         scope: $scope
      });
   };

   $scope.confirmLeftQtyEvent = function () {
      common.messageBox({
         title: "提示信息:",
         content: "是否更新剩余数量?"
      }).success($scope.doConfirmLeftQtyEvent)
          .error(function () {
             common.notifier.cancel("已取消...");
          });
   };

   $scope.doConfirmLeftQtyEvent = function () {
      $http.postXSRF(config.baseUrl + "ER/ItemLeftQtyCreate", {
         "ERID": $scope.selectedItems.map(function (i) {
            return i.erID;
         }),
         "ERITN": $scope.selectedItems.map(function (i) {
            return i.erITN;
         }),
         "ActQty[]": $scope.leftQty.realQty,
         "LeftQty[]": $scope.leftQty.leftQty,
         "userID": config.userID
      }).then(
           function (result) {
              $scope.modalInstance.dismiss();
              if (!result.errorMessage || result.errorMessage === "OK") {
                 common.notifier.success("操作成功...");
              }
           }).then(function () {
                refresh();
           });
   };


   $scope.searchAssignableRequest = function () {
      var options =
      {
         selectedCustomer: $scope.selectedCustomer,
         selectedSite: $scope.selectedSite,
         selectedPosition: $scope.selectedPosition,
         createDate: $scope.createDate,
         
         dep_State: $scope.dep_State,
         dep_City: $scope.dep_City,
         dep_Group1: $scope.dep_Group1,
         rec_State: $scope.rec_State,
         rec_City: $scope.rec_City,
         ERTag: $scope.ERTag,
         ERTRType: $scope.ERTRType,
         ERType: $scope.ERType,
         customerOrder1: $scope.customerOrder1,
         customerOrder2: $scope.customerOrder2,
         customerOrder3: $scope.customerOrder3
      };
      eoMaintainService.queryER(options).success(function (data) {
         var icon = $("#wid-result");
         $scope.orders = orderService.getRequirementPartial(data);
         if (icon.hasClass("jarviswidget-collapsed"))
            icon.find(".jarviswidget-toggle-btn").click();
      });
   };

   $scope.reset = function () {

      $scope.selectedCustomer = { "dep": [], "rec": [] };
      $scope.selectedSite = [];
      $scope.selectedPosition = { "dep": [], "rec": [] };
      $scope.createDate = "";
      $scope.user = "";
      $scope.dep_State = "";
      $scope.dep_City = "";
      $scope.dep_Group1 = "";
      $scope.rec_State = "";
      $scope.rec_City = "";
      $scope.ERTag = [""];
      $scope.ERTRType = [""];
      $scope.ERType = [""];
      $scope.customerOrder1 = "";
      $scope.customerOrder2 = "";
      $scope.customerOrder3 = "";
   };

   $scope.export = function () {
      exportService.export($scope.columns, $scope.results);
   };

}
;angular.module('itms.transport.eoMaintainibm')
    .controller('eoMaintainibmCtrl', ['$scope', "$http", "config", "common", '$modal', '$log', 'eoMaintainService','configService', 'exportService', eoMaintainibmCtrl]);

function eoMaintainibmCtrl($scope, $http, config, common, $modal, $log, eoMaintainService, configService, exportService) {
    $scope.module = "运输执行";
    $scope.title = "运单查询/维护";
    $scope.queryOption = {
        SerType: 'AND',
        EO: [''],
        EOStatus: [''],
        eventstatus: [''],
        EOType: [''],
        EOTRType: [''],
        EOTag: [''],
        EOTRVendor1: '',
        EOTRVendor2: '',
        EOTRVendor3: '',
        customerOrder1: '',
        customerOrder2: '',
        customerOrder3: '',
        VendorOrder1: '',
        VendorOrder2: '',
        VendorOrder3: '',
        reqDelDate1: '',
        reqDelDate2: '',
        reqDelDate3: '',
        reqDelDate4: '',
        ScheduleVendor1: '',
        ScheduleClass1: '',
        DepDate1: '',
        ArrDate1: '',
        DepTime1: '',
        Arrtime1: '',
        DeliverBP1: '',
        DeliverBP2: '',
        depCustomer: '',
        depLocCode: '',
        ERTag: '',
        MesUnit1: '',
        reqDelDate: '',
        dep_Country: '',
        dep_State: '',
        dep_City: '',
        dep_Disc: '',
        dep_Group1: '',
        dep_Group2: '',
        rec_Country: '',
        rec_State: '',
        rec_City: '',
        rec_Disc: '',
        rec_Group1: '',
        rec_Group2: '',
        BP1: "",
        BP2: "",
        BP3: ""

    };
    $scope.results = [];
    $scope.detailConfig = {
        erDetail: true,
        timeLine: true,
        eoDetail: true
    };
    $scope.columns = [{
        "mData": "eo",
        "sTitle": "EO"
    }, {
        "mData": "erID",
        "sTitle": "ER"
    }, {
        "mData": "erITN",
        "sTitle": "ERITN"
    }, {
        "mData": "eoStatus",
        "sTitle": "运单状态"
    }, {
        "mData": "project",
        "sTitle": "项目简称"
    }, {
        "mData": "plannedID",
        "sTitle": "周计划"
    }, {
        "mData": "customerOrder",
        "sTitle": "客户订单号"
    }, {
        "mData": "eoType",
        "sTitle": "类型"
    }, {
        "mData": "eventstatus",
        "sTitle": "事件状态"
    }, {
        "mData": "routeClassID",
        "sTitle": "路单号"
    }, {
        "mData": "tranResLicense",
        "sTitle": "车牌"
    }, {
        "mData": "transDriverID",
        "sTitle": "司机"
    },{
        "mData": "resAmtCS1",
        "sTitle": "箱型"
    },{
        "mData": "subPackNumner",
        "sTitle": "封号"
    },{
        "mData": "amt",
        "sTitle": "件数"
    },{
        "mData": "resID1",
        "sTitle": "包装编码"
    },{
        "mData": "resAmt1",
        "sTitle": "包装数量"
    }, {
        "mData": "matIIDDesc",
        "sTitle": "物料名称"
    }, {
        "mData": "eoTag",
        "sTitle": "特殊"
    }, {
        "mData": "depCustomer",
        "sTitle": "发货方"
    }, {
        "mData": "recCustomer",
        "sTitle": "收货方"
    }, {
        "mData": "pickERDate",
        "sTitle": "预计装箱日期"
    }, {
        "mData": "reDelDate",
        "sTitle": "送达日期"
    }, {
        "mData": "eoTrtype",
        "sTitle": "方式"
    }, {
        "mData": "eoTrvendor",
        "sTitle": "承运方"
    }, {
         "mData": "vendorOrder",
          "sTitle": "承运方路单"
    }, {
        "mData": "deliverBP1",
        "sTitle": "司机ID"
    }];
    $scope.selectedItems = [];

    var configData = {
        "ERTP": null,
        "EOST": null,
        "EVST": null,
        "TRPY": null,
        "ERTG": null
    };

    var leftQty = function() {
        this.realQty = "";
        this.leftQty = "";
    }

    $scope.leftQty = new leftQty();

    $scope.mutiOptionDataSource = {};
    configService.getConfigs(configData).then(
        function() {
            $.extend($scope.mutiOptionDataSource, configData);
        }
    );
    $scope.eoMaintainSearch = function() {
        var data = $scope.queryOption;
        $scope.selectedItems = [];
        eoMaintainService.quickSearch(data)
            .success(function(res) {
                if (!res || res.errorMessage)
                    $scope.results = [];
                else
                    $scope.results = eoMaintainService.getResultPartial(res);

                if( $scope.results.length)
                {
                    var icon = $("#wid-result");
                    if (icon.hasClass("jarviswidget-collapsed"))
                        icon.find(".jarviswidget-toggle-btn").click();
                }
            })
            .error(function() {
                $log.error('EOMaintainSearchCtrl: quickSearch');
            });

    };
    $scope.handleEvent = function() {
        var modalInstance = $modal.open({
            templateUrl: 'app/transport/event/handleEvent.tpl.html',
            controller: 'HandleEventCtrl',
            resolve: {
                items: function() {
                    return $scope.selectedItems;
                }
            }
        });
        modalInstance.result.then(function() {
            common.notifier.success("操作成功");
        });
    };

    $scope.isAnythingSelected = function () {
        return ($scope.selectedItems.length > 0);
    };

    
    $scope.isOnlyOneSelected = function () {
        return ($scope.selectedItems.length == 1);
    };

    
    $scope.leftQtyEvent = function() {
        $scope.modalInstance = $modal.open({
            templateUrl: "app/transport/eoMaintain/eoMaintainLeftQuantity.tpl.html",
            scope: $scope
        });
        
    };

    
    $scope.confirmLeftQtyEvent = function() {
        common.messageBox({
            title: "提示信息:",
            content: "是否更新剩余数量?"
        }).success($scope.doConfirmLeftQtyEvent)
            .error(function () {
                common.notifier.cancel("已取消...");
            });
    };

    
    $scope.doConfirmLeftQtyEvent = function() {
       $http.postXSRF(config.baseUrl + "ER/ItemLeftQtyCreate", {
            "ERID": $scope.selectedItems.map(function (i) {
                return i.erID;
            }),
            "ERITN": $scope.selectedItems.map(function (i) {
                return i.erITN;
            }),
            "ActQty[]": $scope.leftQty.realQty,
            "LeftQty[]": $scope.leftQty.leftQty,
            "userID" : config.userID
        }).then(
            function (result) {
                $scope.modalInstance.dismiss();
                if (!result.errorMessage || result.errorMessage === "OK") {
                    common.notifier.success("操作成功...");
                }
            }).then(function () {
                $scope.eoMaintainSearch();
            });
    };


    $scope.searchAssignableRequest = function () {
        eoMaintainService.queryER().success(function (data) {
            var icon = $("#wid-result");
            $scope.orders = orderService.getRequirementPartial(data);
            if (icon.hasClass("jarviswidget-collapsed"))
                icon.find(".jarviswidget-toggle-btn").click();
        });
    };

    $scope.export = function () {
        exportService.export($scope.columns,$scope.results)

    };

}
;angular.module('itms.transport.event')
    .factory('eoService', ['$http', 'config', "configService", eoService]);

function eoService($http, config, configService) {

   var defaultQueryOption = {
      ERTag: "",
      MesUnit1: '',
      reqDelDate: '',
      dep_Country: '',
      dep_State: '',
      dep_City: '',
      dep_Disc: '',
      
      
      
      
      
      
      
      
      SerType: 'OR',
      EOStatus: ['S001'],
      eventstatus: [''],
      EO: [''],
      EOType: [''],
      EOTRType: [''],
      EOTag: [''],
      EOTRVendor1: '',
      EOTRVendor2: '',
      EOTRVendor3: '',
      customerOrder1: '',
      customerOrder2: '',
      customerOrder3: '',
      VendorOrder1: '',
      VendorOrder2: '',
      VendorOrder3: '',
      reqDelDate1: '',
      reqDelDate2: '',
      reqDelDate3: '',
      reqDelDate4: '',
      ScheduleVendor1: '',
      ScheduleClass1: '',
      DepDate1: '',
      ArrDate1: '',
      DepTime1: '',
      Arrtime1: '',
      DeliverBP1: '',
      DeliverBP2: '',
      depCustomer: '',
      depLocCode: '',
      BP1: "",
      BP2: "",
      BP3: ""

   };

   var searchUrl = config.baseUrl + 'EO/EOQuickSearch';
   var createEventUrl = config.baseUrl + 'EO/EventCreateANY';
   

   var service = {
      queryByEventType: queryByEventType,
      createEvent: createEvent,
      getEventCode: getEventCode
   };


   service.queryAll = queryAllRemote;


   return service;

   function queryAllRemote() {
      var data = defaultQueryOption;
      return $http.postXSRF(searchUrl, data);
   }



   function queryByEventType(type) {
      var data = defaultQueryOption;
      defaultQueryOption.eventstatus = [type || ''];
      return $http.postXSRF(searchUrl, data);
   }

   function createEvent(data) {
      var event = {
         createUser: config.userID,
         eventListener1: '',
         eventListener2: '',
         eventListener3: '',
         eventListener4: '',
         EO: [],
         ERID: [],
         ERITN: []
      };
      angular.extend(event, data);
      return $http.postXSRF(createEventUrl, event);
   }

   function getEventCode(type) {
      return configService.getConfig("EVNT", type);
   }
}
;angular.module('itms.transport.event')
    .controller('EventMaintenanceCtrl', ['$scope', 'eolist', EventMaintenanceCtrl])
    .controller('EventMaintenance.MyWorkSpace', ['$scope', '$modal', 'eoService', 'common', MyWorkSpace])
    .controller('HandleEventCtrl', ['$scope', '$modalInstance', 'eoService', 'dateTimeHelper', 'items', HandleEventCtrl]);

function EventMaintenanceCtrl($scope, eolist) {

   $scope.module = '运输执行';
   $scope.title = '运单事件';
   $scope.orders = getPartialEoList(eolist.data);

   activate();

   function activate() {
      runAllCharts();
   }

   
   function getPartialEoList(items) {
      if (items.errorMessage && items.errorMessage === 'NO_RESULT') {
         return [];
      }
      return items.map(mapper);

      function mapper(item) {
         return {
            eventStatus: item.dn.eventstatus,
            eoNumber: item.dn.eo + '/' + item.erItem.pk.erID + '/' + item.erItem.pk.erITN,
            ertrvendor: item.erHead.ertrvendor,
            depCustomer: item.erHead.depCustomer,
            recCustomer: item.erHead.recCustomer,
            depAreaCode: item.erHead.depAreaCode,
            recLocCode: item.erHead.recLocCode,
            arrtime1: item.dn.arrtime1,
            eo: item.dn.eo,
            erid: item.erItem.pk.erID,
            erITN: item.erItem.pk.erITN
         };
      }
   }
}

function MyWorkSpace($scope, $modal, eoService, common) {
   $scope.columns = [
       {
          "mData": "eventStatus",
          "sTitle": "事件"
       },
       {
          "mData": "eoNumber",
          "sTitle": "EO"
       },
       {
          "mData": "ertrvendor",
          "sTitle": "第三方"
       },
       {
          "mData": "depCustomer",
          "sTitle": "配送方"
       },
       {
          "mData": "depCustomer",
          "sTitle": "发货方"
       },
       {
          "mData": "recCustomer",
          "sTitle": "收货方"
       },
       {
          "mData": "depAreaCode",
          "sTitle": "发货地"
       },
       {
          "mData": "recLocCode",
          "sTitle": "目的地"
       },
       {
          "mData": "arrtime1",
          "sTitle": "计划到达时间"
       }
   ];

   $scope.selectedItems = [];

   $scope.disableAction = function () {
      return $scope.selectedItems.length === 0;
   };

   $scope.filterEvent = function (eventType) {
      eoService
          .queryByEventType(eventType)
          .success(function (data) {
             data = angular.isArray(data) ? data : [];
             $scope.orders = getPartialEoList(data);
          });
   };

   $scope.handleEvent = function () {
      var modalInstance = $modal.open({
         templateUrl: 'app/transport/event/handleEvent.tpl.html',
         controller: 'HandleEventCtrl',
         resolve: {
            items: function () {
               return $scope.selectedItems;
            }
         }
      });
      modalInstance.result.then(function () {
         common.notifier.success("操作成功");
      });
   };

   function getPartialEoList(items) {
      if (items.errorMessage && item.errorMessage === 'NO_RESULT') {
         return [];
      }
      return items.map(mapper);

      function mapper(item) {
         return {
            eventStatus: item.dn.eventstatus,
            eoNumber: item.dn.eo + '/' + item.erItem.pk.erID + '/' + item.erItem.pk.erITN,
            ertrvendor: item.erHead.ertrvendor,
            depCustomer: item.erHead.depCustomer,
            recCustomer: item.erHead.recCustomer,
            depAreaCode: item.erHead.depAreaCode,
            recLocCode: item.erHead.recLocCode,
            arrtime1: item.dn.arrtime1,
            eo: item.dn.eo,
            erid: item.erItem.pk.erID,
            erITN: item.erItem.pk.erITN
         };
      }
   }
}

function HandleEventCtrl($scope, $modalInstance, eoService, dateTimeHelper, items) {
   $scope.loading = false;
   $scope.items = items;
   $scope.event = {
      eventType: '',
      eventCode: '',
      eventDate: dateTimeHelper.formatDate(new Date()),
      eventTime: dateTimeHelper.formatTime(new Date()),
      memo: ''
   };

   $scope.types = [
       {
          value: 'DELY',
          text: '延迟事件'
       },
       {
          value: 'NORM',
          text: '正常事件'
       },
       {
          value: 'UNRP',
          text: '未报告事件'
       },
       {
          value: 'UNXP',
          text: '未期事件'
       }
   ];

   $scope.getEventCode = function (eventType) {
      eoService.getEventCode(eventType)
          .success(function (data) {
             $scope.codes = _.map(data, function (item) {
                return {
                   value: item.group2,
                   text: item.description
                };
             });
          });
   };

   $scope.ok = function () {
      if ($scope.loading)
         return;
      var dt = dateTimeHelper.mergeDateTime($scope.event.eventDate, $scope.event.eventTime);

      var tempData = {
         eventType: $scope.event.eventType,
         eventCode: $scope.event.eventCode,
         eventDateTime: dt,
         memo: $scope.event.memo,

         EO: $scope.items.map(function (item) {
            var temp = item.eo || item.eoID || item.EO || item.eoid;
            if (typeof (temp) == "undefined") {
               temp = item.requirementDetail && item.requirementDetail.eoid;
            }
            return temp || '-1';
         }),
         ERID: $scope.items.map(function (item) {
            var temp = item.erid || item.erID;
            if (typeof (temp) == "undefined") {
               temp = item.requirementDetail && item.requirementDetail.pk && item.requirementDetail.pk.erID;
            }
            return temp;
         }),
         ERITN: $scope.items.map(function (item) {
            var temp = item.eritn || item.erITN;
            if (typeof (temp) == "undefined") {
               temp = item.requirementDetail && item.requirementDetail.pk && item.requirementDetail.pk.erITN;
            }
            return temp;
         })
      };

      if (tempData.EO.length == 1 && !tempData.EO[0])
         tempData.EO = ['-1'];
      $scope.loading = true;
      eoService.createEvent(tempData).then(
         function () {
            $scope.loading = false;
            $modalInstance.close($scope.items);
         }
      );
   };

   $scope.cancel = function () {
      $modalInstance.dismiss('cancel');
   };
}
;angular.module('itms.transport.event')
    .controller('EventSearchCtrl', ['$scope', '$state', '$log', 'eventService', 'exportService', EventSearchCtrl])
    .controller('EventSearchCtrl.MyWorkSpace', ['$scope', '$modal', 'common', 'exportService', EventWorkSpaceCtrl]);

function EventSearchCtrl($scope, $state, $log, eventService, exportService) {

   $scope.module = '运输执行';
   $scope.title = '事件查询';
   $scope.events = [];
   $scope.totalEvents = [];
   $scope.eventSearchCriteria = {
      quickSearch: {},
      erSearch: {},
      eoSearch: {}
   };
  
   activate();

   function activate() {
      eventService.getAllConfigData().then(function (result) {
         $scope.configData = result;
      });

   }

   $scope.searchByEvent = function () {
      $state.go('app.user.transport.eventSearch.search.searchByEvent');
   };
   $scope.searchByEo = function () {
      $state.go('app.user.transport.eventSearch.search.searchByEo');
   };
   $scope.searchByEr = function () {
      $state.go('app.user.transport.eventSearch.search.searchByEr');
   };

   $scope.eventSearch = function (queryOptions) {
      eventService.queryByEvent(queryOptions)
          .success(function (data) {
             $scope.events = data ? eventService.getEventPartial(data) : [];
             $scope.totalEvents = $scope.events;
          })
          .error(function () {
             $log.error('EventSearchCtrl: eventSearch');
          });
   };

   $scope.erSearch = function (queryOptions) {
      eventService.queryByEr(queryOptions)
          .success(function (data) {
             $scope.events = data ? eventService.getEventPartial(data) : [];
             $scope.totalEvents = $scope.events;
          })
          .error(function () {
             $log.error('EventSearchCtrl: queryByEr');
          });
   };

   $scope.eoSearch = function (queryOptions) {
      eventService.queryByEo(queryOptions)
          .success(function (data) {
             $scope.events = data ? eventService.getEventPartial(data) : [];
             $scope.totalEvents = $scope.events;
          })
          .error(function () {
             $log.error('EventSearchCtrl: queryByEr');
          });
   };


   $scope.resetQuickSearch = function () {
      $scope.eventSearchCriteria.quickSearch = {};
   };

   $scope.resetEr = function () {
      $scope.eventSearchCriteria.erSearch = {};
   };

   $scope.resetEo = function () {
      $scope.eventSearchCriteria.eoSearch = {};
   };
   

}

function EventWorkSpaceCtrl($scope, $modal, common, exportService) {

   $scope.selectedItems = [];
   $scope.columns = [
       {
          "mData": "eventType",
          "sTitle": "事件类型"
          
       },
       {
          "mData": "eventCode",
          "sTitle": "事件代码",
          "sWidth": 120
       },
       {
          "mData": "eventDesc",
          "sTitle": "事件代码描述",
          "sWidth": 180
       },
       {
          "mData": "eventDateTime",
          "sTitle": "发生时间",
          "sWidth": 150
       },
       {
          "mData": "createUser",
          "sTitle": "执行帐号"
       },
       {
          "mData": "eoNumber",
          "sTitle": "EO/ER/ERITN"
       }
   ];

   $scope.detailConfig = {
      erDetail: true,
      timeLine: true,
      eoDetail: true
   };

   $scope.handleEvent = function () {
      var modalInstance = $modal.open({
         templateUrl: 'app/transport/event/handleEvent.tpl.html',
         controller: 'HandleEventCtrl',
         resolve: {
            items: function () {
               return $scope.selectedItems.map(function (item) {
                  return {
                     eo: item.eoid,
                     erid: item.erid,
                     erITN: item.eritn
                  };
               });
            }
         }
      });
      modalInstance.result.then(function () {
         common.notifier.success("操作成功");
      });
   };

   $scope.export = function () {
      exportService.export($scope.columns, $scope.totalEvents);
   };

   $scope.getHeader = function () {
      return $scope.columns.map(function (header) {
         return header.sTitle;
      });
   };

   $scope.disableAction = function () {
      return $scope.selectedItems.length === 0;
   };

   $scope.filterEvent = function (eventType) {
      if (eventType) {
         $scope.events = $scope.totalEvents.filter(function (item) {
            return item.eventType == eventType
         });
      } else {
         $scope.events = $scope.totalEvents;
      }
   };


};angular.module('itms.transport.event')
    .factory('eventService', ['$http', '$q', 'config', 'configService', eventService]);

function eventService($http, $q, config, configService) {
    var
        defaultQueryOption = {
            serType: 'AND',
            createUser: '',
            eventType: [''],
            eventCode: '',
            eventListener1: '',
            eventListener2: '',
            eventListener3: '',
            eventListener4: '',
            EO: [''],
            ERID: [''],
            ERITN: [''],
            eventStatus: [''],
            resEventID: [''],
            memo: ''
        },
        defaultErQueryOption = {
            serType: 'AND',
            EOTag: '',
            ERID: [''],
            ERITN: [''],
            ERITNStatus: ['']
        },
        defaultEoQueryOption = {
            serType: 'OR',
            EO: [''],
            eventStatus: [''],
            EOStatus: ['']
        },
        ersearchUrl = config.baseUrl + 'ER/ERITNEventSearch',
        eosearchUrl = config.baseUrl + 'EO/EOEventSearch',
        searchUrl = config.baseUrl + 'EO/EventSearch';

    return {
        queryByEvent: queryByEvent,
        queryByEr: queryByEr,
        queryByEo: queryByEo,
        getEventPartial: getEventPartial,
        getAllConfigData: getAllConfigData
    };

    function getAllConfigData() {
        return $q.all([
                configService.getConfig('EVTP'),
                configService.getConfig('EPST'),
                configService.getConfig('ERNT'),
                configService.getConfig('EOST'),
                configService.getConfig('EVST')
            ]).then(function (results) {
                var result = {};
                angular.forEach(results, function (res) {
                    var confType = getConfType(res.data);
                    result[confType] = res.data;
                });
                return result;
            });

        function getConfType(configs) {
            return configs[0].conType;
        }
    }

    function queryByEvent(queryOptions) {
        
        var data = angular.extend({}, defaultQueryOption);
        if (queryOptions.eventType && queryOptions.eventType.length > 0) {
            data.eventType = queryOptions.eventType.map(function (item) {
                return item.code;
            });
        }
        if (queryOptions.eventStatus && queryOptions.eventStatus.length > 0) {
            data.eventStatus = queryOptions.eventStatus.map(function (item) {
                return item.code;
            });
        }
        if (queryOptions.eventCode) data.eventCode = queryOptions.eventCode;
        if (queryOptions.eventListener1) data.eventListener1 = queryOptions.eventListener1;
        if (queryOptions.eventListener2) data.eventListener2 = queryOptions.eventListener2;
        if (queryOptions.eventListener3) data.eventListener3 = queryOptions.eventListener3;
        if (queryOptions.eventListener4) data.eventListener4 = queryOptions.eventListener4;
        if (queryOptions.eoNumber) data.EO = [queryOptions.eoNumber];
        if (queryOptions.erNumber) data.ERID = [queryOptions.erNumber];

        return $http.postXSRF(searchUrl, data);
    }

    function queryByEr(queryOptions) {
        var data = angular.extend({}, defaultErQueryOption);
        if (queryOptions.ERStatus && queryOptions.ERStatus.length > 0) {
            data.ERITNStatus = queryOptions.ERStatus.map(function (item) {
                return item.code;
            });
        }
        data.ERID=[queryOptions.ERID || ''];
        data.ERITN=[queryOptions.ERITN || ''];
        return $http.postXSRF(ersearchUrl, data);
    }

    function queryByEo(queryOptions) {
        var data = angular.extend({}, defaultEoQueryOption);
        if (queryOptions.eoStatus && queryOptions.eoStatus.length > 0) {
            data.EOStatus = queryOptions.eoStatus.map(function (item) {
                return item.code;
            });
        }
        if (queryOptions.eoEventStatus && queryOptions.eoEventStatus.length > 0) {
            data.eventStatus = queryOptions.eoEventStatus.map(function (item) {
                return item.code;
            });
        }
        data.EO = [queryOptions.eoID || ''];
        return $http.postXSRF(eosearchUrl, data);
    }

    function getEventPartial(events) {
        if (!events || events.errorMessage === 'NO_RESULT') return [];
        return events.map(mapEvent);

        function mapEvent(item) {
            return {
                eventType: item.event.eventType,
                eventCode: item.event.eventCode,
                eventDesc: item.event.eventDesc|| item.eventDesc || '',
                eventDateTime: item.event.eventDateTime,
                createUser: item.event.createUser,
                eoNumber: item.event.eo + '/' + item.event.erid + '/' + item.event.eritn,
                eoid: item.event.eo,
                erid: item.event.erid,
                eritn: item.event.eritn
            };
        }
    }
};angular.module('itms.transport.eoMaintain')
    .controller('MyElectricOrderCtrl', ['$scope', '$modal', '$log', 'myElectricOrderService', MyElectricOrderCtrl]);

function MyElectricOrderCtrl($scope, $modal, $log, myElectricOrderService) {
   $scope.selectedItems = [];
   $scope.module = "运输执行";
   $scope.title = "我的运单";
   $scope.queryOption = {
      SerType: 'AND',
      EO: [''],
      EOStatus: [''],
      eventstatus: [''],
      EOType: [''],
      EOTRType: [''],
      EOTag: [''],
      EOTRVendor1: '',
      EOTRVendor2: '',
      EOTRVendor3: '',
      customerOrder1: '',
      customerOrder2: '',
      customerOrder3: '',
      VendorOrder1: '',
      VendorOrder2: '',
      VendorOrder3: '',
      reqDelDate1: '',
      reqDelDate2: '',
      reqDelDate3: '',
      reqDelDate4: '',
      ScheduleVendor1: '',
      ScheduleClass1: '',
      DepDate1: '',
      ArrDate1: '',
      DepTime1: '',
      Arrtime1: '',
      DeliverBP1: '',
      DeliverBP2: '',
      depCustomer: ($scope.currentUser.userType == '1') ? $scope.currentUser.auth.salesArea : '',
      depLocCode: '',
      recCustomer: ($scope.currentUser.userType == '2') ? $scope.currentUser.auth.salesArea : '',
      recLocCode: '',
      BP1: "",
      BP2: "",
      BP3: ""

   };

   $scope.reset = function () {

      $scope.queryOption = {
         SerType: 'AND',
         EO: [''],
         EOStatus: [''],
         eventstatus: [''],
         EOType: [''],
         EOTRType: [''],
         EOTag: [''],
         EOTRVendor1: '',
         EOTRVendor2: '',
         EOTRVendor3: '',
         customerOrder1: '',
         customerOrder2: '',
         customerOrder3: '',
         VendorOrder1: '',
         VendorOrder2: '',
         VendorOrder3: '',
         reqDelDate1: '',
         reqDelDate2: '',
         reqDelDate3: '',
         reqDelDate4: '',
         ScheduleVendor1: '',
         ScheduleClass1: '',
         DepDate1: '',
         ArrDate1: '',
         DepTime1: '',
         Arrtime1: '',
         DeliverBP1: '',
         DeliverBP2: '',
         depCustomer: ($scope.currentUser.userType == '1') ? $scope.currentUser.auth.salesArea : '',
         depLocCode: '',
         recCustomer: ($scope.currentUser.userType == '2') ? $scope.currentUser.auth.salesArea : '',
         recLocCode: ''
      };
   };
   $scope.results = [];
   $scope.detailConfig = {
      erDetail: true,
      timeLine: true,
      eoDetail: true
   };
   $scope.columns = [{
      "mData": "eo",
      "sTitle": "EO"
   }, {
      "mData": "erID",
      "sTitle": "ER"
   }, {
      "mData": "erITN",
      "sTitle": "ERITN"
   }, {
      "mData": "eoStatus",
      "sTitle": "运单状态",
      "sWidth": 150
   }, {
      "mData": "eventstatus",
      "sTitle": "事件状态",
      "sWidth": 120
   }, {
      "mData": "vendorOrder1",
      "sTitle": "承运商路单",
      "sWidth": 120
   }, {
      "mData": "routeClassID",
      "sTitle": "路单号"
   }, {
      "mData": "tranResLicense",
      "sTitle": "车牌"
   }, {
      "mData": "transDriverID",
      "sTitle": "司机"
   }, {
      "mData": "resAmt1",
      "sTitle": "包装数量",
      "sWidth": 120
   }, {
      "mData": "matIIDDesc",
      "sTitle": "物料名称",
      "sWidth": 120
   }, {
      "mData": "customerOrder",
      "sTitle": "客户订单号",
      "sWidth": 150
   }, {
      "mData": "eoType",
      "sTitle": "类型",
      "sWidth": 120
   }, {
      "mData": "eoTag",
      "sTitle": "特殊"
   }, {
      "mData": "depCustomer",
      "sTitle": "发货方",
      "sWidth": 150
   }, {
      "mData": "recCustomer",
      "sTitle": "收货方",
      "sWidth": 150
   }, {
      "mData": "reDelDate",
      "sTitle": "发达日期",
      "sWidth": 150
   }, {
      "mData": "eoTrtype",
      "sTitle": "方式",
      "sWidth": 120
   }, {
      "mData": "eoTrvendor",
      "sTitle": "承运方"
   }, {
      "mData": "vendorOrder",
      "sTitle": "承运方单号",
      "sWidth": 120
   }];

   $scope.searchCustomer = function (type) {
      var modalInstance = $modal.open({
         templateUrl: "app/planning/searchCustomer.tpl.html",
         controller: searchCustomerCtrl,
         resolve: {
            type: function () {
               return type;
            }
         }
      });
      modalInstance.result.then(function (selectedItem) {
         if (type === 'dep') {
            $scope.queryOption.depCustomer = selectedItem[0];
         } else {
            $scope.queryOption.recCustomer = selectedItem[0];
         }
      }, function () {
         $log.info('Modal dismissed at: ' + new Date());
      });
   };

   $scope.eoMaintainSearch = function () {
      var data = $scope.queryOption;
      myElectricOrderService.quickSearch(data)
          .success(function (res) {
             if (!res || res.errorMessage)
                $scope.results = [];
             else
                $scope.results = myElectricOrderService.getResultPartial(res);
          })
          .error(function () {
             $log.error('EOMaintainSearchCtrl: quickSearch');
          });

   };

   $scope.export = function () {
      exportService.export($scope.columns, $scope.results)

   };

}
;angular.module('itms.transport.eoMaintain')
    .factory('myElectricOrderService', ['$http', 'config', "configService", function ($http, config, configService) {
        

        var searchUrl = config.baseUrl + 'EO/MyEOQuickSearch';

        return {
            quickSearch: quickSearch,
            getResultPartial: getResultPartial
        };

        function quickSearch(param) {
            var data = param;
            return $http.postXSRF(searchUrl, data);
        }

        function getResultPartial(items) {
            return items.map(mapResult);

            function mapResult(item) {
                return {
                    eo: item.dn.eo,
                    erID: item.erHead.erID,
                    erITN: item.erItem.pk.erITN,
                    eoStatus: item.eostatusDesc,
                    customerOrder: item.dn.customerOrder1,
                    eoType: item.eotypeDesc,
                    eoTag: item.eotagDesc,
                    depCustomer: item.depCustomerDesc,
                    recCustomer: item.recCustomerDesc,
                    reDelDate: item.dn.reqDelDate1,
                    eoTrtype: item.eotrtypeDesc,
                    eoTrvendor: item.eotrvendor1Desc,
                    vendorOrder: item.dn.vendorOrder1,
                    eventstatus:item.dn.eventstatus,
                    vendorOrder1:item.dn.vendorOrder1,
                    routeClassID:item.erItem.routeClassID,
                    tranResLicense:item.erItem.tranResLicense,
                    transDriverID:item.erItem.transDriverID,
                    resAmt1:item.erItem.resAmt1,
                    matIIDDesc:item.matIIDDesc


                };
            }
        }


    }]);